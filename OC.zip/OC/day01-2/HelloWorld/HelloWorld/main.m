//
//  main.m
//  HelloWorld
//
//  Created by lcy on 14/11/10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

/*
    c   .c  和 .h
    oc  .m   message 和  .h
    oc ---> c++  .mm   和  .h
 */

#import <Foundation/Foundation.h>

//#include "<#header#>"
//#include <<#header#>>

/*
    test.h
    int a;  //全局变量   .c
 */
//#include <type.h>
//test.h
//#ifndef __XXXXXX__
//#define __XXXXXX__

//#endif
//./a.out abc
//argv[0]  a.out    argv[1]  abc

void test(void)
{
    NSLog(@"test");
}
int main(int argc, const char * argv[])
{
    //a.out
    //32   4GB
    //64
    //@autoreleasepool  自动释放池   内存管理
    @autoreleasepool {
        // insert code here...
        //没有时间   以及 回车
        printf("helloworld");
        
        // 操作系统 next step
        // 防止文件重名
        // Log
        //C++  namespace
        //QF
        //@"Hello, World!"  oc的字符串对象
        //"helloworld"
        
        NSLog(@"Hello, World!"); //有
        
        //command +
        /*
         #if __LP64__ || (TARGET_OS_EMBEDDED && !TARGET_OS_IPHONE) || TARGET_OS_WIN32 || NS_BUILD_32_LIKE_64
         typedef long NSInteger;
         typedef unsigned long NSUInteger;
         #else
         typedef int NSInteger;
         typedef unsigned int NSUInteger;
         #endif
         */
        //command + /
        NSInteger INT_i = 10;   //NSInteger
        
        printf("%ld",INT_i);
        NSLog(@"%ld",INT_i);
        
//        //float  CGFloat
        /*
         #if defined(__LP64__) && __LP64__
         # define CGFLOAT_TYPE double
         # define CGFLOAT_IS_DOUBLE 1
         # define CGFLOAT_MIN DBL_MIN
         # define CGFLOAT_MAX DBL_MAX
         #else
         # define CGFLOAT_TYPE float
         # define CGFLOAT_IS_DOUBLE 0
         # define CGFLOAT_MIN FLT_MIN
         # define CGFLOAT_MAX FLT_MAX
         #endif
         */
        
        //int *p = NULL;  //NULL (void *)0//nil  Nil
        //0  即不可读 也不可写
        //*p = 10
        //NSLog(@"%d",*p);  //Segement
        
        //void *   必须要强转    id
        //id
        
        //bool   TURE  FALSE
        //BOOL  YES   NO
        //control + i
        //control + v  上下键   =
        BOOL ret = 1 > 2;
        
        if(ret)
        {
            NSLog(@"YES");
        }
        else
        {
            NSLog(@"NO");
        }
        
        //printf   gdb
        //质数
        for (NSInteger i = 0; i < 10; i++) {
            
        }
        
        //fn+ 快捷键
        test();
        NSLog(@"NO");
        
        //forin
//        for (<#type *object#> in <#collection#>) {
//            <#statements#>
//        }
        
        //i
    }
    return 0;
}

