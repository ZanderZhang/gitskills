//
//  Person.m
//  Person
//
//  Created by lcy on 14/11/10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

@end
