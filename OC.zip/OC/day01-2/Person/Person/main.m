//
//  main.m
//  Person
//
//  Created by lcy on 14/11/10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

/* .h .c
 1.定义一个汽车类,包含以下
 成员:品牌,价格,
 */
//person   name   age
struct Per
{
    char *name;
    int age;
};

//@interface
//NSObject   所以类的基类  只要是oc的类 必须直接或者间接的继承该类
// id  ==  NSObject *
//类的声明
//@interface 类名 : NSObject
//@end
//@interface Person : NSObject
//{
//    //类的成员变量的访问  是有权限的.
//    //类内 (声明和实现)  和  类外
//    //共有的   @public      都可以访问
//    //被保护的  @protected  只能被类内和子类访问 (默认)
//    //私有的   @private    只能被类内
//    //字段  或者  成员(实例)变量
//    //所有的字段  都有以下划线打头.
//@public
//    char *_name;
//    NSInteger _age;  //long  _age;
//}
//
//@end
//
////类的实现
////@implementation 类名
////@end
//
//@implementation Person
//
//@end

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        // insert code here...
        //NSLog(@"Hello, World!");
        
        //struct Per p = {"zhangsan",11};  //栈
        //p  栈   保存 了一个堆内存地址
        struct Per *p = (struct Per *)malloc(sizeof(struct Per));  //堆
        //memset
        p->name = "zhangsan";
        p->age = 100;
    
        NSLog(@"%s,%d",p->name,p->age);
        
        //OC的所有声明的对象 都要在堆内存
        //alloc    在堆中申请内存
        //[类名或者对象 消息];
        //study();
        Person *per = [Person alloc];
        
        //画一条线说明没权限访问
        per->_name = "zhangsan";
        per->_age = 100;
        
        NSLog(@"%s,%ld",per->_name,per->_age);
        
    }
    return 0;
}

