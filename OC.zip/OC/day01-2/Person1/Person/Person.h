//
//  Person.h
//  Person
//
//  Created by lcy on 14/11/10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//person  eat
@interface Person : NSObject
{
    //此处 只允许 存放成员变量  不允许存放成员方法。
//@public
    char *_name;
    NSInteger _age;
}

//void eat(void);
//oc的方法 要以 +  或者  - 开头
//-   方法  一定要用对象来调用。
//+   方法  只能用类名来调用
//-(返回值)方法名;
//方法名:  eat
//成员方法
-(void)eat;

//和谁一起吃饭
//void eatWithName(char *name);
//-(返回值)方法名:(参数类型)参数名;
//方法名:  eatWithName:
-(void)eatWithName:(char *)name;

//和谁一起吃饭  吃了多久.
//void eatWithName(char *name,int time);
//-(返回值)方法名:(参数类型)参数名 标签:(参数类型)参数名 ..
//方法名:  eatWithName: andTime:
-(void)eatWithName:(char *)name andTime:(NSInteger)time;

//100
//int returnValue(void);
//-(返回值)方法名;
//方法名:  returnValue
-(NSInteger)returnValue;

//启动
-(void)start;
//以多少的速度启动
-(void)startWithSpeed:(NSInteger)speed;
//以多少的速度启动  跑了多久

@end
