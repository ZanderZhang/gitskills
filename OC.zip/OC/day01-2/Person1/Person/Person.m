//
//  Person.m
//  Person
//
//  Created by lcy on 14/11/10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

-(void)eat
{
    NSLog(@"person eat");
}

-(void)eatWithName:(char *)name
{
    NSLog(@"person eat With %s",name);
}

-(void)eatWithName:(char *)name andTime:(NSInteger)time
{
    NSLog(@"person eat With %s andtime %ld",name,time);
}

-(NSInteger)returnValue
{
    return 100;
}

@end
