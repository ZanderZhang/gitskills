//
//  main.m
//  Person
//
//  Created by lcy on 14/11/10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        Person *per = [Person alloc];
        per->_name = "zhangsan";
        per->_age = 100;
        
        NSLog(@"%s,%ld",per->_name,per->_age);
        [per eat];
        
        //[类名或者对象 消息:实参 标签:参数 ..];
        [per eatWithName:"lisi"];
        //[per startWithSpeed:100];
        
        [per eatWithName:"lisi" andTime:100];
        
        NSInteger ret = [per returnValue];
        NSLog(@"%ld",ret);
    }
    return 0;
}

