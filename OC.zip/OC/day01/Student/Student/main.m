//
//  main.m
//  Student
//
//  Created by lcy on 14/11/10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//function
void study(void)
{
    NSLog(@"stu study");
}

//抽象  类
typedef struct stu
{
    char name[20];
    int age;
    
    //函数指针
    //study
    void (*study)(void);  //int *p;
}stu_t;

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        //具体的学生   对象
        stu_t s;    //栈
        strcpy(s.name, "lisi");
        //函数名就是函数地址
        s.study = study;
        
        s.study();
        // insert code here...
        NSLog(@"Hello, World!");
        
    }
    return 0;
}

