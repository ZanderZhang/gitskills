//
//  Car.h
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Car : NSObject
{
    NSInteger _speed;
}

-(id)initWithSpeed:(NSInteger)speed;
-(void)setSpeed:(NSInteger)speed;
-(NSInteger)speed;

@end
