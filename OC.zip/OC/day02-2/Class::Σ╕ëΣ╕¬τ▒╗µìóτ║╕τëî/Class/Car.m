//
//  Car.m
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Car.h"

@implementation Car
-(id)initWithSpeed:(NSInteger)speed{
    self = [super init];
    if(self)
    {
        _speed = speed;
    }
    return self;
}

-(void)setSpeed:(NSInteger)speed{
    _speed = speed;
}

-(NSInteger)speed{
    return _speed;
}
@end
