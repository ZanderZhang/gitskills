//
//  Card.h
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Card : NSObject
{
    char _value;
}

-(id)initWithValue:(char)value;
-(void)swapCard:(Card *)card;
-(char)value;

@end
