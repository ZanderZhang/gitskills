//
//  Card.m
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Card.h"

@implementation Card

-(id)initWithValue:(char)value
{
    self = [super init];
    if(self)
    {
        _value = value;
    }
    return self;
}

-(void)swapCard:(Card *)card{
    char temp = self->_value;
    self->_value = card->_value;
    card->_value = temp;
}

-(char)value{
    return _value;
}
@end
