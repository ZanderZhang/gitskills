//
//  Hands.m
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Hands.h"

@implementation Hands

-(id)initWithCard:(char)cardValue{
    self = [super init];
    if(self)
    {
        _card = [[Card alloc] initWithValue:cardValue];
    }
    return self;
}

-(void)swapCardWithRightHand:(Hands *)rightHand{
    [self->_card swapCard:rightHand->_card];
}

-(Card *)card
{
    return _card;
}

@end
