//
//  Person.h
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Hands.h"

@interface Person : NSObject
{
    Hands *_leftHand;
    Hands *_rightHand;
}

-(id)initWithLeftCard:(char)leftCard andRightCard:(char)rightCard;

-(void)swapHands;

-(Hands *)leftHand;
-(Hands *)rightHand;

@end
