//
//  Person.m
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person
-(id)initWithLeftCard:(char)leftCard andRightCard:(char)rightCard{
    self = [super init];
    if(self)
    {
        _leftHand = [[Hands alloc] initWithCard:leftCard];
        _rightHand = [[Hands alloc] initWithCard:rightCard];
    }
    return self;
}


-(void)swapHands{
    [_leftHand swapCardWithRightHand:_rightHand];
}

-(Hands *)leftHand{
    return  _leftHand;
}
-(Hands *)rightHand{
    return _rightHand;
}


@end
