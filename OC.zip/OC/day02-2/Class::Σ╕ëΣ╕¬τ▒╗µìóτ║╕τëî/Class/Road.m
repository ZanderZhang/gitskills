//
//  Road.m
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Road.h"

@implementation Road

-(id)initWithDis:(NSInteger)dis andSpeed:(NSInteger)speed{
    self = [super init];
    if(self)
    {
        _dis = dis;
        _car = [[Car alloc] initWithSpeed:speed];
    }
    return  self;
}

-(NSInteger)calcTime{
    return  _dis / [_car speed];
}

@end
