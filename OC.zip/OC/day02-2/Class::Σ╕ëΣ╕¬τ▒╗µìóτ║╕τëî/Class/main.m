//
//  main.m
//  Class
//
//  Created by lcy on 14-8-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

struct bir
{
    int year;
    int month;
    int day;
};

struct stu{
    char name[20];
    int age;
    //生日
    struct bir *b;
};

////Car
//NSInteger speed;  (init)20;
//
////@interface Road : NSObject
//{
//    NSInteger dis;  (init)1000
//    Car *car; (get set)
//}

//@end

//人
//{leftHand  rightHand}
//手
//{
//   leftCard rightCard
//}
//Card
#import "Road.h"
#import "Person.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        
        Road *road = [[Road alloc] initWithDis:1000 andSpeed:20];
        
        NSInteger time = [road calcTime];
        NSLog(@"%ld",time);
        
        Person *p = [[Person alloc] initWithLeftCard:'A' andRightCard:'K'];
        NSLog(@"leftcard = %c rightcard = %c",[[[p leftHand] card] value],[[[p rightHand] card] value]);
        
        [p swapHands];
        
        NSLog(@"leftcard = %c rightcard = %c",[[[p leftHand] card] value],[[[p rightHand] card] value]);
    }
    return 0;
}

