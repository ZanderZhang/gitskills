//
//  Dog.h
//  Get_set_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
/*
    @interface 
    {
        成员变量
    }
      +            -
    类的方法     对象的方法
    init   初始化 成员变量
    initWithXXXX
    setter  getter
    @end
 */

@interface Dog : NSObject
{
    NSInteger _age;
    NSInteger _height;
    NSInteger _weight;
}

-(void)setAge:(NSInteger)age;
-(void)setWeight:(NSInteger)weight;
-(void)setHeight:(NSInteger)height;

-(NSInteger)age;
-(NSInteger)weight;
-(NSInteger)height;

-(void)setAge:(NSInteger)age andWeight:(NSInteger)weight andHeight:(NSInteger)height;

-(void)show;

+(void)test;

@end
