//
//  Dog.m
//  Get_set_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Dog.h"

@implementation Dog

+(void)test
{
    //+方法  既不能访问 成员变量 也不能访问成员方法
    //_age = 100;
    //self Dog
    //self set
}

-(void)setAge:(NSInteger)age
{
    _age = age;

}

-(void)setWeight:(NSInteger)weight
{
    _weight = weight;
    //self setA
}

-(void)setHeight:(NSInteger)height
{
    _height = height;
}

-(NSInteger)age
{
    return _age;
}
-(NSInteger)weight
{
    return _weight;
}
-(NSInteger)height
{
    return _height;
}

-(void)setAge:(NSInteger)age andWeight:(NSInteger)weight andHeight:(NSInteger)height
{
    _age = age;
    _height = height;
    _weight = weight;
}

-(void)show
{
    NSLog(@"age = %ld,height = %ld,weight = %ld",_age,_height,_weight);
}

@end
