//
//  MyRect.h
//  Get_set_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyRect : NSObject
{
    NSInteger _length;
    NSInteger _width;
    NSInteger _area;
}

-(void)setLength:(NSInteger)length andWidth:(NSInteger )width;
-(NSInteger)area;

@end
