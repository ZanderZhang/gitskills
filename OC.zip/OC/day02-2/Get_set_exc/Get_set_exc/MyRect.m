//
//  MyRect.m
//  Get_set_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "MyRect.h"

@implementation MyRect

-(void)setLength:(NSInteger)length andWidth:(NSInteger)width
{
    _length = length;
    _width = width;
}

-(NSInteger)area
{
    return _length * _width;
}

@end
