//
//  main.m
//  Get_set_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyRect.h"
#import "Dog.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        MyRect *rect = [[MyRect alloc] init];
        [rect setLength:10 andWidth:100];
        NSLog(@"%ld",[rect area]);
        
        Dog *dog = [[Dog alloc] init];
        
        [Dog test];
    }
    return 0;
}

