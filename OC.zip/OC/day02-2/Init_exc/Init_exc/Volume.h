//
//  Volume.h
//  Init_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Volume : NSObject
{
    NSInteger _length;
}

//initWithXxxxxXxxxx
-(id)init;
-(id)initWithLength:(NSInteger)length;
-(NSInteger)volume;

@end
