//
//  Volume.m
//  Init_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Volume.h"

@implementation Volume

-(id)init
{
    self = [super init];
    if(self)
    {
        _length = 1;
    }
    return self;
}

-(id)initWithLength:(NSInteger)length
{
    self = [super init];
    
    if(self)
    {
        _length = length;
    }
    return self;
}

-(NSInteger)volume
{
    return _length * _length * _length;
}

@end
