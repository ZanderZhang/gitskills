//
//  main.m
//  Init_exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Volume.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        
        Volume *v = [[Volume alloc] init];
        NSLog(@"%ld",[v volume]);
        
        Volume *v1 = [[Volume alloc] initWithLength:10];
        NSLog(@"%ld",[v1 volume]);
        
    }
    return 0;
}

