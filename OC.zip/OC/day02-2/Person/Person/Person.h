//
//  Person.h
//  Person
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
@public
    char *_name; //8
    NSInteger _age;
}

//-(id)init; //NSObject *
-(id)initWithName:(char *)name;
-(id)initWithName:(char *)name andAge:(NSInteger)age;

+(void)test;


@end
