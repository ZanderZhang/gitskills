//
//  Person.m
//  Person
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

/*
    self = [super init];
    if(self != nil)
    {
 
    }
    return self;
 */

/*
    +  -
    -  self 哪个对象调用方法  self指向哪个对象
    +  self 哪个类调用该方法  self指向该类
 */

//

-(id)init
{
    //"zhangsan"  100
    //self 自己
    //super 父类
    //alloc   new  --->  malloc   失败
    self = [super init]; //父类构造子类失败  返回nil
    //NSLog(@"%p",self);
    if(self)    //0
    {
        //init code
        //NSLog(@"self con");
        _name = "zhangsan"; //p->_name == //self->_name
        _age = 0;
    }
    return self;
}

//
-(id)initWithName:(char *)name
{
    self = [super init];
    
    if(self)
    {
        //解决的方法
        //1.成员变量+ "_"
        //2.self 修饰访问.
        _name = name;
    }
    return self;
}

-(id)initWithName:(char *)name andAge:(NSInteger)age
{
    self = [super init];
    
    if(self)
    {
        _name = name;
        _age = age;
    }
    return self;
}
//instancetype == id
//instancetype 只能做返回值
//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        
//    }
//    return self;
//}

//类的方法  不能访问成员变量

+(void)test
{
    //_name = "zhangsan";
    
}


@end
