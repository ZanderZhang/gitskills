//
//  Car.h
//  Time
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Car : NSObject
{
    CGFloat _speed;
}

-(id)initWithSpeed:(CGFloat)speed;
-(CGFloat)speed;

@end
