//
//  Car.m
//  Time
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Car.h"

@implementation Car

-(id)initWithSpeed:(CGFloat)speed
{
    self = [super init];
    if(self)
    {
        _speed = speed;
    }
    return self;
}

-(CGFloat)speed
{
    return _speed;
}

@end
