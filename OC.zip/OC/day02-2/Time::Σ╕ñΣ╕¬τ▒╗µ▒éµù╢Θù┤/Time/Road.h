//
//  Road.h
//  Time
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"

@interface Road : NSObject
{
    CGFloat _dis;
    Car *_car;
}

-(id)initWithDis:(CGFloat)dis;
-(void)setCar:(Car *)car;
-(CGFloat)calcTime;

@end
