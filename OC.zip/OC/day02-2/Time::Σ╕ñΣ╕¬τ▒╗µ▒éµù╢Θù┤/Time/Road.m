//
//  Road.m
//  Time
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Road.h"

@implementation Road

-(id)initWithDis:(CGFloat)dis
{
    self = [super init];
    if (self) {
        _dis = dis;
    }
    return self;
}

-(void)setCar:(Car *)car
{
    _car = car;
}

-(CGFloat)calcTime
{
   return _dis / [_car speed];
}

@end
