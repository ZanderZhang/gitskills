//
//  main.m
//  Time
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

//struct Bir
//{
//    int year;
//    int month;
//    int day;
//};
//
//struct stu
//{
//    char *name;
//    //生日
//    struct Bir bir;
//};

/*
    Car  
    _speed
 
    Road
    _dis
    Car *_car;
 */

#import <Foundation/Foundation.h>
#import "Road.h"
#import "Car.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        Car *car = [[Car alloc] initWithSpeed:20.0f];
        Road *road = [[Road alloc] initWithDis:1000.0f];
       
        [road setCar:car];
        NSLog(@"%g",[road calcTime]);
    }
    return 0;
}

