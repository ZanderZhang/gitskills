//
//  Add.h
//  Exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Add : NSObject
//
{
@public
    NSInteger _leftValue;
    NSInteger _rightValue;
}

-(NSInteger)calc;

+(NSInteger)calc:(NSInteger)leftValue andRightValue:(NSInteger)rightValue;

@end
