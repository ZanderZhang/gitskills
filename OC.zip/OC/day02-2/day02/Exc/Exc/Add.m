//
//  Add.m
//  Exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Add.h"

@implementation Add

-(NSInteger)calc
{
    return _leftValue + _rightValue;
}
//+  -
//-   对象
//+   类的方法
//有的时候 不需要使用成员变量的时候(不需要对象)  考虑使用+方法
+(NSInteger)calc:(NSInteger)leftValue andRightValue:(NSInteger)rightValue
{
    return leftValue + rightValue;
}

@end
