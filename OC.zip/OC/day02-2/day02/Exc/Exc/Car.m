//
//  Car.m
//  Exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Car.h"

@implementation Car

-(CGFloat)calcTime
{
    return _dis / _speed;
}

@end
