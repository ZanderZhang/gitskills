//
//  Card.h
//  Exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Card : NSObject
{
@public
    char _leftCard[20];
    char _rightCard[20];
}

-(void)swapCard;

@end
