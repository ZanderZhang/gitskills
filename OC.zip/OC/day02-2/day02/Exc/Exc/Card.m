//
//  Card.m
//  Exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Card.h"

@implementation Card

-(void)swapCard
{
    char temp[20] = {0};
    strcpy(temp, _leftCard);
    strcpy(_leftCard, _rightCard);
    strcpy(_rightCard, temp);
}

@end
