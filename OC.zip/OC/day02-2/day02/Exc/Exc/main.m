//
//  main.m
//  Exc
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"
#import "Card.h"
#import "Add.h"


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        //malloc  随机值
        //alloc  所有对象的成员变量的值都为 0
        Car *car = [Car alloc];
        //NSLog(@"%lf %lf",car->_speed,car->_dis);
        
        car->_dis = 1000;
        car->_speed = 20;
        
        CGFloat time = [car calcTime];
        //%g  float
        NSLog(@"%d",(int)time);
        
        Card *card = [Card alloc];
        
        strcpy(card->_leftCard,"red A");
        strcpy(card->_rightCard, "black K");
        
        [card swapCard];
        
        NSLog(@"left = %s,right = %s",card->_leftCard,card->_rightCard);
        
        Add *add = [Add alloc];
        add->_leftValue  = 10;
        add->_rightValue = 20;
        NSLog(@"%ld",[add calc]);
        
        //调用+方法的时候  不需要开辟内存  效率优化
        //Add *add1  = [Add alloc];
        NSLog(@"%ld",[Add calc:10 andRightValue:20]);
    }
    return 0;
}

