//
//  main.m
//  Person
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

struct stu
{
    char *name;
    int age;
};

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        // 0 0
        //构造函数 要求   必须以initWithXXXXX
        //用来初始化对象的成员变量
        //嵌套调用  C++
        //zhangsan  20
        Person *p = [[Person alloc] initWithName:"zhangsan"];
        NSLog(@"%s,%ld",p->_name,p->_age);
        //p1  lisi  10
        
        //带参数的构造函数
        Person *p1 = [[Person alloc] initWithName:"lisi"];
        NSLog(@"%s,%ld",p1->_name,p1->_age);
        //Person *p1 = [[Person alloc] init];
        //父类的init方法
        //如果要调用自己的init方法 必须要自己实现init.
        //
        //memset
        //p->_name = "zhangsan";
        //int a;   初始化   赋值
        //a  = 10;
        
        Person *p2 = [[Person alloc] initWithName:"zhangsan" andAge:20];
        NSLog(@"%s,%ld",p2->_name,p2->_age);
        
        Person *p3 = [[Person alloc] initWithName:"lisi" andAge:10];
        NSLog(@"%s,%ld",p3->_name,p3->_age);
    }
    return 0;
}

