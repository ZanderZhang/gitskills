//
//  Person.m
//  Person
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

/*
    self = [super init];
    if(self != nil)
    {
 
    }
    return self;
 */

/*
    +  -
    -  self 哪个对象调用方法  self指向哪个对象
    +  self 哪个类调用该方法  self指向该类
 */

//

-(id)init
{
//    self = [super init];
//    if(self)
//    {
//        _name = "zhangsan";
//        _age = 0;
//    }
//    return self;
    //self -> p
    return [self initWithName:"zhangsan" andAge:0];
}

-(id)initWithName:(char *)name
{
//    self = [super init];
//    if(self)
//    {
//        _name = name;
//    }
//    return self;
    return [self initWithName:name andAge:0];
}

-(id)initWithName:(char *)name andAge:(NSInteger)age
{
    self = [super init];
    
    if(self)
    {
        _name = name;
        _age = age;
    }
    return self;
}

@end
