//
//  Person.h
//  get_set
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
@protected
    char *_name;
@protected
    NSInteger _age;
}
//访问器和设置器
//作用:访问或者设置类的被保护或者私有成员的值
//getter   setter
//属性
//setter  成员变量 把"_"去掉 首字母大写 前面加上set
//_name  name  --->  Name  ---> setName
-(void)setName:(char *)name;

//getter  成员变量 把"_"去掉
//_name   name
-(char *)name;

-(void)setAge:(NSInteger )age;
-(NSInteger)age;

-(void)setName:(char *)name andAge:(NSInteger)age;

//show  显示所有成员变量的信息
-(void)show;

-(id)initWithName:(char *)name andAge:(NSInteger)age;

@end
