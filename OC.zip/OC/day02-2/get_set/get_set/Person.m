//
//  Person.m
//  get_set
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

-(id)initWithName:(char *)name andAge:(NSInteger)age
{
    self = [super init];
    if(self)
    {
        _name = name;
        _age = age;
    }
    
    return self;
}

-(void)setName:(char *)name
{
    _name = name;
}

//-(char *)name
//{
//    return _name;
//}

-(void)setAge:(NSInteger)age
{
    _age = age;
    //[self setName:_name andAge:age];
}

//-(NSInteger)age
//{
//    return _age;
//}

-(void)setName:(char *)name andAge:(NSInteger)age
{
    _name = name;
    _age = age;
}

-(void)show
{
    NSLog(@"name = %s,age = %ld",_name,_age);
}

@end
