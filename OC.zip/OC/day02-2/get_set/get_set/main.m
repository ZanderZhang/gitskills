//
//  main.m
//  get_set
//
//  Created by lcy on 14/11/11.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        
        Person *p = [[Person alloc] initWithName:"xiaoli" andAge:21];
        
        [p setName:"xiaozhang" andAge:22];
        [p show];
        
//        NSLog(@"%s",[p name]);
//        //xiaozhang
//        [p setName:"xiaozhang"];
//        [p setAge:22];
//        NSLog(@"%s",[p name]);
//        
//        //空指针  可以调用方法  但是不会执行该方法 如果该方法有后返回值 返回nil.
//        Person *p1 = nil;
//        [p1 setAge:10];
//        NSLog(@"%ld",[p1 age]);
        
        
    }
    return 0;
}

