//
//  main.m
//  NSMutableString
//
//  Created by lcy on 14/11/12.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

NSString *rangeToStr(NSRange range)
{
    return [NSString stringWithFormat:@"{%ld,%ld}",range.location,range.length];
}

void NSString_exc(void)
{
    NSString *str = @"My name is";
    NSString *str1 = @"John Zhang";
    NSString *str2 = @"I am 45";
    
    NSString *str3 = [NSString stringWithFormat:@"%@ %@,%@",str,str1,str2];
    
    NSLog(@"%@",str3);
    
    //int a;
    //test(int *b)
//    {
//        *b = 100;
//    }
    //int *a = &b;
    //test(a)
//    {
//        a =
//    }
    //test(int **b);
    NSError *err = nil;
    [str3 writeToFile:@"/Users/lcy/Desktop/test" atomically:YES encoding:NSUTF8StringEncoding error:&err];
    
    NSLog(@"%@",err);
    
    NSString *str4 = [NSString stringWithContentsOfFile:@"/Users/lcy/Desktop/test" encoding:NSUTF8StringEncoding error:&err];
    NSLog(@"%@",str4);
    
    NSString *str5 = @"Welcome to Beijing";
    NSString *str6 = @"Beijing";
    NSString *str7 = @"When I was young,I loved a girl on neighbor class.";
    NSString *str8 = @"was";
    NSString *str9 = @"girl";
    
    NSRange range = [str5 rangeOfString:str6];
    //NSStringFromRange 把range转换成字符串
    if(range.location == NSNotFound)
    {
    //NSNotFound==-1,是一个很大的数，就是-1无符号的时候。
    }
    else
    {
        NSLog(@"%@",NSStringFromRange(range));//******
    }
    
    NSString *str10 = [str5 substringWithRange:NSMakeRange(2, 4)];
    
    NSLog(@"%@",str10);
    //was
    NSRange range1 = [str7 rangeOfString:str8];
    //girl
    NSRange range2 = [str7 rangeOfString:str9];
    //was - girl  length
    NSRange range3 = NSMakeRange(range1.location, range2.location - range1.location + range2.length);
    
    NSString *str11 = [str7 substringWithRange:range3];
    NSLog(@"%@",str11);
}
//NSMutableString  NSString

void create_NSMutableString(void)
{
    NSString *str1 = @"helloworld"; //不可变
    
    NSMutableString *str = [[NSMutableString alloc] initWithString:str1]; //可变
    
    //NSMutableString *str2 = str1;  //不可变
    //自己的创建方法
    NSMutableString *str2 = [[NSMutableString alloc] initWithCapacity:30];
    
    NSLog(@"%lu",[str2 length]);
    
    NSMutableString *str3 = [[NSMutableString alloc] init];

    
    
    
    NSMutableString *str4 = [NSMutableString string];
    //len = 0
    NSLog(@"%@",str);
}

void NSMutableString_Operator_func(void)
{
    //增  删  改  rangeOfString
    NSString *str = @"helloworld";
    NSMutableString *str1 = [[NSMutableString alloc] initWithString:str];
    
    NSLog(@"%@",str1);
    //增加
    //add   insert  append
    [str1 appendString:@"qianfeng"];
    
    [str1 appendFormat:@"%d",1000];
    //setString  会清空之前的内容
    [str1 setString:@"welcome"];
    
    [str1 insertString:@"XXXXXXX" atIndex:5];
    NSLog(@"%@",str1);
    //10  参考值
    NSMutableString *str2 = [[NSMutableString alloc] initWithCapacity:10];
    
    [str2 setString:@"qianfengsafhjsafhjahfkahflakh"];
    NSLog(@"%@",str2);
    
    //[str2 deleteCharactersInRange:NSMakeRange(0, 10)];
    //NSLog(@"%@",str2);
    
    //改  不等长替换
    [str2 replaceCharactersInRange:NSMakeRange(0, 8) withString:@"baiduXXXXX"];
    NSLog(@"%@",str2);
    
}

void oc_str_range(void)
{
    //helloworld
    //he
    //ld
    //owo
    NSString *str = @"helloworld";
    //FromIndex 从某个下表 开始   取到整个字符串的结束
    //to   开区间  不包含当前的值
    NSString *str1 = [str substringToIndex:2];
    NSLog(@"%@",str1);
    
    NSString *str2 = [str substringFromIndex:8];
    NSLog(@"%@",str2);
    
    NSString *str3 = [str substringFromIndex:4];
    NSString *str4 = [str3 substringToIndex:3];
    NSLog(@"%@",str4);
    
    //owo
    //NSRange rang = {4,3};
    //NSMakeRange
    NSString *str5 = [str substringWithRange:NSMakeRange(4, 3)];
    NSLog(@"%@",str5);
    
    
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        oc_str_range();
        
    }
    return 0;
}

