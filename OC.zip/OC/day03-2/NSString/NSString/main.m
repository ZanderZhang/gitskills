//
//  main.m
//  NSString
//
//  Created by lcy on 14/11/12.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

struct Car
{
    //黑色  1   白色  2;
};

//枚举
enum {
    BLACK = 100,  //100
    WHITE   //+1
};
//165  170  175  180
//BLACK  WhITE

//M

#import <Foundation/Foundation.h>

void oc_and_c_string(void)
{
    char *str = "hello world";  //'\0'  NULL 0
    NSString *oc_str = @"hello world";  //字符串对象 '\0'
    
    NSLog(@"%s",str); //puts
    //%@  专门输出oc对象
    NSLog(@"%@",oc_str);
    
    //c ---> oc
    //ascii              //1
    //中  ---->  GBXXX   //2
    //日本
    //语言的国际化  --->  unicode
    //UTF-8  1  2  4
    //UTF-16    2
    //UTF-32   4
    //1    2   4
    //UTF-8
    //-   alloc  init
    NSString *str1 = [[NSString alloc] initWithCString:"qianfeng" encoding:NSUTF8StringEncoding];
    
    NSString *str2 = [[NSString alloc] initWithUTF8String:"中国"];
    
    //+ string  不需要alloc
    NSString *str3 = [NSString stringWithCString:"qianfeng" encoding:NSUTF8StringEncoding];
    
    NSString *str4 = [NSString stringWithUTF8String:"中国"];
    
    //oc --> c
    //-
    const char *str5 = [oc_str UTF8String];
    //str5
    
    NSLog(@"str1 = %s",str5);
}

void create_oc_string(void)
{
    //
    NSString *str = @"hello";
    //- 使用已有的OC字符串对象 创建对象
    NSString *str1 = [[NSString alloc] initWithString:str];
    NSLog(@"%@",str1);
    NSString *str2 = [NSString stringWithString:str];
    NSLog(@"%@",str2);
    
    NSString *str3 = [[NSString alloc] initWithFormat:@"%@ %d:%d:%d",str,11,59,59];
    NSLog(@"%@",str3);
    NSString *str4 = [NSString stringWithFormat:@"%d:%d:%d",11,59,59];
    //www.baidu.com?q=10&cnt=10
    //"1.jpg" "2.jpg" ... "100.jpg"
    str4 = [NSString stringWithFormat:@"www.baidu.com?q=%d&cnt=%d",11,59];
    
    for (NSInteger i = 0; i < 100; i++) {
        str4 = [NSString stringWithFormat:@"%ld.jpg",i+1];
         NSLog(@"%@",str4);
    }
    NSLog(@"%@",str4);
}

void oc_string_func(void)
{
    //sizeof
    //char *str1 = "hello"; //str1[0];
    NSString *str = @"helloworld";
    NSString *str1 = @"helloworld";
    NSLog(@"%p %p",str,str1);  //优化 指向同一个地址
    //strlen
    NSUInteger len = [str length];
    NSLog(@"%lu",len);
    //unicode
    unichar c = [str characterAtIndex:0];
    //%C   unichar
    NSLog(@"%C",c);
    //strcmp
    //==  不能
    //NSLog(@"%d",str == str1);  //比较地址
    NSLog(@"%d",[str isEqualToString:str1]);
    /*
    typedef NS_ENUM(NSInteger, NSComparisonResult) {NSOrderedAscending = -1L,  <
        NSOrderedSame,   //0   ==
        NSOrderedDescending}; //1  >
     */
    NSComparisonResult ret = [str compare:str1];
    if(ret == NSOrderedAscending)
    {
        NSLog(@"str < str1");
    }
    else if(ret == NSOrderedDescending)
    {
        NSLog(@"str > str1");
    }
    else if(str != nil && str1 != nil && ret == NSOrderedSame)
    {
        NSLog(@"str == str1");
    }
    //strstr
    NSString *str2 = @"abc1";
    NSString *str3 = nil;
    /*
     typedef struct _NSRange {
        NSUInteger location;  //位置
        NSUInteger length;    //长度
     } NSRange;
     */
    NSRange rang = [str3 rangeOfString:str2];
    if(rang.location == NSNotFound)
    {
        NSLog(@"not found");
    }
    else
    {
        NSLog(@"%ld %ld",rang.location,rang.length);
    }
    //-1L
    //NSNotFound
    //strtok
    //内存    数据做持久化 ---->  硬盘
    //写文件
    [str3 writeToFile:@"/Users/lcy/Desktop/test" atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    //读文件
    NSString *str4 = nil;
    str4 = [NSString stringWithContentsOfFile:@"/Users/lcy/Desktop/test" encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"%@",str4);
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        oc_string_func();
    }
    return 0;
}

