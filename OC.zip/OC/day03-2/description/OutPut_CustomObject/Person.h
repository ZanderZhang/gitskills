//
//  Person.h
//  OutPut_CustomObject
//
//  Created by lcy on 14/11/12.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{@public
    NSString *_name;
    NSInteger _age;
}
//init
-(id)initWithName:(NSString *)name andAge:(NSInteger)age;

//如果要输出自己对象的格式   自己实现 description
//-(NSString *)description;
-(void)show;
@end
