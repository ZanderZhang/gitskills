//
//  Person.m
//  OutPut_CustomObject
//
//  Created by lcy on 14/11/12.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

-(id)initWithName:(NSString *)name andAge:(NSInteger)age
{
    self = [super init];
    if(self)
    {
        _name = name;
        _age = age;
    }
    return self;
}
-(void)show;
{
    NSLog(@"%ld%ld",_name,_age);
}

////-(NSString *)description
//{
//    //name:zhangsan age:20
//    return [NSString stringWithFormat:@"name:%@ age:%ld",_name,_age];
//}


@end
