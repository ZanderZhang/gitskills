//
//  main.m
//  OutPut_CustomObject
//
//  Created by lcy on 14/11/12.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
       NSString *name = @"zhangsan";
        // insert code here...
        Person *p = [[Person alloc] initWithName:name andAge:20];
        
        //%@
       // NSLog(@"%@",name);
        
        //%@ <类名:地址>   调用一个方法description
       // NSLog(@"%@",p);
        [p show];
        
    }
    return 0;
}

