//
//  main.m
//  NSArray
//
//  Created by lcy on 14/11/13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Coder.h"
#import "Painter.h"
/*
    NSString  *str = @"123";
    NSMutableString *str = @"123";  //不可变
    NSMutableString *str1 = [NSMutableString alloc] init];
    str1 = @"123"; //不可变
 
    // + - 
    alloc  init
    string
    str != nil;
    str compare:str1   NSOrderSame  == 0
 
    @"中123"; 5
 
 */


void string(void)
{
    NSString *str = @"When I was young, I loved a girl on neighbor class.";
    NSString *str1 = @"teacher,I rather teaching tje students";
    
    NSString *str2 = @"Welcome to Qianfeng";
    NSMutableString *str3 = [NSMutableString stringWithString:str2];
    NSRange range = [str2 rangeOfString:@"to"];
    
    [str3 deleteCharactersInRange:range];
    NSLog(@"%@",str3);
    
    [str3 insertString:@"hello" atIndex:range.location];
    NSLog(@"%@",str3);
    
    //setString
    //appendString
    //@""   空串  != nil(空格)
    [str3 setString:@""];
    NSLog(@"%@",str3);
    
    [str3 appendString:@"123"];
    NSLog(@"%@",str3);
    
    NSMutableString *str4 = [[NSMutableString alloc] initWithString:str];
    
    NSRange range1 = [str4 rangeOfString:@"young"];
    NSRange range2 = [str4 rangeOfString:@"girl"];
    
    [str4 replaceCharactersInRange:NSMakeRange(range1.location, range2.location - range1.location + range2.length) withString:str1];
    NSLog(@"%@",str4);
}

void create_NSArray(void)
{
    //int arr[10] = {1,2,0,3,4};  基本数据类型
    //oc的数组 存储的必须是oc的对象
    //NSObject *
    //-
    NSArray *arr = [[NSArray alloc] initWithObjects:@"hello",@"123", nil];
    
    //对象   %@
    NSLog(@"%@",arr);  // ---> description
    NSLog(@"%lu",[arr count]);
    
    //+  array
    NSArray *arr1 = [NSArray arrayWithObjects:@"hello",@"123", nil];
    NSLog(@"%@",arr1);
    
    //arrayWithArray   使用数组中的对象 来创建数组对象
    NSArray *arr2 = [[NSArray alloc] initWithArray:arr1];
    NSLog(@"%@",arr2);
    NSLog(@"%lu",[arr2 count]);
    
    //使用数组对象 作为数组的 元素
    NSArray *arr3 = [NSArray arrayWithObject:arr2];
    NSLog(@"%@",arr3);
    NSLog(@"%lu",[arr3 count]);
}

void c_and_oc_arr(void)
{
    int arr[10] = {1,2,3,4};
    //oc的数组 存储的必须是oc的对象 不能直接存储 基本数据类型
    //C语言的数组 可以存储任意数据类型
    //NSArray *arr = nil;
    //@"hello" @"123"
    //char *str[10];  指针数组
    NSString *arr1[10] = {@"hello",@"213"};  //10 个 NSString *
    //char *str[10] = {"zhangfei",....};
    //1 2 3 4
    //NSNumber  //基本数据类型  工具
    //float
    NSNumber *num = [NSNumber numberWithInt:1];
    NSArray *arr3 = [NSArray arrayWithObjects:num, nil];

    int value = [num intValue];
    NSLog(@"%d",value);
}

void NSArray_func(void)
{
    //length
    //count
    //创建数组的特殊写法 hel
    NSString *str = @"hello"; //strchr
    //str characterAtIndex:<#(NSUInteger)#>
    //也不需要跟nil
    NSArray *arr = @[@"hello",@"sdfhkashf",@"123",@"456"];
    NSLog(@"%lu",[arr count]);
    
    NSLog(@"%@",[arr objectAtIndex:0]);
    //c 使用下标 oc 为了兼容c 也可以使用下表
    NSLog(@"%@",arr[0]);
    //取数组的最后一个元素
    NSLog(@"%@",[arr lastObject]);
    //判断是否包含 该元素
    NSLog(@"%d",[arr containsObject:@"123"]);
    //返回该对象 在数组中出现的下表
    NSLog(@"%ld",[arr indexOfObject:@"123"]);
    
    //
    NSArray *arr1 = [arr subarrayWithRange:NSMakeRange(0, 2)];
    NSLog(@"%@",arr1);
    
    //NSIndexSet
    NSMutableIndexSet *indexSet = [NSMutableIndexSet indexSet];
    [indexSet addIndex:0];
    [indexSet addIndex:1];
    [indexSet addIndex:3];
    NSArray *arr2 = [arr objectsAtIndexes:indexSet];

    NSLog(@"%@",arr2);
    
    //.exe
    //.txt
    //.plist   xml
    [arr2 writeToFile:@"/Users/lcy/Desktop/test.plist" atomically:YES];
    
    NSArray *str3 = [NSArray arrayWithContentsOfFile:@"/Users/lcy/Desktop/test.plist"];
    NSLog(@"str3 = %@",str3);
    
//    for (NSInteger i = 0; i < [arr count]; i++) {
//        if(i == 0)
//        {
//            str1 = arr[i];
//        }
//        else if(i == 3)
//        {
//            str2 = arr[i];
//        }
//    }
//    
//    NSArray *arr2 = [NSArray arrayWithObjects:str1,str2, nil];
}

void travel_arr(void)
{
    NSArray *arr1 = @[@"456"];
    NSArray *arr = @[@"hello",@"sdfhkashf",@"123",@"456",arr1];
    
    //下标法
    for (NSInteger i = [arr count] - 1; i >= 0; i--) {
        NSLog(@"%@",arr[i]);
    }
    //枚举器法
    //枚举器的对象  由数组本身提供
    //objectEnumerator        正序枚举器.
    //reverseObjectEnumerator 逆序枚举器
    NSEnumerator *enumertaor = [arr reverseObjectEnumerator];
    id obj = nil;
    while (obj = [enumertaor nextObject]) {
        NSLog(@"enum = %@",obj);
    }
    
    //快速枚举
    //forin
    for (NSString *obj in arr) {
        NSLog(@"%@",obj);
    }
}

void add_custom_object_to_array(void)
{
    Coder *c = [[Coder alloc] init];
    Painter *p = [[Painter alloc] init];
    NSArray *arr = @[p,c];  //{1,2}
    //确定某个元素 是要找的对象
    //isKindOfClass  作用  判断某个对象 是不是属于某个类的对象(或者子类)
    //类的对象 obj
    //[Coder class] 类对象  就是获取当前类.
    //forin 的应用。
    for (id obj in arr) {
        if([obj isKindOfClass:[Coder class]])//(1==1)
        {
            [obj myCode];
        }
        else if([obj isKindOfClass:[Painter class]])
        {
            [obj paint];
        }
    }
    
  //  NSLog(@"%@",arr);
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        add_custom_object_to_array();
        
    }
    return 0;
}

