//
//  main.m
//  NSMutableArray
//
//  Created by lcy on 14/11/13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

void create_NSMutableArray(void)
{
    //NSMutableArray  NSArray
    //int arr[30] = {0};
    NSMutableArray *arr = [[NSMutableArray alloc] initWithCapacity:30];
    NSLog(@"%ld",[arr count]);
    
    NSMutableArray *arr1 = [NSMutableArray arrayWithCapacity:30];
    
    NSMutableArray *arr2 = [NSMutableArray array];
    //count  0
    
    NSMutableArray *arr3 = [[NSMutableArray alloc] init];
}

void NSMutableArray_func(void)
{
    
    //增  删  改
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    //  3     7
    NSArray *arr1 = @[@"hello",@"123"];
    
//    [arr addObject:@"hello"];
//    [arr addObject:@"123"];
//    10
    for(NSInteger i = 0;i < 10;i++)
    {
        NSString  *str = [NSString stringWithFormat:@"hello%ld",i];
        [arr addObject:str];
    }
    NSLog(@"%@",arr);
    [arr addObjectsFromArray:arr1];
//    NSLog(@"%@",arr);
    [arr insertObject:@"qianfeng" atIndex:0];
    NSLog(@"%@",arr); // \U
    //要插入的数组元素个数 要和下标个数 对应
    NSMutableIndexSet *index = [NSMutableIndexSet indexSet];
    [index addIndex:3];
    [index addIndex:7];
    [arr insertObjects:arr1 atIndexes:index];
    
    NSLog(@"%@",arr);

    //删除
    //删除所有
    //[arr removeAllObjects];
    //删除最后一个
    //[arr removeLastObject];
    //删除指定的对象  有就删  没有 算了
    //[arr removeObject:@"123"];
    //在制定的范围内删除指定的元素
    [arr removeObject:@"123" inRange:NSMakeRange(0, 10)];
    //删除指定下标的对象
    [arr removeObjectAtIndex:0];
    NSMutableIndexSet *indexSet = [NSMutableIndexSet indexSet];
    [indexSet addIndex:0];
    [indexSet addIndex:1];
    [arr removeObjectsAtIndexes:indexSet];
    NSArray *arr2 = @[@"hello7",@"welcome"];
    //删除两个数组中相同的元素
    [arr removeObjectsInArray:arr2];
    [arr removeObjectsInRange:NSMakeRange(1, 6)];
    NSLog(@"%@",arr);
    
    //修改
    [arr replaceObjectAtIndex:0 withObject:@"XXXXXX"];
//    arr replaceObjectsAtIndexes:<#(NSIndexSet *)#> withObjects:<#(NSArray *)#>
    //逆序
    //排序
    [arr exchangeObjectAtIndex:0 withObjectAtIndex:3];
    //@"1",@"2",@"3",@"4",@"5"
    //逆序
    //升序 排序
    NSLog(@"%@",arr);
}

void array_reverse(void)//逆序输出
{
    NSMutableArray *arr = [NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
    for (NSInteger i = 0; i < [arr count] / 2; i++) {
        [arr exchangeObjectAtIndex:i withObjectAtIndex:[arr count] - i - 1];
    }
    
    NSLog(@"%@",arr);
    
}

void array_sort(void)//冒泡排序
{
    NSMutableArray *arr = [NSMutableArray arrayWithObjects:@"safa1",@"asfasgag2",@"jkljla3",@"4safas",@"5uiouo", nil];
    //i * j
    for (NSInteger i = 0; i < [arr count]; i++) {
        for (NSInteger j = 0; j < [arr count] - i - 1; j++) {
            NSString *str = arr[j];
            NSString *str1 = arr[j+1];
    
            if([str compare:str1] == NSOrderedAscending)
            {
                [arr exchangeObjectAtIndex:j withObjectAtIndex:j+1];
            }
        }
    }
    NSLog(@"%@",arr);
}

////函数指针
//typedef int INT;
////先定义一个该类型的变量 然后前面加上typedef
//typedef void (*pfunc)(void);
//typedef void (^BLOCK)(void);
//void test(pfunc func)
//{
//    func();
//}
//
void func(void)
{
    NSLog(@"func");
}

void test1(void (^block)(void))
{
    block();
}

//比较规则
NSInteger myCompare(id obj1,id obj2,void *p)
{
    return -[obj1 compare:obj2];
}




//函数指针
void system_sort(void)
{
    NSMutableArray *arr = [NSMutableArray arrayWithObjects:@"1234",@"243",@"367676",@"4344535",@"5",nil];
    //[arr sortUsingFunction:myCompare context:nil];
    
//    [arr sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
//        return -[obj1 compare:obj2];
//    }];
//    //根据字符串的长度 排序
    //降序
    //字符串  compare
    //person
    //arr sortedArrayUsingFunction:(NSInteger (*)(__strong id, __strong id, void *)) context:(void *) hint:(NSData *)
    //void (*pfunc)(void);  //指针  int *p;
    //pfunc = func;
    NSLog(@"%@",arr);
    
    //test(func);
    //block
    void (*pfunc)(void) = func;  //--->
//    void (^myBlock)(void) = ^{
//        NSLog(@"abc");
//    };
    
    test1(^{
        NSLog(@"abc");
    });
    //返回值  (^block名)(参数列表) = ^[返回值(参数列表)]{};
    //myBlock();
    //sum
    //int sum(int a,int b);  10 + 20
    int (^sum)(int a,int b) = ^int(int a,int b){
        return a+b;
    };
    int ret = sum(10,20);
    NSLog(@"%d",ret);
    
 }


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        system_sort();
        NSMutableArray *arr=[NSMutableArray arrayWithObjects:@"1",@"0",@"2", nil];
        [arr sortUsingSelector:@selector(compare:)];
        NSLog(@"%@",arr);
        NSString *str=@"Hello world abc";
        NSMutableString *str1=[NSMutableString stringWithString:str];
        NSArray *str1=ns
    }
    return 0;
}

