//
//  main.m
//  array_sort
//
//  Created by lcy on 14/11/13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

//甲
int compare(int a,int b)
{
    if(a < b)
    {
        return 1;
    }
    return -1;
}

//乙
int compare1(int a,int b)
{
    if(a < b)
    {
        return -1;
    }
    return 1;
}
//block
//回调
void mySort(int *arr,int len,int (*compare)(int a,int b))
{
    for (int i = 0; i < len; i++) {
        for (int j = 0; j < len - i -1; j++) {
            if(compare(arr[j],arr[j+1]) == 1)
            {
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        //char *str[10] = {"zhangfei","guanyu"};
        int arr[] = {12,343,45,46,5,76,7,6,87,9};
        int len = sizeof(arr) / sizeof(arr[0]);
        
        mySort(arr, len,compare);
        
        for (NSInteger i = 0; i < len; i++) {
            printf("%d ",arr[i]);
        }
        printf("\n");
        
//        
//        mySort(arr, len,compare1);
//        
//        for (NSInteger i = 0; i < len; i++) {
//            printf("%d ",arr[i]);
//        }
//        printf("\n");
    }
    return 0;
}

