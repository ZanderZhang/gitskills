//
//  Coder.m
//  NSArray
//
//  Created by lcy on 14/11/13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Coder.h"

@implementation Coder
//NSStringFromSelector(_cmd) 打印方法名
-(void)myCode
{
    //NSLog(@"code");
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

@end
