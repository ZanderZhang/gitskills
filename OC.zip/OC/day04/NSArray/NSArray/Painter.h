//
//  Painter.h
//  NSArray
//
//  Created by lcy on 14/11/13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Painter : NSObject
-(void)paint;
@end
