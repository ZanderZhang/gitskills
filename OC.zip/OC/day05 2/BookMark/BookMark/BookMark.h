//
//  BookMark.h
//  BookMark
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "History.h"
#import "Site.h"
@interface BookMark : NSObject
{
    //保存 书签的内容
    NSMutableDictionary *_dic;
    
    //管理历史记录
    History *_his;
    
    //书签的数据模型 用来管理书签的内容
    Site *_site;
}

//init
// 初始化 字典 和 历史记录的对象

//增加书签的方法
//初始化  _site对象  并且把_site增加到字典中

//打开网址的方法  根据标题
//找到 _his 增加历史记录中

//显示所有书签的方法
//遍历 _dic中的内容

//显示历史记录的方法
//让_his 来显示历史记录

@end
