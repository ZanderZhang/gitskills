//
//  History.h
//  BookMark
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface History : NSObject
{
    //字典  保存 历史记录的信息
    NSMutableDictionary *_hisDic;
}

//init
//初始化历史记录的字典

//增加历史记录的方法
//把传进来的网址对象 放到 历史记录的字典中

//显示his的字典

@end
