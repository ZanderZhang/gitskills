//
//  Site.h
//  BookMark
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//model  1.构造函数
//2. 访问器和设置器
@interface Site : NSObject
{
    NSString *_title;
    NSString *_content;
}

@end
