//
//  main.m
//  BookMark
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BookMark.h"
#define N (10)
void qqFriend(void)
{
    // insert code here...
    //  NSLog(@"Hello, World!");
    NSString *str1=@"myclassmate1";
    NSString *str2=@"myclassmate2";
    NSString *str3=@"myclassmate3";
    //  NSLog(@"\n%@\n%@\n%@",str1,str2,str3);
    NSMutableArray *arr1=[NSMutableArray array];
    for (NSInteger i=0; i<N; i++) {
        NSString *s=[NSString stringWithFormat:@"zhang1%ld",i];
        [arr1 addObject:s];
    }
    // NSLog(@"%@",arr1);
    NSMutableArray *arr2=[NSMutableArray array];
    for (NSInteger i=0; i<N; i++) {
        NSString *s=[NSString stringWithFormat:@"zhang2%ld",i];
        [arr2 addObject:s];
    }
    // NSLog(@"%@",arr1);
    NSMutableArray *arr3=[NSMutableArray array];
    for (NSInteger i=0; i<N; i++) {
        NSString *s=[NSString stringWithFormat:@"zhang3%ld",i];
        [arr3 addObject:s];
    }
    // NSLog(@"%@",arr1);
    NSDictionary *dic1=[NSDictionary dictionaryWithObject:@[arr1] forKey:str1];
    //NSLog(@"%@",dic1);
    NSDictionary *dic2=[NSDictionary dictionaryWithObject:@[arr2] forKey:str2];
    NSDictionary *dic3=[NSDictionary dictionaryWithObject:@[arr3] forKey:str3];
    NSArray *arr=@[dic1,dic2,dic3];
    NSLog(@"%@",arr);
}
int main(int argc, const char * argv[])
{

    @autoreleasepool {
        qqFriend();
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
           }
    return 0;
}

