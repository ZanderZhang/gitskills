//
//  Lrc.h
//  Lrc
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Lrc : NSObject
{
    NSMutableArray *_time;
    NSMutableArray *_lrc;
}

//-(id)init;
-(void)paserLrc:(NSString *)lrc;
-(void)show;

@end
