//
//  Lrc.m
//  Lrc
///Users/qianfeng/Downloads/day05 3/Lrc/Lrc.xcodeproj/Users/qianfeng/Downloads/day05 3/Lrc/Lrc.xcodeproj
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights /Users/qianfeng/Downloads/day05 3/Lrc/Lrc/main.mreserved.
///Users/qianfeng/Downloads/day05 3/Lrc/Lrc/main.m
///Users/qianfeng/Downloads/day05 3/Lrc/Lrc.xcodeproj
#import "Lrc.h"

@implementation Lrc

- (id)init
{
    self = [super init];
    if (self) {
        _time = [[NSMutableArray alloc] init];
        _lrc = [[NSMutableArray alloc] init];
    }
    return self;
}

-(void)paserLrc:(NSString *)lrc

{
    NSArray *arr = [lrc componentsSeparatedByString:@"["];
    NSLog(@"%@",arr);
    
    for(NSInteger i = 3;i < [arr count];i++)
    {
        
     
            NSString *str = arr[i];
            NSArray *strArr = [str componentsSeparatedByString:@"]"];
            
            [_time addObject:strArr[0]];
        [_lrc addObject:strArr[1]];
        
    
    }
}
-(void)show

{
    NSLog(@"%@",_time);
    NSLog(@"%@",[_lrc componentsJoinedByString:@""]);
}



@end
