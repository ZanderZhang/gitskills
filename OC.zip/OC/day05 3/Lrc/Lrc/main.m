//
//  main.m
//  Lrc
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Lrc.h"
//arr ---> 3 个 dic ---> 1key  ---> 数组  3元素
//我的好友
//  zhangsan
//  lisi
//  ...N

//我的同事
//  zhangsan
//  lisi
//  ...
//我的同学
//  zhangsan
//  lisi
//  ...

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        
        NSString *str = [NSString stringWithContentsOfFile:@"/Users/qianfeng/Desktop/情非得已.lrc" encoding:NSUTF8StringEncoding error:nil];
        NSLog(@"%@",str);
        
        Lrc *l = [[Lrc alloc] init];
        [l paserLrc:str];
        [l show];
        
    
    }
    return 0;
}

