//
//  main.m
//  NSDictionary
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

void create_dic(void)
{
    //dic  键    ----   值
    //guest
    //新华字典   查找    中
    //根据索引   找到值
    //数组       1. 排序      二分法查找
    //哈希表     给一个唯一的索引    哈希算法   数据库
    
    //通讯录
    //姓名  ---  号码
    //数组 0  姓名  1  号码
    
    //字典是一个无序
    //不可变字典  1   --- > zhangsan
    NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:@"zhangsan",@"1",@"lisi",@"2",@"wangwu",@"3",nil];
    
    NSLog(@"%@",dic);
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:@"zhangsan",@"1",@"lisi",@"2", nil];
    NSLog(@"%@",dic1);

    NSDictionary *dic2 = @{@"1":@"zhangsan",@"2":@"lisi"};
    NSLog(@"%@",dic2);
    
    NSDictionary *dic3 = [NSDictionary dictionaryWithDictionary:dic2];
    
    [dic3 writeToFile:@"/Users/lcy/Desktop/test.plist" atomically:YES];
    
}

void NSDictionary_func(void)
{
    NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:@"zhangsan",@"hello",@"lisi",@"2",@"wangwu",@"3",nil];
    //objectAtIndex
    NSLog(@"%@",[dic objectForKey:@"hello"]);
    //arr[0]  dic[key]
    NSLog(@"%@",dic[@"hello"]);
    //取到字典里的所有的key
    NSArray *keys = [dic allKeys];
    for (NSString *key in keys) {
        NSLog(@"%@",dic[key]);
    }
    NSArray *values = [dic allValues];
    //枚举器
    //objectEnumerator  值的枚举器
    //keyEnumerator     键的枚举器
    NSEnumerator *enumerator = [dic keyEnumerator];
    id obj = nil;
    while(obj = [enumerator nextObject])
    {
        NSLog(@"%@",obj);
    }
    //快速枚举  取到的字典的键
    for (NSString *obj in dic) {
        NSLog(@"%@ ---> %@",obj,dic[obj]);
    }
}

void NSMutableDictionary_create(void)
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:30]; //0
    //array
    //string
    //dictonary
    NSMutableDictionary *dic1 = [NSMutableDictionary dictionary];
    
    NSMutableDictionary *dic2 = [[NSMutableDictionary alloc] init];
    //增加 @"zhangsan":@"1";
    [dic2 setObject:@"zhangsan" forKey:@"1"];
    [dic2 setObject:@"lisi" forKey:@"2"];
    NSLog(@"%@",dic2);
    //删除
    //删除的时键值对
    //[dic2 removeAllObjects];
    [dic2 removeObjectForKey:@"1"];
    //dic2 removeObjectsForKeys:(NSArray *)
    NSLog(@"%@",dic2);
    //修改
    //如果使用setObject 设置的键 之前已经存在  相当于修改对应的值.
    //[dic2 setObject:@"wangwu" forKey:@"1"];
   // NSLog(@"%@",dic2);
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        NSMutableDictionary_create();
    }
    return 0;
}

