//
//  Person.h
//  NSMutableArray
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    NSString *_name;
    NSInteger _age;
}

-(void)setName:(NSString *)name;
-(void)setAge:(NSInteger)age;

-(NSInteger)personCompare:(Person *)per;

@end
