//
//  Person.m
//  NSMutableArray
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

-(void)setName:(NSString *)name
{
    _name = name;
}

-(void)setAge:(NSInteger)age
{
    _age = age;
}

//name 升序
//age  升序
-(NSInteger)personCompare:(Person *)per
{
    if([self->_name compare:per->_name] == NSOrderedAscending)
    {
        return NSOrderedAscending;
    }
    else if([self->_name compare:per->_name] == NSOrderedDescending)
    {
        return NSOrderedDescending;
    }
    else
    {
        if(self->_age < per->_age)
        {
            return NSOrderedAscending;
        }
        else
        {
            return NSOrderedDescending;
        }
    }
}

-(NSString *)description
{
    return [NSString stringWithFormat:@"name:%@ age:%ld",_name,_age];
}

@end
