//
//  main.m
//  NSMutableArray
//
//  Created by lcy on 14/11/14.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NSInteger (*pfunc)(id obj1,id obj2,void *p);
//int *
//int [10]
typedef int *p;
typedef int arr[10];

NSInteger myCompare(id obj1,id obj2,void *p)
{
    //NSLog(@"%d",*(int *)p);
    return [obj1 compare:obj2];
}

void NSMutableArray_sort(void)
{
    //NSArray
    //NSMutableArray
    NSMutableArray *arr = [NSMutableArray arrayWithObjects:@"One",@"Two",@"Three",@"Four",@"Five",nil];
    
    //[arr sortUsingFunction:myCompare context:&a];
    //NSArray *sortArr = [arr sortedArrayUsingFunction:myCompare context:nil];
    
    //block
    //返回值 (^名字)(参数列表) = ^[返回值(参数列表)]{};
    __block int a = 100;
    if(1 < 2)
    {
        NSLog(@"%d",a);
        a = 1000;
    }
    
    void (^block)(void) = ^{
        //block 可以访问 局部变量
        NSLog(@"%d",a);
        //block 不允许修改一个局部变量的值.
        //要修改的话,必须在该变量声明的地方加上__block
        a = 10000;
        NSLog(@"%d",a);
    };
    
    block();
//    [arr sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
//        return -[obj1 compare:obj2];
//    }];
    NSLog(@"%@",arr);
    //NSLog(@"%@",NSStringFromSelector(_cmd));
    //SEL    //作用  gcc   a.out ----> n函数
    //int sum(int a,int b);  link
    //_int_sum_XXXX
    
    //int sum(int a,int b);
    //数字
    //@selector(方法名)  如果方法名一样  生成的ID也是一样的.
    //SEL sel = @selector(compare:);
    
    NSString *str = @"hello";
    NSString *str1 = @"hello";
    
    //performSelector 执行selector  withObject 用来给selector 传参数的.
    //[str performSelector:sel withObject:str1];
    //默认排序  升序    函数指针
    [arr sortUsingSelector:@selector(compare:)];
    NSLog(@"%@",arr);
}

//自定义对象的排序
//Person  name  age
//name 升序   age 升序
#import "Person.h"
//0 - 100

void sort_custom_object(void)//*****重点
{
    NSMutableArray *personArr = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < 100; i++) {
        Person *p = [[Person alloc] init];
        
        [p setName:[NSString stringWithFormat:@"zhangsan%d",arc4random() % 10]];
        [p setAge:arc4random() % 10 + 1];
        [personArr addObject:p];
    }
    
//    [personArr sortUsingComparator:^NSComparisonResult(id obj1, id obj2){
//        return [obj1 personCompare:obj2];
//    }];
    
    [personArr sortUsingSelector:@selector(personCompare:)];
    
    NSLog(@"%@",personArr);
}

void str_strtok_and_strcat(void)
{
    //char str[] = "hello world abc";  //" " 崩溃
    //" "  hello world abc
    //" w" hello orld abc
    NSString *str = @"hello world abc";
    NSMutableString *str1 = [NSMutableString stringWithString:str];
    //oc componentsSeparatedByString 按整体来分割
    NSArray *arr = [str1 componentsSeparatedByString:@" w"];//***NSArray*
    NSLog(@"%@",arr);
    //componentsSeparatedByCharactersInSet 按单个的字符来分割
    //@""  空串  当分割的字符再当前要分割的字符串的第一个位置的时候 会出现
    NSCharacterSet *charSet = [NSCharacterSet characterSetWithCharactersInString:@" w"];
    NSArray *arr1 = [str1 componentsSeparatedByCharactersInSet:charSet];
    NSLog(@"%@",arr1);
    NSArray *arr2 = @[@"hello",@"qianfeng"];
    //连接字符串
    NSString *str10 = [arr2 componentsJoinedByString:@"XXXXXXX"];//**NSString*
    NSLog(@"%@",str10);
    
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        int b = 10;
        p a = &b;
        
        arr brr; //brr含有是个元素的数组
        str_strtok_and_strcat();
    }
    return 0;
}

