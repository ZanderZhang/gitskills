//
//  Person.h
//  Person
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    NSString *_name;
    NSInteger _age;
    BOOL _gender;
}
//@property (参数) NSString *name;
@property (nonatomic,readwrite) NSString *name;
@property (nonatomic,readonly) NSInteger age;
@property (nonatomic,getter = isGender,setter = test:) BOOL isGender; //isGender

//setGender
//gender
//BOOL 类型  一般会自己实现get 和 setter方法
//nonatomic
//-(void)setName:(NSString *)name
//{
//   _name = name;
//}

//带参数的用
//atomic    原子性  ---> 多线程
//nonatomic 非原子性  不需要加锁
//nonatomic atomic    // 默认  atomic
//readonly  只提供 getter方法
//readonly  readwrite  //默认  readwrite

//设置自己的getter和 setter方法
//getter  setter    setXxxx    xxxx
//需要使用点语法   并且还想自定义 getter setter

//retain assgin

-(void)test:(BOOL)gender;
-(BOOL)isGender;


@end
