//
//  Person.m
//  Person
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person
@synthesize name = _name;
@synthesize age = _age;

-(void)test:(BOOL)gender
{
    _gender = gender;
}

-(BOOL)isGender
{
    return _gender;
}



//atomic

@end
