//
//  main.m
//  Person
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        Person *p = [[Person alloc] init];
        //age
        //
        p.name = @"zhangsan";
        
        NSLog(@"%@",p.name);
        
        p.isGender = NO;
        NSLog(@"%d",p.isGender);
        
    }
    return 0;
}

