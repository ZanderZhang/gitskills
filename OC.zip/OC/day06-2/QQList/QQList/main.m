//
//  main.m
//  QQList
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BookMark.h"
/*
    array  --->  dic ----> value  array
    我的好友
        我的好友1
        我的好友2
        我的好友3
    我的同学
        我的好友1
 */

void qqlist(void)
{
    NSArray *arr = @[@"friend",@"class",@"coll"];
    NSMutableArray *qq = [[NSMutableArray alloc] init];
    for (NSString *str in arr)
    {
        NSMutableArray *mem = [[NSMutableArray alloc] init];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        for(NSInteger i = 0 ;i < 3;i++)
        {
            NSString *name = [NSString stringWithFormat:@"%@%ld",str,i+1];
            [mem addObject:name];
        }
        [dic setObject:mem forKey:str];
        [qq addObject:dic];
    }
    NSLog(@"%@",qq);
}
void qqlists(void)
{
    NSArray *arr=@[@"my friends",@"my classmates",@"my colleagues"];
    NSMutableArray *qq=[[NSMutableArray alloc] init];
    for (NSString *str in arr) {
        NSMutableArray *mem=[[NSMutableArray alloc] init];
        NSMutableDictionary *dic=[[NSMutableDictionary alloc] init];
        for (NSInteger i=0; i<15; i+=3) {
            NSString *name=[NSString stringWithFormat:@"%@%ld",str,i];
            [mem addObject:name];
            
        }
        [dic setObject:mem forKey:str];
        [qq addObject:dic];
        
        
    }
    NSLog(@"%@",qq);
    }
    


void qqlist2(void)
{
    NSArray *arr=@[@"friends",@"class",@"colleague"];
    NSMutableArray *qq=[[NSMutableArray alloc] init];
    for (NSString *str in arr) {
        NSMutableArray *mem=[[NSMutableArray alloc] init];
        NSMutableDictionary *dic=[[NSMutableDictionary alloc] init];
        for (NSInteger i=0; i<3; i++) {
            NSString *name=[NSString stringWithFormat:@"%@%ld",str,i+1];
            [mem addObject:name];
        }
        [dic setObject:mem forKey:str];
        [qq addObject:dic];
    }
    NSLog(@"%@",qq);
}
void qqlist1(void)
{
    NSArray *arr=@[@"friend",@"class",@"coll"];
    NSMutableArray *qq=[[NSMutableArray alloc] init];
    for (NSString *str in arr) {
        NSMutableArray *mem=[[NSMutableArray alloc] init];
        NSMutableDictionary *dic=[[NSMutableDictionary alloc]init];
        for (NSInteger i=0; i<10; i++) {
            NSString *name=[NSString stringWithFormat:@"%@%ld",str,i+1];
            [mem addObject:name];
        }
        [dic setObject:mem forKey:str];
        [qq addObject:dic];
    }
    NSLog(@"%@",qq);
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
//        BookMark *mark = [[BookMark alloc] init];
//        
//        [mark addMark:@"百度" andContent:@"www.baidu.com"];
//        [mark addMark:@"谷歌" andContent:@"www.google.com"];
//        [mark showAllSites];
//
//        [mark openMark:@"百度"];
//        [mark showHistroy];
        qqlists();
    }
    return 0;
}

