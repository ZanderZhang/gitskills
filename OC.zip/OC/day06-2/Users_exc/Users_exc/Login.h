//
//  Login.h
//  Users_exc
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Login : NSObject
{
    NSString *_userName;
    NSString *_userPasswd;
}

@property NSString *userName;
@property NSString *userPasswd;

-(id)initWithUserName:(NSString *)userName andUserPasswd:(NSString *)userPasswd;

-(BOOL)LoginWithUserName:(NSString *)username andUserPasswd:(NSString *)userPasswd;

@end
