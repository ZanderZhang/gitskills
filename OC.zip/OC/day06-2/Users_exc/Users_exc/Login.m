//
//  Login.m
//  Users_exc
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Login.h"

@implementation Login
@synthesize userName = _userName;
@synthesize userPasswd = _userPasswd;

-(id)initWithUserName:(NSString *)userName andUserPasswd:(NSString *)userPasswd
{
    self = [super init];
    if(self)
    {
        _userPasswd = userPasswd;
        _userName = userName;
    }
    
    return self;
}

//判断  返回值
-(BOOL)LoginWithUserName:(NSString *)userName andUserPasswd:(NSString *)userPasswd
{
    if([_userName isEqualToString:userName] && [_userPasswd isEqualToString:userPasswd])
    {
        return YES;
    }
    return NO;
}

@end
