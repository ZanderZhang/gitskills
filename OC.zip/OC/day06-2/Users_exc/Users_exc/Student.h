//
//  Student.h
//  Users_exc
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Test.h"
//
@interface Student : NSObject
//_
@property Test *test;
@property NSString *name; 
@property NSInteger age;
@property NSInteger num;
@property NSInteger score;

-(id)init;

@end
