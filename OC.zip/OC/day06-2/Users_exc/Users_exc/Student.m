//
//  Student.m
//  Users_exc
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Student.h"

@implementation Student
- (instancetype)init
{
    self = [super init];
    if (self) {
        //_test = [[Test alloc ] init];
    }
    return self;
}
@end
