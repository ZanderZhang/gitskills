//
//  main.m
//  Users_exc
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
#import "Test.h"
#import "Login.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        Test *test = [[Test alloc] init];
        Student *s = [[Student alloc] init];
        s.name = @"zhangsan";
        s.test = test;
        NSLog(@"%@",s.name);
        
        Login *login = [[Login alloc] initWithUserName:@"qianfeng" andUserPasswd:@"123456"];
        
        if([login LoginWithUserName:@"qianfeng" andUserPasswd:@"123456"])
        {
            NSLog(@"登陆成功");
        }
        else
        {
            NSLog(@"登陆失败");
        }
    }
    return 0;
}

