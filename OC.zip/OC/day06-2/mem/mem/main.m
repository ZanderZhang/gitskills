//
//  main.m
//  mem
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

struct mem
{
    void *p;
    int count;
};

//int *test(void)
//{
//    //a
//    int a = 100;
//    return &a;
//}

//void *func(void)
//{
//    void *p = malloc(10);
//    return p;
//}

//引用计数器   NSInteger
int main(int argc, const char * argv[])
{
    @autoreleasepool {
        struct mem mem_p;
        
        mem_p.p = malloc(100); // 1
        //alloc
        mem_p.count = 1;
        
        void *q = mem_p.p;  //2
        //retain
        mem_p.count ++;
        
        void *m = mem_p.p; //3
        mem_p.count ++;
        
        //m
        mem_p.count--; // 2
        if(mem_p.count == 0)
        {
            free(mem_p.p);
        }
        m = nil;
        
        //mem_p
        mem_p.count --;   //1
        if(mem_p.count == 0)
        {
            free(mem_p.p);
        }

        //q
        mem_p.count --;  //0
        if(mem_p.count == 0)
        {
            free(mem_p.p);
        }
        
        //p = nil;
    }
    return 0;
}

