

#import <Foundation/Foundation.h>

//析构方法  ---->  构造
@interface Person : NSObject
//@property (nonatomic) NSString *name;
//@property (nonatomic) NSInteger age;
@end
