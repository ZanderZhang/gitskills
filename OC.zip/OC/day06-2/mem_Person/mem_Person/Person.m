//
//  Person.m
//  mem_Person
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

//当该对象 真正被释放的时候 就会调用该方法。
-(void)dealloc
{
    NSLog(@"person dead");
    [super dealloc];
}

@end
