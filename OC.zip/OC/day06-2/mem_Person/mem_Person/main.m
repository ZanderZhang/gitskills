//
//  main.m
//  mem_Person
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Dog.h"

int main(int argc, const char * argv[])
{
    //Person   Dog
    //Dog *dog  Person
    //set get   满足内存管理
    @autoreleasepool {
        
        
//        //alloc 默认把该对象的引用计数器 设置成 1
//        Person *p = [[Person alloc] init];
//        //retainCount  MRC
        NSLog(@"%lu",[p retainCount]); // alloc 1
//        //count++;
        
//        //retain 引用计数器 + 1
//        Person *q = [p retain];
//        [q release];  //先把之前的内容释放。
//        
//        q = [[Person alloc] init];
//        
//        [p release];
//        [q release];
//        //retain
//        //{
//        //    self.retainCount ++;
//        //    return self;
//        //}
//        NSLog(@"%lu",[p retainCount]); //2
//        
//        //p
//        //p  release作用:将对象计数器-1
//        //release
//        //{
//        //    self.retainCount --;
//        //}
//        
////        [p release];  //1
////        p = nil;
////        NSLog(@"%lu",[q retainCount]);
////        
////        [q release];
////        q = nil;
//        ///NSLog(@"%lu",[q retainCount]);
//        
//         /*
//            retainCount--;
//            if(retainCount == 0)
//            {
//                free
//            }
//        
//            if(retainCount == 1)
//            {
//                free()
//            }
//         */
//        //q = nil;
    }
    return 0;
}

