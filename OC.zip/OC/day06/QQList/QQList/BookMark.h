//
//  BookMark.h
//  QQList
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "History.h"
#import "Site.h"

@interface BookMark : NSObject
{
    //记录内容
    NSMutableDictionary *_dic;
    
    //管理历史记录
    History *_his;
    
    //数据模型
    Site *_site;
}

-(id)init;

//增加书签的方法
-(void)addMark:(NSString *)title  andContent:(NSString *)content;

//显示所有的书签
-(void)showAllSites;

//打开网址的方法
-(void)openMark:(NSString *)title;

//显示历史记录
-(void)showHistroy;

@end
