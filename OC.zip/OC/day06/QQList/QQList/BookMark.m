//
//  BookMark.m
//  QQList
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "BookMark.h"

@implementation BookMark

-(id)init
{
    self = [super init];
    if(self)
    {
        _dic = [[NSMutableDictionary alloc] init];
        _his = [[History alloc] init];
        //一个site对象
        //_site = [[Site alloc] init];
    }
    return self;
}

//MVC
-(void) addMark:(NSString *)title  andContent:(NSString *)content
{
    _site = [[Site alloc] init];
    //NSLog(@"%@",_site);
    [_site setTitle:title];
    [_site setContent:content];
    
    [_dic setObject:_site forKey:title];
}

-(void)showAllSites
{
    for (NSString *key in _dic) {
        //[_dic[key] content]  调用数据模型的get方法
        NSLog(@"%@ -----> %@",key,[_dic[key] content]);
    }
}

-(void)openMark:(NSString *)title
{
    //直接加到历史记录对象中 NSString
    [_his addHistroy:title andSite:_dic[title]];
}

-(void)showHistroy
{
    [_his showHis];
}

@end
