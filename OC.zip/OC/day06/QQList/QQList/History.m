//
//  History.m
//  QQList
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "History.h"

@implementation History

- (instancetype)init
{
    self = [super init];
    if (self) {
        _hisDic = [[NSMutableDictionary alloc] init];
    }
    return self;
}

-(void)addHistroy:(NSString *)title andSite:(Site *)site
{
    [_hisDic setObject:site forKey:title];
}

-(void)showHis
{
    for (NSString *key in _hisDic) {
        NSLog(@"his %@ -----> %@",key,[_hisDic[key] content]);
    }
}

@end
