//
//  Site.h
//  QQList
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//init
//get set
@interface Site : NSObject
{
    NSString *_title;
    NSString *_content;
}

-(void)setTitle:(NSString *)title;
-(void)setContent:(NSString *)content;

-(NSString *)content;

@end
