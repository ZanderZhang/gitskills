//
//  Site.m
//  QQList
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Site.h"

@implementation Site

-(void)setTitle:(NSString *)title
{
    _title = title;
}

-(void)setContent:(NSString *)content
{
    _content = content;
}

-(NSString *)content
{
    return _content;
}

@end
