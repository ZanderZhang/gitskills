//
//  Student.h
//  Student
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject
{
    //NSString *ID;
    //protected
    //NSString *_name;
    NSInteger _age;
    NSInteger _area; //get 自己实现
}

//property 如果属性名和实例变量名 一样  那么系统会直接使用自己的实力变量
//如果不一样   property会自动生成一个和property名字一样的变量。直接使用该变量

//property 属性类型 名字
//一般 和  实力变量名一致
//自动声明

@property NSString *name;  //代替set 和 get方法的声明 setName
//如果  直接写property  不写成员变量名 和 @synthesize  系统会自动生成一个以property名 前面+ "_" 的实例变量(_name)  并且会自动实现getter 和 setter方法。

//@property NSInteger area;
//@synthesize name = _name;
//+             -
//类的方法       对象
//不使用对象

//self     类对象   --->  判断   isKindOfClass:Class
//+    不能访问成员变量 也 不能调用-

//init   一般只有 alloc
//get set

//-(void)setName:(NSString *)name;
//-(void)setAge:(NSInteger)age;

//-(NSString *)name;
//-(NSInteger)age;

-(void)test;
@end
