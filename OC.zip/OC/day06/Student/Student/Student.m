//
//  Student.m
//  Student
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Student.h"   //malloc free

@implementation Student

//@synthesize 属性名
//1.property 变量名 如果和 实例变量名一样
//@synthesize name;  //自动实现 对应的get set方法
//2.property 变量名 如果和 实例变量名不一样
//@synthesize 属性名 = 实例变量名;  系统就不会生成一个新的实例变量
//@synthesize name = _name;
//@synthesize area = _area;

//手动实现的get 或者 set放法  和  自动的都存在  系统先调用手动实现
//-(NSInteger)area
//{
//    return _width * _height;
//}

-(void)test
{
    NSLog(@"Student %@",_name);
}



//-(void)setName:(NSString *)name
//{
//    self->name = name;
//}

//-(void)setName:(NSString *)name
//{
//    self->_name = name;
//}

//-(void)setAge:(NSInteger)age
//{
//    self->age = age;
//}

//-(NSString *)name
//{
//    return self->_name;
//}
//-(NSInteger)age
//{
//    return self->_age;
//}

@end
