//
//  main.m
//  Student
//
//  Created by lcy on 14/11/17.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"

struct Stu
{
    int a;
    int b;
};

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        struct Stu s1;
        s1.a = 10;
        s1.b = 20;
        
        Student *s = [[Student alloc] init];
        //点语法 左值   访问的是set方法。
        //[s setName:@"zhangsan"];
        s.name = @"zhangsan"; //_name = @"zhangsan"
        
        [s test];
        //右值  访问的get
        //[s name];
        NSLog(@"%@",s.name);
        [s test];
        
        
    }
    return 0;
}

