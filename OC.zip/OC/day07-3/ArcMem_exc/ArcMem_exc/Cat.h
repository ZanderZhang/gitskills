//
//  Cat.h
//  ArcMem_exc
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Tail.h"

@interface Cat : NSObject
{
    Tail *_tail;
}
@property (nonatomic,strong) Tail *tail;
//-(void)setTail:(Tail *)tail;
//-(Tail *)tail;

@end
