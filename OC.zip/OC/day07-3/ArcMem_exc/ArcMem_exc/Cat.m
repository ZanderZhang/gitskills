//
//  Cat.m
//  ArcMem_exc
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Cat.h"

@implementation Cat
@synthesize tail = _tail;

/*
 @property (retain,nonatomic) Tail *tail;
 -(void)setTail:(Tail *)tail;
 if(_tail != tail)
 {
[_tail release];
 _tail = tail retain
 }
 */

-(void)setTail:(Tail *)tail
{
    _tail = tail;
}

-(Tail *)tail
{
    return _tail;
}

@end
