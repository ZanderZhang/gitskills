//
//  Teacher.m
//  Ask
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher

-(void)ask:(Kids *)kid
{
    [kid answer];
}

@end
