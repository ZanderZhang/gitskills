//
//  main.m
//  Ask
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Kids.h"
#import "Boys.h"
#import "Girls.h"
#import "Teacher.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        
        Teacher *t = [[Teacher alloc ]init];
        
        Kids *kids1 = [[Boys alloc] init];
        Kids *kids2 = [[Girls alloc] init];
        
        [t ask:kids1];
        [t ask:kids2];
    }
    return 0;
}

