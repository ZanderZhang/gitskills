//
//  MyRect.h
//  Extend
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Shape.h"

@interface MyRect : Shape
{
    NSInteger _width;
}

-(void)setWidth:(NSInteger)width;

@end
