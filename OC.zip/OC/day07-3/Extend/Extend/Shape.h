//
//  Shape.h
//  Extend
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Shape : NSObject
{
    NSInteger _length;
    NSInteger _area;
    NSInteger _roundLength;
}

-(void)setLength:(NSInteger)length;
-(NSInteger)getArea;
-(NSInteger)getRoundLength;

@end
@interface Shape1 : NSObject
{
    NSInteger _length;
    NSInteger _area;
    NSInteger _roundLength;
}
-(void)setLength1:(NSInteger)length;
-(NSInteger)getArea;
-(NSInteger)getRoundLength;
/*
 NSInteger getRoundLength;
 NSInteger _area;
 
 
 
 
 
 *///foundation.framework


@end
