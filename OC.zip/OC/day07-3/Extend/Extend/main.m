//
//  main.m
//  Extend
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//三个特征   封装  继承  多态

//height  wegiht
//Dog
//Tiger
//Fish

//行为   吃饭  睡觉  呼吸
//基类 NSObject

//Animal 基类  父类   超类
//Dog    子类  派生类
@interface MyAnimal : NSObject
{
//@protected
//@public
//@public 或者 protected 的属性 可以被继承。
//@private  不能被继承
    NSInteger _height;
    NSInteger _weight;
}

-(void)eat;
-(void)sleep;
-(void)breath;

-(void)angry;

//看门
//%@  description

@end

@implementation MyAnimal
-(void)eat
{
    NSLog(@"Animal eat");
}

-(void)breath
{
    NSLog(@"方言"); //
}

-(void)angry
{
    NSLog(@"animal angry");
}

@end
//Dog

@interface Dog : MyAnimal
{
    //扩展
    NSString *_type;
}

-(void)test;
-(void)watchDoor;

@end

@implementation Dog

-(void)angry
{
    NSLog(@"wang wang");
}

-(void)test
{
    NSLog(@"%ld",_weight);
}

@end

@interface Tiger : MyAnimal

-(void)angry;

@end

@implementation Tiger

-(void)angry
{
    NSLog(@"eat person");
}

@end

//重写   方法要和父类完全一样
//方言
//普通话
@interface Fish : MyAnimal

-(void)swim;
-(void)breath;
@end

@implementation Fish

-(void)breath
{
    [super breath];
    NSLog(@"普通话");
}
@end
//重写  编译的时候确定*****
//多态  运行的时候确定*****
//有下列三个步骤：
//1.继承
//2.父类指向子类的指针
//MyAnimal *an = [[Dog alloc] init];
//Dog *d = [[MyAnimal alloc] init]; //必须知道  该父类就是一个子类对象
//3.重写

//参数 id  NSObject *
//返回值

//NSArray
//NSMutableArray NSArray sorted
//id  person   NSString

void beatAnimal(MyAnimal *an)
{
    [an angry];
}

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        MyAnimal *an = [[MyAnimal alloc] init];
        [an eat];
        [an breath];
        
        Dog *dog = [[Dog alloc] init];
        [dog eat];
        [dog breath];
        
        //子类重写了父类的方法  再调用该方法的时候  会调用自己的方法。
        Fish *fish = [[Fish alloc] init];
        [fish breath];
        
        MyAnimal *an1 = [[Dog alloc] init];
        MyAnimal *an2 = [[Tiger alloc] init];
        
        beatAnimal(an1);
        beatAnimal(an2);
        
        //NSArray *arr = nil;
        //arr sortedArrayUsingFunction:(NSInteger (*)(__strong id, __strong id, void *)) context:(void*)
        
        
    }
    return 0;
}

