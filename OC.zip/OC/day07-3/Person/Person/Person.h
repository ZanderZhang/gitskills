//
//  Person.h
//  Person
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//
//#include <<#header#>>
#import <Foundation/Foundation.h>
//@class name  用来导入类
#import "Car.h"
//@class Car;

@interface Person : NSObject
{
    Car *_car;
    //NSString *_name;
}

//car  的setter 方法  没有满足内存管理
@property (nonatomic,retain) Car *car;

/*
 //-(void)setCar:(Car *)car
 //{
 //    //判断设置是不是同一辆车
 //    if(_car != car)
 //    {
 //        //释放旧值.
 //        [_car release]; //-1   NULL.
 //        _car = [car retain];
 //    }
 //}
 */

//@property (nonatomic,assgin) Car *car;
/*
 //-(void)setCar:(Car *)car
 //{
 //
 //
 //        _car = car;
 //
 //}

 */
//@property (nonatomic,retain) NSInteger *age;

//-(void)setCar:(Car *)car;
//-(Car *)car;

@end
