//
//  Person.m
//  Person
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person
@synthesize car = _car;
//init;
//-(void)setCar:(Car *)car
//{
//    //判断设置是不是同一辆车
//    if(_car != car)
//    {
//        //释放旧值.
//        [_car release]; //-1   NULL.
//        _car = [car retain];
//    }
//}

-(Car *)car
{
    return _car;
}

//先调用父类[]
-(void)dealloc
{
    NSLog(@"Person dead");
    //把成员变量 release
    [_car release];
    _car = nil;
    [super dealloc];
}

@end
