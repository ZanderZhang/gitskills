//
//  main.m
//  Student
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Car.h"
//mrc  property   retain         assgin
//arc  property   strong/weak    assgin

void arc_mem(void)
{
    //ARC
    //两种指针    强指针  strong  默认
    //           弱指针  weak/unsafe_unretain
    //只要该内存 有一个 强指针指向它   该内存就不会被回收。
    //如果没有强指针指向该内存  再多的弱指针指向该内存 也会被回收
    __strong Person *p = [[Person alloc] init]; // 1
    NSLog(@"%@",p);
    __weak Person *q = p;   //retain  //2
    __weak Person *m = p;   //
    __unsafe_unretained Person *x = p;
    NSLog(@"%@ %@ %@",q,m,x);
    
    p = nil;  //release  //1
    x = nil;
    //如果没有强指针指向该内存 那么所有指向该内存的弱指针(weak) 都会被置成nil
    //如果是__unsafe_unretained  不会被置成nil.
    NSLog(@"%@ %@ %@",q,m,x);
    
    //q = nil;  //release  //0  ---> dealloc
    //出了@autoreleasepool  所有的强指针都会被置成nil
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        Person *p = [[Person alloc] init];
        Car *c = [[Car alloc] init];
        
        p.car = c;  // 2
        
        Car *c1 = [[Car alloc] init];
        p.car =c1;  //c  1   c1  2
        
        p = nil;  //c1 1
        c = nil;
        c1 = nil;
    }
    return 0;
}

