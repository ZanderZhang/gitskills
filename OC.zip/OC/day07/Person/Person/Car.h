//
//  Car.h
//  Person
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//@class Person;
//#import "Person.h"

@interface Car : NSObject
@property (nonatomic) NSInteger ID;
//{
//    Person *_per;
//}

@end
