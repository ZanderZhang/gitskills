//
//  Car.m
//  Person
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Car.h"

@implementation Car

-(void)dealloc
{
    NSLog(@"Car dead %ld",_ID);
    [super dealloc];
}

@end
