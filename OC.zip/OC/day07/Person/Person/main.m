//
//  main.m
//  Person
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
    property   ---- >  getter  setter
    {
        NSString *_name;
    }
    @property  NSString *name;
 
    .m 
    //@synthesize name;
    //@synthesize name = _name;
    -(void)setName:(NSString *)name
    {
        _name = name;
    }
 
    //
    @property (nonatominc) NSString *name; "_name"
 
    nonatominc  atomic     原子性    atomic
    readonly    readWrite           readWrite
    getter      setter     点语法  ---> 自己名字的getter 和 setter 
 
    //默认 assgin
    retain  retanCount+1  property 写了 retain setter方法 就是满足内存管理的
        //一般oc对象  都要使用 retain 来修饰。
    assgin   //基本数据类型  不能修饰对象  NSObject
 
    内存
        alloc  new copy  retain      release  autorelease
    Person *p = [alloc] init]
    Person *q = [p retain];
 
    [q release]
    q = [Person alloc] init];
 
//    p  retainCount     q
// 
//    [p release];
//    p = nil;
//    p retainCount   1
        Person   Car
        Car *_car  set
 */

#import "Person.h"
#import "Car.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        Person *p = [[Person alloc] init];
        Car *car = [[Car alloc] init];  // 1
        car.ID = 100;
        
        //Car *car1 = [car retain]; // car retainCount+1
        p.car = car;  //2
        
        NSLog(@"%lu",[car retainCount]);
//        Car *car1 = [[Car alloc] init];  //1
//        car1.ID = 200;
//        p.car = car1;
//        
//        NSLog(@"%lu",[car retainCount]);
//        
//        [car release]; //1
//        [car1 release];
//        [p release];

    }
    return 0;
}

