//
//  Person.h
//  Student
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"

@interface Person : NSObject
//@property (nonatomic) NSString *name; //strong == retain
//@property (nonatomic) NSInteger age;  //assgin
//{
//    Car *_car;  //strong
//}

@property (nonatomic,strong) Car *car;

/*
    -(void)setCar:(Car *)car
    {
        _car = car;
    }
 */

//-(void)setCar:(Car *)car;
//-(Car *)car;

@end
