//
//  Person.m
//  Student
//
//  Created by lcy on 14/11/18.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person



-(Car *)car
{
    return _car;
}

-(void)dealloc
{
    NSLog(@"Person dead");
    //当前类的dealloc 调用的时候  会吧所有的强指针成员 都设置成nil
    _car = nil;
    //[super dealloc];
}

@end
