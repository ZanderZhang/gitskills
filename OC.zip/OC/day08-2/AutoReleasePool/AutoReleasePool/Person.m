//
//  Person.m
//  AutoReleasePool
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"
#import "QFAutoReleasePool.h"
//extern NSMutableArray *arr;

@implementation Person

+(id)person
{
    //autoreleasepool
    //autorelease      把当前的对象扔到自动释放池中
    //Person *p = [[[Person alloc] init] autorelease];
    Person *p = [[Person alloc] init];
    p.ID = 1000;
    
    //[arr addObject:p];
    
    //[p release]; // 1

    return p;
}

-(void)dealloc
{
    NSLog(@"person dead");
    [super dealloc];
}

//作用
-(id)autorelease
{
    [[QFAutoReleasePool currendPool] addObjectToPool:self];
    [self release];
    return self;
}

@end
