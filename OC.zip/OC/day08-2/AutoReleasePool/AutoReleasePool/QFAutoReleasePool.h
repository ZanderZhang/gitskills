//
//  QFAutoReleasePool.h
//  AutoReleasePool
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QFAutoReleasePool : NSObject
{
    //保存当前自动释放池 加进来的对象
    NSMutableArray *_objs;
}

-(void)addObjectToPool:(id)obj;
+(QFAutoReleasePool *)currendPool;

@end
