//
//  QFAutoReleasePool.m
//  AutoReleasePool
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "QFAutoReleasePool.h"

//保存 所有产生的自动释放池.
static NSMutableArray *aryPool = nil;

@implementation QFAutoReleasePool

- (instancetype)init
{
    self = [super init];
    if (self) {
        if(nil == aryPool)
        {
            //保证栈  只有一个。
            aryPool = [[NSMutableArray alloc] init];
        }
        
        //创建完 pool  立马扔到栈里面
        [aryPool addObject:self];
        
        [self release]; //保证 retainCount = 1

        _objs = [[NSMutableArray alloc] init];
    }
    return self;
}

-(void)addObjectToPool:(id)obj
{
    [_objs addObject:obj];
}

+(QFAutoReleasePool *)currendPool
{
    return [aryPool lastObject];
}

-(void)dealloc
{
    [_objs release];
    
    [aryPool removeObject:self];
    [super dealloc];
}

@end
