//
//  main.m
//  AutoReleasePool
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "QFAutoReleasePool.h"

//NSMutableArray *arr = nil;
int main(int argc, const char * argv[])
{
//    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
//    
//    [pool release];
    //5.0
    //延时释放
    
    //栈
    @autoreleasepool { //1
        //Person *p = [[Person alloc] init];
        
        //NSMutableArray
        //@autoreleasepool { //2
        //arr = [[NSMutableArray alloc] init];
         //   Person *p1 = [Person person];
        //Person *p1 = [Person person];
          //  NSLog(@"%ld",p1.ID);
        //}   //release
        //有多个autoreleasepool 当对象调用autorelease 会把对象扔到离他最近的池子中 (栈顶)
        
        //[arr release];
        //alloc  +
        //NSString *str = [NSString stringWithFormat:@"hello"];
            
        //1.autoreleasepool对象 --->  栈
        //2.自定义对象 需要实现 autorelease
        
        //数组 10
        QFAutoReleasePool *pool = [[QFAutoReleasePool alloc] init];
        QFAutoReleasePool *pool1 = [[QFAutoReleasePool alloc] init];
        Person *p = [[[Person alloc] init] autorelease];
        [pool1 release]; //1
        [pool release];  //释放
        
    }  //[pool release];   person release

    return 0;
}

