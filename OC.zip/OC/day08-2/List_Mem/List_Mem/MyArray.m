//
//  MyArray.m
//  List_Mem
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "MyArray.h"

@implementation MyArray

//增加元素的方法
//1.obj  retainCount + 1
//2._count + 1

-(void)addObject:(id)obj
{
    //记录个数
    //_count
    _objs[_count++] = [obj retain];
}
//访问数组元素
//_objs[index]

-(id)objectAtIndex:(NSInteger)index
{
    return _objs[index];
}

//删除指定下标的元素
//_objs index  retainCount - 1
//_count - 1
//移位
-(void)removeObjectAtIndex:(NSInteger)index
{
    [_objs[index] release];
    _objs[index] = nil;
    
    for (NSInteger i = index; i < _count - 1; i++) {
        _objs[i] = _objs[i+1];
    }
    _objs[--_count] = nil;
    //_count--;
}

//删除 所有
-(void)removeAllObjects
{
    for (NSInteger i = 0; i < _count; ) {
        [self removeObjectAtIndex:i];
    }
}
//替换
//_objs index retainCount - 1
// anObject  retainCount + 1
//_objs index  = anObject
-(void)replaceObjectAtIndex:(NSInteger)index withObject:(id)anObject
{
    [_objs[index] release];
    _objs[index] = [anObject retain];
}

//给所有元素 发送release
-(void)dealloc
{
    for(NSInteger i = 0;i < _count;i++)
    {
        [_objs[i] release];
        _objs[i] = nil;
    }
    _count = 0;
    [super dealloc];
}

-(NSString *)description
{
    NSMutableString *str = [[NSMutableString alloc] init];
    /*
     (hello,
      world,
     */
    [str appendString:@"(\n"];
    for (NSInteger i = 0; i < _count; i++) {
        [str appendString:@"\t\t"];
        [str appendString:_objs[i]];
        if(i != _count - 1)
        {
            [str appendString:@",\n"];
        }
    }
    [str appendString:@"\n)"];
    
    return str;
}

@end
