//
//  main.m
//  List_Mem
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
//实现一个类似于系统的数组  带内存管理
#import "MyArray.h"

void list_mem(void)
{
    //alloc  1 ---> 自定义的类
    //alloc retain  copy new --->  release
    
    //        NSMutableString *str3 = [[NSMutableString alloc] init];
    //        NSLog(@"%ld",[str3 retainCount]);
    //        NSString *str = [[NSString alloc] init];
    //        NSLog(@"%ld",[str retainCount]);
    //        [str release];
    //
    //        NSString *str1 = @"helloworld";
    //        NSLog(@"%ld",[str1 retainCount]);
    //
    //        NSString *str2 = [NSString stringWithFormat:@"%@",str1];
    //        NSLog(@"%ld",[str2 retainCount]);
    //
    //NSMutableArray  --->  Person
    
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < 10; i++) {
        Person *p = [[Person alloc] init];
        p.ID = 100 + i;
        [arr addObject:p]; //2
        
        [p release];
    }
    
    [arr release];
    
    //dealloc //数组被销毁的时候  会给所有的元素 发送一次release 消息。
    
    //[arr removeObjectAtIndex:0]; //0  person 0
    //[arr removeAllObjects];
    
    //        Person *p = [[Person alloc] init];
    //        NSLog(@"%ld",[p retainCount]);  //1
    //
    //        [arr addObject:p]; //数组增加元素的时候 会自动把该对象的引用计数器 +1
    //        NSLog(@"%ld",[p retainCount]);  //2
    //
    //        //replace
    //        Person *p1 = [[Person alloc] init]; // 1
    //        //会把旧的对象的retainCount - 1 把新的对象的引用计数器+1
    //        [arr replaceObjectAtIndex:0 withObject:p1];
    //        NSLog(@"p = %ld",[p retainCount]);  //1
    //        NSLog(@"p1 = %ld",[p1 retainCount]); //2
    //
    //        [arr removeObject:p1];//数组删除元素的时候 会自动把该对象的引用计数器 -1 release
    //        NSLog(@"%ld",[p1 retainCount]);  //2
}
int main(int argc, const char * argv[])
{
    @autoreleasepool {
        MyArray *arr = [[MyArray alloc] init];
        
        for (NSInteger i = 0 ; i < 10; i++) {
            //Person *p = [[Person alloc] init];
            NSString *str = [NSString stringWithFormat:@"张三%ld",i];
            //NSLog(@"%@",p);
            //p.ID = 100 + i;
            [arr addObject:str];
            //[p release];
        }
        
        NSLog(@"%@",arr);
        
        NSArray *arr1 = @[@"张三"];
        NSLog(@"%@",arr1);
        
        NSLog(@"arr[0] = %@",[arr objectAtIndex:0]);
        
        //[arr removeObjectAtIndex:0];
        //[arr removeAllObjects];
        
//        Person *p1 = [[Person alloc] init];
//        [arr replaceObjectAtIndex:0 withObject:p1];
//        NSLog(@"%ld",[p1 retainCount]);
        
        [arr release];
        
        
    }
    return 0;
}

