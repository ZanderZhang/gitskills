//
//  ObjectA.h
//  Loop_reference
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ObjectB;

@interface ObjectA : NSObject

@property (nonatomic,strong) ObjectB *b;

@end
