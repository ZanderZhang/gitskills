//
//  ObjectA.m
//  Loop_reference
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ObjectA.h"

@implementation ObjectA

-(void)dealloc
{
    _b = nil;
    NSLog(@"ObjectA dead");
}

@end
