//
//  ObjectB.m
//  Loop_reference
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "ObjectB.h"

//strong
//weak

@implementation ObjectB

-(void)dealloc
{
    _a = nil;
    NSLog(@"ObjectB dead");
}

@end
