//
//  main.m
//  Loop_reference
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ObjectA.h"
#import "ObjectB.h"

int main(int argc, const char * argv[])
{
    /*
        A   B
     */
    @autoreleasepool {
        ObjectA *objectA = [[ObjectA alloc] init];
        ObjectB *objectB = [[ObjectB alloc] init];
        
        //循环引用(相互强引用)  会导致两个对象的内存无法回收.   内存泄露
        //解决方法 把其中的一个变成一个 弱引用
        //---->  weak   //代理
        
        //强引用    ----> retainCount  +1
        //弱引用    ----> retainCount  不变
        objectA.b = objectB;
        objectB.a = objectA;
        
        objectA = nil; //B
        objectB = nil; //A
        
//        NSMutableArray *arr1 = [[NSMutableArray alloc] init];
//        NSMutableArray *arr2 = [[NSMutableArray alloc] init];
//        
//        [arr1 addObject:arr2];
//        [arr2 addObject:arr1];
        
        
        
    }
    return 0;
}

