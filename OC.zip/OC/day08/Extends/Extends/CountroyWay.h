//
//  CountroyWay.h
//  Extends
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Road.h"

@interface CountroyWay : Road

@end
