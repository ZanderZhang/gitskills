//
//  CountroyWay.m
//  Extends
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CountroyWay.h"

@implementation CountroyWay
- (instancetype)init
{
    self = [super init];
    if (self) {
        _addSpeed = -10;
    }
    return self;
}
@end
