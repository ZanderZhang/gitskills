//
//  HighWay.m
//  Extends
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "HighWay.h"

@implementation HighWay

- (instancetype)init
{
    self = [super init];
    if (self) {
        _addSpeed = 0;
    }
    return self;
}
@end
