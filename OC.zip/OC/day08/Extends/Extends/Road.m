//
//  Road.m
//  Extends
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Road.h"

@implementation Road

-(void)setDistance:(NSInteger)dis
{
    _distance = dis;
}

-(NSInteger)distance
{
    return _distance;
}

@end
