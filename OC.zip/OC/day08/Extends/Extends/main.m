//
//  main.m
//  Extends
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Road.h"
#import "Car.h"
#import "MountRoad.h"
#import "Bus.h"
#import "CountroyWay.h"
#import "SleepCar.h"

void calcTime(Road *road,Car *car)
{
    NSInteger time = road.distance / (car.speed + road.addSpeed);
    NSLog(@"%ld",time);
}

int main(int argc, const char * argv[])
{
    //继承
    //重写
    //父类指向子类的指针
    @autoreleasepool {
        Road *road = [[CountroyWay alloc] init];
        
        [road setDistance:1000];
        
        Car *bus = [[SleepCar alloc] init];
        
        calcTime(road,bus);
        
    }
    return 0;
}

