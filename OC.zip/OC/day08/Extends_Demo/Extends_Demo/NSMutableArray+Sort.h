//
//  NSMutableArray+Sort.h
//  Extends_Demo
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (Sort)

-(void)reverse;
//排序方法
-(void)sort;

@end
