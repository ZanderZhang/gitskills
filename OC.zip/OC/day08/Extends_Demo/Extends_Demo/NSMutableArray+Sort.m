//
//  NSMutableArray+Sort.m
//  Extends_Demo
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "NSMutableArray+Sort.h"

@implementation NSMutableArray (Sort)
//1. 系统类  扩充方法
//2. 如果多个人合作  把类中公共的代码 放到类别中  给别人使用

-(void)reverse
{
    for(NSInteger i = 0;i< [self count] / 2;i++)
    {
        [self exchangeObjectAtIndex:i  withObjectAtIndex:[self count] - i - 1];
    }
}

-(void)sort
{
    //升序
    //给可变数组  扩充一个方法  逆序保存 数组中的内容
    NSLog(@"my sort");
    for (NSInteger i = 0 ; i < [self count] ; i++) {
        for (NSInteger j = 0; j < [self count] -i -1; j++) {
            if([self[j] compare:self[j+1]] == NSOrderedAscending)
            {
                [self exchangeObjectAtIndex:j withObjectAtIndex:j+1];
            }
        }
    }
}

@end
