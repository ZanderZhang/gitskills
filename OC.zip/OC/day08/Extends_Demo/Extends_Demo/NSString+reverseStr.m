//
//  NSString+reverseStr.m
//  Extends_Demo
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "NSString+reverseStr.h"

@implementation NSString (reverseStr)

-(void)reveseStr
{
    //字符串  self
    //NSMutableS   %C  --> 中
    for (NSInteger i = [self length] - 1; i >= 0 ; i--) {
        NSLog(@"%C",[self characterAtIndex:i]);
    }
}
@end
