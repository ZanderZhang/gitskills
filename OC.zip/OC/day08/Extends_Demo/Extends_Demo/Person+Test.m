//
//  Person+Test.m
//  Extends_Demo
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person+Test.h"

@implementation Person (Test)
-(void)test
{
    NSLog(@"%ld",_a);
}
@end
