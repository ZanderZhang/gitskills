//
//  main.m
//  Extends_Demo
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

//struct bir
//{
//
//};
//
//struct stu s
//{
//    struct bir b;
//};

//struct stu s ;

// 扩展
//
//子类成员或者方法  >= 父类

//A  :  B
// test

//
//A *a = [A alloc] init];
//super init  //构造父类
//a test;

// 重写

//NSArray  --->  排序算法(冒泡)   扩充
//A : NSArray  ---> sort   //类簇
//{}

// 类别  ---->  给已有的类扩充方法
//category

//声明语法
//@interface 要扩展类的名字 (类别的名字)
//@end

//@implementation <#class#> (<#category name#>)
//@end

#import "NSMutableArray+Sort.h"
#import "NSString+reverseStr.h"
//  继承       和   类别
// 字段和方法       方法
//
// 类中字段的访问权限  protected  子类 和 本类
// @priveate  本类
// 类别 直接访问 私有成员
// 不可变字符串  ---->  方法   逆序输出 字符串  类别
int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        //@"12324",@"43543543",@"234324";
        NSMutableArray *arr = [[NSMutableArray alloc] initWithObjects:@"12324",@"43543543",@"234324", nil];
        
        [arr sort];
        
        NSLog(@"%@",arr);
        
        NSString *str = @"helloworld";
        [str reveseStr];
    }
    return 0;
}

