//
//  MyArray.h
//  List_Mem
//
//  Created by lcy on 14/11/19.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

//NSObject *obj[100];
//NSArray  ---> @"hello";  count
//int arr[10] ;  1 .... 10
//arr[0] = 1;
//arr[1] = 2;
@interface MyArray : NSObject
{
    //保存数组元素的c语言数组
    id _objs[100];
    //保存数组中元素的个数
    NSInteger _count;
}
//增加元素的方法
//1.obj  retainCount + 1
//2._count + 1
-(void)addObject:(id)obj; //0x43873785 _objs[_count++] = [obj retain];
//访问数组元素
//_objs[index]
-(id)objectAtIndex:(NSInteger)index;
//删除指定下标的元素
//_objs index  retainCount - 1
//_count - 1
//移位
-(void)removeObjectAtIndex:(NSInteger)index;
//删除 所有
-(void)removeAllObjects;
//替换
//_objs index retainCount - 1
// anObject  retainCount + 1
//_objs index  = anObject
-(void)replaceObjectAtIndex:(NSInteger)index withObject:(id)anObject;
//给所有元素 发送release
-(void)dealloc;

@end
