//
//  main.m
//  Copy
//
//  Created by lcy on 14/11/21.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//strcpy
#import "Person.h"

void str_copy(void)
{
    //copy 拷贝系统对象
    NSString *str = [[NSString alloc] initWithFormat:@"%@",@"hello"];
    NSLog(@"%ld",[str retainCount]); //!= 1
    
    //如果拷贝的是一个不可变的对象  那么相当于  该对象发送了一次  retain 消息
    NSString *str1 = [str copy];
    NSLog(@"%p %p",str,str1);
    NSLog(@"%ld %ld",[str retainCount],[str1 retainCount]);
    
    //如果拷贝的是可变对象  会产生一个新的对象,旧的对象的retainCount 不变   新的对象retainCount = 1
    //只要是对象调用copy 消息 不管不可变还是不可变  最终拷贝出来的结果都是不可变的.
    NSMutableString *str2 = [[NSMutableString alloc] initWithFormat:@"%@",@"hello"];
    NSLog(@"%ld",[str2 retainCount]);
    
    NSMutableString *str3 = [str2 copy];
    NSLog(@"%p %p",str2,str3);
    NSLog(@"%ld %ld",[str2 retainCount],[str3 retainCount]);
}

void mutable_copy(void)
{
    //copy mutableCopy 系统对象
    NSString *str = [NSString stringWithFormat:@"%@",@"helloworld"];
    //拷贝一份新的对象.
    //只要是对象调用mutableCopy 消息 不管不可变还是不可变  最终拷贝出来的结果都是可变的.
    NSMutableString *str1 = [str mutableCopy];
    NSLog(@"%p %p",str,str1);
    
    NSLog(@"%ld %ld",[str retainCount],[str1 retainCount]);
    [str1 appendString:@"123"];
    
    NSLog(@"%@",str1);
    
    NSMutableString *str2  = [[NSMutableString alloc]initWithFormat:@"%@",@"hello" ];
    
    NSMutableString *str3 = [str2 mutableCopy];
    NSLog(@"%p %p",str2,str3);
    
    NSLog(@"%ld %ld",[str2 retainCount],[str3 retainCount]);
    
    [str3 appendString:@"123"];
    NSLog(@"%@",str3);
}

void custom_obj_copy(void)
{
    //NSCopying
    //NSString
    Person *p = [[Person alloc] init];
    p.name = @"zhangsan";
    p.age = 100;
    
    Person *q = [p copy];
    
    Person *m = [p mutableCopy];
    
    NSLog(@"%p,%p",p,q);
    NSLog(@"%@",q);
    
    [p release];
    [q release];
}
void creat_file(void)
{
    NSMutableArray *arr=[NSMutableArray arrayWithObjects:@"123",@"456", nil];
    NSMutableArray *arr1=[arr mutableCopy];
    [arr1 replaceObjectAtIndex:0 withObject:@"789"];
    NSLog(@"%@",arr1);

    
}

int main(int argc, const char * argv[])
{
    @autoreleasepool {
    
        
        
        //*****copy 和 mutableCopy 拷贝的都是一个浅拷贝
        //NSArray *arr1 = [arr mutableCopy];
        
//        NSLog(@"%p %p",arr,arr1);
//        NSLog(@"%p %p",arr[0],arr1[0]);
        
        //person  name  ---> car  name
        //NSMutableArray *arr;
        //init  --->  5  add arr
        //car
        //YES   深拷贝
        //NO    浅拷贝
        //深拷贝  浅拷贝
//        NSMutableString *str = [[NSMutableString alloc] initWithFormat:@"hello"];
//        
//        NSMutableString *str1 = [[NSMutableString alloc] initWithFormat:@"world"];
//        NSMutableArray *arr = [[NSMutableArray alloc] initWithObjects:str,str1,nil];
//        
//        NSArray *arr2 = [[NSArray alloc] initWithArray:arr copyItems:YES];
//       // NSArray *arr3=[[NSArray alloc]initWithArray:arr copyItems:NO];
//        NSLog(@"%p %p",arr2,arr);
//        NSLog(@"arr2[0]=%p arr[0]=%p",arr2[0],arr[0]);
//        
//        //Person
//        
//        Person *p = [[Person alloc] init];
//        p.name = @"zhangsan";
//        
//        Person *q = [p copy];
//        
//        NSLog(@"%p,%p",p,q);
//        NSLog(@"%p %p",p.name,q.name);
//
        creat_file();

    }
    return 0;
}

