//
//  Person.h
//  Copy
//
//  Created by lcy on 14/11/21.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject <NSCopying,NSMutableCopying>
@property (nonatomic,retain) NSString *name;
@property (nonatomic,assign) NSInteger age;
@property (nonatomic,retain) NSMutableArray *arr;

@end
