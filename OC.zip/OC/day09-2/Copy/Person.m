//
//  Person.m
//  Copy
//
//  Created by lcy on 14/11/21.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person
//zone 系统提供的内存
//strcpy  char arr[]
//copy

//-(id)copyWithZone:(NSZone *)zone
//{
//
//    return [self retain];
//}

-(id)copyWithZone:(NSZone *)zone
{
    Person *person = [[Person allocWithZone:zone] init];
    //self ---> p
    person.name = [self.name mutableCopy];
    person.age = self.age;
    person.arr = [[NSMutableArray alloc] initWithArray:self.arr copyItems:YES];
    return person;
}

-(id)mutableCopyWithZone:(NSZone *)zone
{
    Person *person = [[Person allocWithZone:zone] init];
    //self ---> p
    person.name = self.name;
    person.age = self.age;
    return person;
}//这个跟上面是一样的。

//-(NSString *)description
//{
//    return [NSString stringWithFormat:@"%@ %ld",_name,_age ];
//}
-(NSString *)description
{
    return [NSString stringWithFormat:@"%@ %ld", _name,_age];
}


@end
