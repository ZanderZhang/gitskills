//
//  MyTest.m
//  Protocol
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "MyTest.h"

@implementation MyTest

-(void)test1
{
    NSLog(@"test1");
}

-(void)test2
{
    NSLog(@"test2");
}

-(void)helloworld
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

@end
