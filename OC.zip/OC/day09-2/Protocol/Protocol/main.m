//
//  main.m
//  Protocol
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//protocol NSObject 在协议中 叫  基协议
//@protocol 协议名 <NSObject>
//@end
#import "MyProtocol.h"
#import "MyTest.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        MyTest *t = [[MyTest alloc] init];
        //SEL @sele
        //conformsToProtocol  判断某个对象 是否遵守某个协议
        BOOL ret = [t conformsToProtocol:@protocol(MyProtocol)];
        
        if(ret)
        {
            NSLog(@"YES");
        }
        else
        {
            NSLog(@"NO");
        }
        
        [t test1];
        
        //判断协议中的某个方法  是否实现
        if([t respondsToSelector:@selector(test2)])
        {
            [t test2];
        }
        
        [t helloworld];
        
        //1.boss  --->  协议
        //id <协议名> 对象名 = [[Mytest alloc] init];
        //<>   泛型
        id <MyProtocol> t1 = [[MyTest alloc] init];
        [t1 test1];
        
        BOOL ret1 = [t1 conformsToProtocol:@protocol(HelloWorld)];
        NSLog(@"%d",ret1);
        
        id <HelloWorld,MyProtocol> t2 = [[MyTest alloc] init];
        [t2 helloworld];
    }
    return 0;
}

