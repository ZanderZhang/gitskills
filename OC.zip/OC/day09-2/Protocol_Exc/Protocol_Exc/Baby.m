//
//  Baby.m
//  Protocol_Exc
//
//  Created by lcy on 14/11/21.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Baby.h"

@implementation Baby

-(void)play
{
    NSLog(@"我要你逗我玩");
    [_delegate playWithBaby];
}

-(void)eat
{
    NSLog(@"我饿了");
    [_delegate eatWithBaby];
}

-(void)wash
{
    NSLog(@"我要洗澡");
    [_delegate washWithBaby];
}
-(void)pill
{
    NSLog(@"我要吃药");
    [_delegate pillWithBaby];
}







@end
