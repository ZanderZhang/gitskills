//
//  TakeCare.h
//  Protocol_Exc
//
//  Created by lcy on 14/11/21.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TakeCare <NSObject>

//@optional
//@required
-(void)playWithBaby;
-(void)washWithBaby;
-(void)pillWithBaby;
-(void)eatWithBaby;











@end
