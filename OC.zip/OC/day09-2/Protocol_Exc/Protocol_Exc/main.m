//
//  main.m
//  Protocol_Exc
//
//  Created by lcy on 14/11/21.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//
//conformsToProtocol
//respondsToSelector  ---->
//id <> 变量

#import "Baby.h"
#import "Amah.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        Baby *b = [[Baby alloc] init];
        Amah *a = [[Amah alloc] init];
        
//        b.delegate = a;
        [b setDelegate:a];
        [b play];
        [b eat];
        [b pill];
        [b wash];
        
        
        
        
        
        
        
    }
    return 0;
}

