//
//  Agent.m
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Agent.h"

@implementation Agent

-(void)findHose
{
    NSLog(@"Agent find House");
}

@end
//代理模式，什么是代理模式，给某一对象提供代理对象，并由代理对象控制具体对象的引用，
//指的就是一个角色代表另一个角色采取行动，
/*如何实现代理模式，定义代理和被代理对象之间的通讯协议，设置代理对象，通过代理对象执行相应的功能
 如何实现代理模式：
 1.定义代理和被代理对象之间的通讯协议；
 2.设置代理对象；
 3.通过代理对象执行相应的功能。
*/
