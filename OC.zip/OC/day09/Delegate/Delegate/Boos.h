//
//  Boos.h
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Code.h"
#import "PayMoney.h"
@interface Boos : NSObject <PayMoney>
{
   __weak id <Code>_delegate;
}

@property (nonatomic,weak) id <Code> delegate;

-(void)bossCoding;

@end
