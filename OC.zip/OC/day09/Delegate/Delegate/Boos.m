//
//  Boos.m
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Boos.h"

@implementation Boos
@synthesize delegate = _delegate;
//{
//    _delegate = delegate
//}

-(void)bossCoding
{
    //c
    [_delegate Coding];
}

-(void)payMoney:(NSInteger)money
{
    NSLog(@"boss pay money %ld",money);
}

@end
