//
//  Coder.h
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Code.h"
#import "PayMoney.h"

@interface Coder : NSObject <Code>
//所有的代理  weak
@property (nonatomic,weak) id <PayMoney> delegate;

-(void)askMoney;

@end
