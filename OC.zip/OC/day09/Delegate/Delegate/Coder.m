//
//  Coder.m
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Coder.h"

@implementation Coder

-(void)Coding
{
    NSLog(@"coder coding");
}

-(void)askMoney
{
    [_delegate payMoney:300000];
}

@end
