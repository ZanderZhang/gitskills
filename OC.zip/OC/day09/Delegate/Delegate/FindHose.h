//
//  FindHose.h
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FindHose <NSObject>
-(void)findHose;

@end
