//
//  PayMoney.h
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PayMoney <NSObject>

-(void)payMoney:(NSInteger)money;
@end
