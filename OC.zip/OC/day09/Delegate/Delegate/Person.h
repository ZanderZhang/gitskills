//
//  Person.h
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FindHose.h"

@interface Person : NSObject

@property (nonatomic,strong) id <FindHose> delegate;

-(void)personFindHouse;

@end
