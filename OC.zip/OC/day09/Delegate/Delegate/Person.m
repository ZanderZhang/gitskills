//
//  Person.m
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

-(void)personFindHouse
{
    [_delegate findHose];
}

@end
