//
//  main.m
//  Delegate
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Boos.h"
#import "Coder.h"
#import "Code.h"
#import "Person.h"
#import "Agent.h"

//person (协议) ---->  中介  ---->  找房子
int main(int argc, const char * argv[])
{
    @autoreleasepool {
        //单向代理
        //双向代理
        Boos *b = [[Boos alloc] init];
        Coder *c = [[Coder alloc] init];
        //相互强引用
        b.delegate = c;
        c.delegate = b;
        [b bossCoding];
        [c askMoney];
        
        Person *p = [[Person alloc] init];
        Agent *a = [[Agent alloc] init];
        
        p.delegate = a;
        [p personFindHouse];
    }
    return 0;
}

