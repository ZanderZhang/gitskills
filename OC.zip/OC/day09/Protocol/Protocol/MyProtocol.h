//
//  MyProtocol.h
//  Protocol
//
//  Created by lcy on 14/11/20.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MyProtocol <NSObject>

//类
//协议  不能存放  成员变量.
//默认  @required
//别的对象实现该协议的时候 必须实现下面的方法。
//@required
-(void)test1;

@optional
-(void)test2;

@end
