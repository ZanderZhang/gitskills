//
//  Car.h
//  Copy_exc
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Car : NSObject <NSCopying>

@property (nonatomic,strong) NSString *name;

@end
