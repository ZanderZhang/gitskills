//
//  Car.m
//  Copy_exc
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Car.h"

@implementation Car

-(id)copyWithZone:(NSZone *)zone
{
    //[self class]  Car
    Car *c = [[[self class] alloc] init];
    c.name = [self.name mutableCopy];
    
    return c;
}

@end
