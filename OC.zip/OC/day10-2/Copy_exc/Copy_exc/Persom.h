//
//  Persom.h
//  Copy_exc
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Car.h"

@interface Persom : NSObject <NSCopying>

//retain  copy   NSString
//@property (nonatomic,strong) NSString *car;
@property (nonatomic,strong) NSMutableArray *data;
@property (nonatomic,strong) NSString *name;

-(id)init;

@end
