//
//  Persom.m
//  Copy_exc
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Persom.h"

@implementation Persom

- (instancetype)init
{
    self = [super init];
    if (self) {
        _data = [[NSMutableArray alloc] init];
        for (NSInteger i = 0; i < 5; i++) {
            Car *c = [[Car alloc] init];
            c.name = @"audi";
            [_data addObject:c];
        }
        //NSLog(@"1111%@",_data);
    }
    return self;
}

- (id)copyWithZone:(NSZone *)zone
{
    Persom *p = [[Persom allocWithZone:zone] init];
    
    p.name = [self.name mutableCopy];
    p.data = [[NSMutableArray alloc] initWithArray:self.data copyItems:YES];
    
    return p;
}

@end
