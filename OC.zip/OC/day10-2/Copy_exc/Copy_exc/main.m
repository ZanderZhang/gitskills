//
//  main.m
//  Copy_exc
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//深拷贝和浅拷贝
//成员指针
//Person  age     p1  p2   p1.age = 100, p2 = 100
//p1.age = 200;
//person   mutabletableArray  Car
//
#import "Persom.h"
int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        //协议 NSCopying
        Persom *p = [[Persom alloc] init];
        p.name = @"zhangsan";
        Persom *q = [p copy];
        
        NSLog(@"%p %p",p,q);
        NSLog(@"%p %p",p.name,q.name);
        NSLog(@"%p %p",p.data,q.data);
        
        Car *c1 = p.data[0];
        Car *c2 = q.data[0];
        
        NSLog(@"%p %p",c1,c2);
        NSLog(@"%p %p",c1.name,c2.name);
    }
    return 0;
}

