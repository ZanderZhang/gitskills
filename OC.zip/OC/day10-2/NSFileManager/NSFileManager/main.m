//
//  main.m
//  NSFiDow1leManager
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
//NSFileManager  创建
//NSFileHandle   copy  DownLoad  ---->  断点续传
//seekTofileOffset

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        //NSFileManager
        NSFileManager *man = [NSFileManager defaultManager];
        
        NSString *path = @"/Users/lcy/Desktop/Download/123/AppFree.zip";
        
        //Intermediate  中间
        //withIntermediateDirectories 如果是一级  NO
        //多级目录  必须是YES
        if(![man fileExistsAtPath:path])
        {
            [man createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
        }
        //mange  拷贝 移动  删除
        //目标路径里 的文件夹也必须有名字
        //mv  重命名
        //普通文件也可以拷贝
        //
        //[man copyItemAtPath:path toPath:@"/Users/lcy/hello.zip" error:nil];
        //[man moveItemAtPath:path toPath:@"/Users/lcy/hello.zip" error:nil];
        [man removeItemAtPath:@"/Users/lcy/Desktop/hello.zip" error:nil];
        //遍历文件夹
        //深层遍历  和  浅层遍历
        NSArray *arr = [man contentsOfDirectoryAtPath:@"/Users/lcy/Desktop/AppFree" error:nil];
        
        NSLog(@"1%@",arr);
        
        arr = [man subpathsOfDirectoryAtPath:@"/Users/lcy/Desktop/AppFree" error:nil];
        NSLog(@"2%@",arr);
    }
    return 0;
}

