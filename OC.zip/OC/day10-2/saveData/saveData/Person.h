//
//  Person.h
//  saveData
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject <NSCoding>
@property (nonatomic,strong) NSString *name;
@property (nonatomic) NSInteger age;
@end
