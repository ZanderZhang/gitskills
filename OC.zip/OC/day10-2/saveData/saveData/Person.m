//
//  Person.m
//  saveData
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person

//aCoder  用来做 给自定义对象的所有成员进行归档
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    //name
    [aCoder encodeObject:_name forKey:@"name"];
    [aCoder encodeInteger:_age forKey:@"age"];
}

//aDecoder
-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.age = [aDecoder decodeIntegerForKey:@"age"];
    }
    return self;
}

@end
