//
//  main.m
//  saveData
//
//  Created by lcy on 14/11/24.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[])
{
    /*
        对象
        person *p =[pErson alloc] init];
        p = [alloc] init];
        array ---> dic ---> dic  qqlist    网络 json
     
        person  --->  NSMutableArray *array ; 先alloc
     
        person string   isKindOfClass
     
        writeToFile 
     
        sortXXX   ---->  比较规则
        //自定义对象的 排序
        SEL
        block
        
        property ---> 带参数
        @property NSString *name;
        协议   ----> 代理设计模式 传参数
     
        //copy ---> 网络下载
        //归档
     */
    @autoreleasepool {
        //copy     NSCopying
        //encodeXX NSCoding
        
        Person *p = [[Person alloc] init];
        
        p.name = @"zhangssan";
        p.age = 100;
        NSLog(@"%@",p);

        //Person name  age
        // string  copy
        // person  copy   ---> 归档  序列化  --->  对象   转换成二进制 data
        //
        //NSData *data = nil;
        //data write
//        NSArray *arr = @[@"zhangsan"];
//        NSDictionary *dic = @{@"1":@"qianfeng"};
//        NSMutableData *data = [[NSMutableData alloc] init];
//        NSKeyedArchiver *arch = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
//        //归档
//        [arch encodeObject:arr forKey:@"arr"];
//        [arch encodeObject:dic forKey:@"dic"];
//        [arch encodeObject:p forKey:@"p"];
//        //结束归档
//        [arch finishEncoding]; //closeFile;
//        NSLog(@"%@",data);
//        [data writeToFile:@"/Users/lcy/Desktop/test" atomically:YES];
        //person  --->  car
        //解归档
        NSData *data = [NSData dataWithContentsOfFile:@"/Users/lcy/Desktop/test"];
        NSKeyedUnarchiver *unarch = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
        
        NSArray *arr = [unarch decodeObjectForKey:@"arr"];
        
        NSDictionary *dic = [unarch decodeObjectForKey:@"dic"];
        
        Person *p1 = [unarch decodeObjectForKey:@"p"];
        NSLog(@"%@ %ld",p1.name,p1.age);
        
        NSLog(@"%@ %@",arr,dic);
        
    }
    return 0;
}

