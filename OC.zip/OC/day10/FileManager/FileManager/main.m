//
//  main.m
//  FileManager
//
//  Created by lcy on 14/11/21.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>







void copy_file(void)
{
    NSString *soucePath = @"/Users/lcy/Desktop/AppFree.zip";
    
    NSString *destPath = @"/Users/lcy/Desktop/abc.zip";
    
    NSFileManager *man = [NSFileManager defaultManager];
    if(![man fileExistsAtPath:destPath])
    {
        [man createFileAtPath:destPath contents:nil attributes:nil];
    }
    
    NSFileHandle *writeHandle = [NSFileHandle fileHandleForWritingAtPath:destPath];
    NSFileHandle *readHandle = [NSFileHandle fileHandleForReadingAtPath:soucePath];
    
    NSData *data = [readHandle readDataOfLength:500];
    while (data.length == 500) {
        [writeHandle writeData:data];
        data = [readHandle readDataOfLength:500];
    }
    [writeHandle writeData:data];
    //commnd + c
    //commnd + v
    [readHandle closeFile];
    [writeHandle closeFile];
}

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        //NSFileManager  文件管理员 创建 删除 或者拷贝 或者 移动
        //NSFileHandle   文件句柄  文件的打开 关闭和 读写
        
        //得到一个文件管理员
        //单例 设计
        //+
        //NSFileManager *man = [NSFileManager defaultManager];
        //NSString  文件的路径
        //contents  文件创建时候的初始化内容 ---> 空文件 nil
        //attributes  属性(读写)   ---> nil
        //@"/Users/lcy/Desktop/"
        //得到主目录的路径
        NSString *str = @"qianfeng"; //数据 持久化
        //写文件    数据库   网络
        //保存   硬盘上
        //文件分类:文本文件 和 二进制文件
        
        NSFileManager *man = [NSFileManager defaultManager];
        NSString *homePath = NSHomeDirectory();
        NSLog(@"%@",homePath);
        NSString *desktopPath = [NSString stringWithFormat:@"%@/Desktop",homePath];
        NSString *path = [NSString stringWithFormat:@"%@/test",desktopPath];
        
        //fileExistsAtPath  判断文件是否已经存在
        if([man fileExistsAtPath:path])
        {
            NSLog(@"文件已经存在");
        }
        else
        {
            NSLog(@"文件不存在");
            BOOL ret = [man createFileAtPath:path contents:nil attributes:nil];
            
            if(ret)
            {
                NSLog(@"创建文件成功");
            }
            else
            {
                NSLog(@"创建文件失败");
            }
        }
        //打开文件
        //fileHandleForReadingAtPath 以只读打开文件
        //fileHandleForWritingAtPath 只写打开文件
        //fileHandleForUpdatingAtPath 读和写打开文件
        NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:path];
        //文件指针  每次打开一个文件  文件指针都会指向文件的开始
        //文件指针的定位
        //把文件指针定位到整个文件末尾
        //[fileHandle seekToEndOfFile];
        //[fileHandle seekToFileOffset:5];
        //{1,2,3,4,5};
        //fileHandle seekToFileOffset:<#(unsigned long long)#>
        //NSData;  二进制数据
        NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
        NSLog(@"%@",data);
        [fileHandle writeData:data];
        [fileHandle closeFile]; //关闭文件
        
        //command + c
        
        //读文件
        NSFileHandle *readHandle = [NSFileHandle fileHandleForReadingAtPath:path];
        
        //readDataToEndOfFile 把所有的文件都读出来
        //readDataOfLength  读指定字节的数据
        NSData *data1 =[readHandle readDataOfLength:10];
        
        NSLog(@"data1 = %ld",[data1 length]);
        
        NSLog(@"%@",data1);
        //data ---> str
        NSString *str2 = [[NSString alloc] initWithData:data1 encoding:NSUTF8StringEncoding];
        NSLog(@"%@",str2);
        [readHandle closeFile];
        //播放器 ----> 10GB
        /*
         //500
            A     ---->     B
         data =  read   write:data
         //readDataToEndOfFile
         10GB   1Mb   //   1Mb
         */
        //while(data.length == 500 )
        //{
        //  b  写数据
        //  a  读数据
        //}
        //b  写数据
        
        copy_file();
        
    }
    return 0;
}

