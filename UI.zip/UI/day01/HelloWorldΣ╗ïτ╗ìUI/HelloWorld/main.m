//
//  main.m
//  HelloWorld
//
//  Created by lcy on 14/11/25.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//
//shift + command + h  首页
//commad + s   截图
#import <UIKit/UIKit.h>
#import "CYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        //1.创建一个UIApplication 对象,每一个应用程序 都要对应一个UIApplication对象
        //单例 [UIApplication sharedApplication]
        //2.设置代理CYAppDelegate 对象  处理监听事件
        //3.创建一个事件循环
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CYAppDelegate class]));
    }
}
