//
//  CYAppDelegate.m
//  UILabel
//
//  Created by lcy on 14/11/25.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"

@implementation CYAppDelegate

-(void)showAllFonts
{
    NSInteger cnt = 0;//逻辑
    NSArray *fonts = [UIFont familyNames];
    for (NSString *name in fonts) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, cnt * 30, 320, 30)];
        label.text = name;
        label.font = [UIFont fontWithName:name size:14.0f];
        label.textAlignment = NSTextAlignmentCenter;

        cnt ++;
        [self.window addSubview:label];
    }
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    //UILabel  主要用来显示文字
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(50, 50, 270, 400)];
    //label.backgroundColor = [UIColor redColor];
    label.text = @"Sent when the applicationisabouttomovefrom active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state";
    //设置位置
    label.textAlignment = NSTextAlignmentCenter;
    //字体颜色
    label.textColor = [UIColor cyanColor];
    //字体大小
    //如果不改变字体样式的话 .name  nil
    NSArray *fonts = [UIFont familyNames];
    NSLog(@"%@",fonts);
    label.font = [UIFont fontWithName:@"Bodoni 72 Smallcaps" size:24.0f];
    
    //设置高亮颜色
    label.highlightedTextColor = [UIColor yellowColor];
    //手动设置label 高亮
    label.highlighted = YES;
    label.shadowColor = [UIColor blueColor];
    //设置阴影的偏移量
    label.shadowOffset = CGSizeMake(-3, -3);
    //分行模式
    label.lineBreakMode = NSLineBreakByWordWrapping;
    //设置label的多行显示  10
    //任意行显示  numberOfLines = 0
    label.numberOfLines = 0;
    //[self.window addSubview:label];
    
    
    [self showAllFonts];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
