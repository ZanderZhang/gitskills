//
//  CYAppDelegate.m
//  UILabel_1
//
//  Created by lcy on 14/11/25.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"
#import "CYCustomVew.h"

@implementation CYAppDelegate

-(void)UILabel_exc
{
    //frame
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 60, 320, 30)];
    label.text = @"笑得肚子疼";
    label.font = [UIFont boldSystemFontOfSize:20.0f];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blueColor];
    
    label.shadowColor = [UIColor grayColor];
    label.shadowOffset = CGSizeMake(2, 2);
    [self.window addSubview:label];
    
    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(40, label.frame.origin.y + label.frame.size.height, 200, 30)];
    
    label1.text = @"修改后的内容";
    label1.textColor = [UIColor lightGrayColor];
    
    [self.window addSubview:label1];
    
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(20, label1.frame.origin.y + label1.frame.size.height, 280, 100)];
    
    label2.text = @"Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions";
    //动态计算字体size。
    CGSize size = [label2.text sizeWithFont:label2.font constrainedToSize:CGSizeMake(280, 10000)];
    CGRect rect = label2.frame;
    rect.size = size;
    label2.frame = rect;
    
    label2.numberOfLines = 0;
    [self.window addSubview:label2];
    
    //自己实现  ---》 自定义view
    UILabel *label3 = [[UILabel alloc] initWithFrame:CGRectMake(20, label2.frame.origin.y + label2.frame.size.height, 280, 40)];
    
    label3.text = @"15个人点赞";
    label3.backgroundColor = [UIColor grayColor];
    
    [self.window addSubview:label3];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 300, 50)];
    label.backgroundColor = [UIColor grayColor];
    
    label.font = [UIFont boldSystemFontOfSize:16.0f];
    label.text = @"Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state";
    
    //width  height
    CGSize size = [label.text sizeWithFont:label.font constrainedToSize:CGSizeMake(300, 10000)];
    NSLog(@"%@",NSStringFromCGSize(size));
    //动态计算字体size。
//    label.frame.size = size;
    label.numberOfLines = 0;
    CGRect rect = label.frame;  //获取 label的旧的frame
    rect.size = size;  //把新的size 赋值给rect。
    label.frame = rect; //新的rect的值给label的frame
    
    //[self.window addSubview:label];
    //[self UILabel_exc];
    
    CYCustomVew *view = [[CYCustomVew alloc] initWithFrame:CGRectMake(20, 100, 280 ,40)];
    view.leftLabel.text = @"15人觉得赞";
    view.rightLabel.text = @"33条评论";
    view.backgroundColor = [UIColor redColor];
    [self.window addSubview:view];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
