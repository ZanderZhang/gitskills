//
//  CYCustomVew.h
//  UILabel_1
//
//  Created by lcy on 14/11/25.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYCustomVew : UIView

@property (nonatomic,strong) UILabel *leftLabel;
@property (nonatomic,strong) UILabel *rightLabel;

@end
