//
//  CYCustomVew.m
//  UILabel_1
//
//  Created by lcy on 14/11/25.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYCustomVew.h"

@implementation CYCustomVew

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 140, 40)];
        [self addSubview:_leftLabel];
        
        _rightLabel = [[UILabel alloc] initWithFrame:CGRectMake(140, 0, 140, 40)];
        _rightLabel.textAlignment = NSTextAlignmentRight;
        [self addSubview:_rightLabel];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
/*
 Only override drawRect:if you perfrorm custom drawing. An empty implementation adversely affects performance during animation.
 Only override drawRect:if you perform custom drawing.An empty implementation adversely affects performance during animation.
 O
 
 
 
 */

@end
