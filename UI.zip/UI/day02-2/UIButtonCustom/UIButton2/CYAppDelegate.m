//
//  CYAppDelegate.m
//  UIButton2
//
//  Created by lcy on 14/11/26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"

@implementation CYAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    //动态获取图片大小***

    //自定义
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];

    //.png  .png省略  其他格式的后缀不能省略
    UIImage *img1 = [UIImage imageNamed:@"1"];
    UIImage *img2 = [UIImage imageNamed:@"2"];
    btn.frame = CGRectMake(50, 50, img1.size.width, img1.size.height);
    
    NSLog(@"%@",NSStringFromCGSize(img1.size));
    
    //[btn setImage:img1 forState:UIControlStateNormal];
    //既要有图片 又要有title setBackgroundImage
    [btn setBackgroundImage:img1 forState:UIControlStateNormal];
    
    [btn setImage:img2 forState:UIControlStateSelected];
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [btn setTitle:@"btn" forState:UIControlStateNormal];
    
    [self.window addSubview:btn];
    return YES;
}

-(void)btnClick:(UIButton *)sender
{
    sender.selected = YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
