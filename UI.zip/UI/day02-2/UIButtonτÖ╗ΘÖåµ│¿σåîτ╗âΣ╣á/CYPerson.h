//
//  CYPerson.h
//  UIButton1
//
//  Created by lcy on 14/11/26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CYPerson : NSObject
-(void)personBtnClick;

@end
