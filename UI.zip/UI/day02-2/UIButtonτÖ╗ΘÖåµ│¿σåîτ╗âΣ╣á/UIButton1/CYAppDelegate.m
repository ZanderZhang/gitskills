//
//  CYAppDelegate.m
//  UIButton1
//
//  Created by lcy on 14/11/26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"
#import "CYPerson.h"
enum
{
    LOGIN = 100,
    REGISTER = 200
};

@implementation CYAppDelegate
{
    UILabel *_showLabel;
    CYPerson *p;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    //多个按钮 共用一个消息*****tag
    _showLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, 320, 40)];
    _showLabel.textAlignment=NSTextAlignmentCenter;
    
    [self.window addSubview:_showLabel];
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    loginBtn.tag = LOGIN; //0
    loginBtn.frame = CGRectMake(50, 400, 100, 40);
    [loginBtn setTitle:@"登陆" forState:UIControlStateNormal];
    // self  -->  CYAppDelegate对象
    // 别的对象处理
    // p 一定是一个成员变量
    // 回调
    //p = [[CYPerson alloc] init];
    [loginBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.window addSubview:loginBtn];
    
    UIButton *registerBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    registerBtn.tag = REGISTER;
    registerBtn.frame = CGRectMake(200, 400, 100, 40);
    [registerBtn setTitle:@"注册" forState:UIControlStateNormal];
    [registerBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.window addSubview:registerBtn];
    return YES;
}

//带一个参数
//btn
//sender 谁触发的该方法   sender 就是该对象
-(void)btnClick:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    //NSLog(@"%@",sender);
    switch (btn.tag) {
        case LOGIN:
            _showLabel.text =btn.titleLabel.text;
            break;
            
        case REGISTER:
            _showLabel.text = btn.titleLabel.text;
            break;
            
        default:
            break;
    }
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
