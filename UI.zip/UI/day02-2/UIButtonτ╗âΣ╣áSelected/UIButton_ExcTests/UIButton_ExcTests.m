//
//  UIButton_ExcTests.m
//  UIButton_ExcTests
//
//  Created by lcy on 14/11/26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface UIButton_ExcTests : XCTestCase

@end

@implementation UIButton_ExcTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
