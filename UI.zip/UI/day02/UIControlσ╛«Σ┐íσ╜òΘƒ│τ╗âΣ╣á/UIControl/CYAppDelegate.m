//
//  CYAppDelegate.m
//  UIControl
//
//  Created by lcy on 14/11/26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"

@implementation CYAppDelegate
{
    UIButton *btn;
    UILabel *_firstLabel;
    UILabel *_secondLabel;
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    UIView *view = nil;
    
    UIControl *control = [[UIControl alloc] initWithFrame:CGRectMake(40, 40, 100, 100)];
    control.backgroundColor = [UIColor redColor];
    //id  由谁来处理该消息  ---> self
    //action  执行的方法
    //state  != Event
    /*
     UIControlEventTouchDown  按下          = 1 <<  0,      // on all touch downs
     UIControlEventTouchDownRepeat     = 1 <<  1,      // on multiple touchdowns (tap count > 1)
     UIControlEventTouchDragInside     = 1 <<  2,
     UIControlEventTouchDragOutside    = 1 <<  3,

     UIControlEventTouchUpInside       = 1 <<  6,
     UIControlEventTouchUpOutside      = 1 <<  7,
     */
    //监听事件。
    //[control addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpOutside];
    //[self.window addSubview:control];
    
    btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(100, 220, 100, 100);
    [btn setTitle:@"录音" forState:UIControlStateNormal];
    
    [btn addTarget:self action:@selector(touchDown) forControlEvents:UIControlEventTouchDown];
    [btn addTarget:self action:@selector(TouchOutSide) forControlEvents:UIControlEventTouchDragOutside];
    [btn addTarget:self action:@selector(touchInSide) forControlEvents:UIControlEventTouchUpInside];
    [self.window addSubview:btn];
    
    _firstLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 60, 320, 40)];
    _firstLabel.textAlignment = NSTextAlignmentCenter;
    
    _secondLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 120, 320, 40)];
    _secondLabel.textAlignment = NSTextAlignmentCenter;
    
    [self.window addSubview:_firstLabel];
    [self.window addSubview:_secondLabel];
    return YES;
}
//state  events
-(void)touchInSide
{
    _firstLabel.text= @"";
    _secondLabel.text = @"发送成功";
}

-(void)TouchOutSide
{
    _firstLabel.text= @"";
    _secondLabel.text = @"取消发送";
}

-(void)touchDown
{
    _firstLabel.text = @"正在录音,上滑取消...";
    _secondLabel.text = @"松手发送";
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
