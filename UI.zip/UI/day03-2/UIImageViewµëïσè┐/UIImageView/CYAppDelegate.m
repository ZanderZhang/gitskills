//
//  CYAppDelegate.m
//  UIImageView
//
//  Created by lcy on 14/11/27.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"

@implementation CYAppDelegate
{
    NSInteger _cnt;
    BOOL _flag; //NO
    CGRect _oldFrame;
}

-(void)createUIImageView//*做圆脸头像
{
    //1@2x.png --->
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100,200)];
    imgView.image = [UIImage imageNamed:@"2"];
    
    //image 显示模式
    /*
     UIViewContentModeScaleToFill,  直接拉伸 填充整个imgView
     UIViewContentModeScaleAspectFit,      // contents scaled to fit with fixed aspect. remainder is transparent
     UIViewContentModeScaleAspectFill,
    */
    imgView.contentMode = UIViewContentModeScaleAspectFit;
    [self.window addSubview:imgView];
    
    UIImageView *imgView1 = [[UIImageView alloc] initWithFrame:CGRectMake(50, 300, 100,100)];
    imgView1.layer.borderWidth = 1.0f;
    imgView1.layer.cornerRadius = 50.0f;
    
    imgView1.clipsToBounds = YES;
    
    imgView1.image = [UIImage imageNamed:@"4.jpg"];
    [self.window addSubview:imgView1];
}

-(void)ImageView_Exc
{
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 50, 300, 300)];
    imgView.image = [UIImage imageNamed:@"1.jpg"];
    imgView.tag = 100;
    _cnt = 1;
    [self.window addSubview:imgView];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    btn.frame = CGRectMake(100, 400, 120, 40);
    [btn setTitle:@"next" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.window addSubview:btn];
}

-(void)btnClick
{
    _cnt ++;   //4.jpg
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",_cnt]];
    UIImageView *imgView = (UIImageView *)[self.window viewWithTag:100];
    
    imgView.image = image;
    
    if(_cnt == 4)
    {
        _cnt = 0;
    }
}


-(void)tapImageView
{
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 50, 120, 200)];
    imgView.image = [UIImage imageNamed:@"1.jpg"];
    imgView.tag = 100;
    
    //手势的操作***
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [imgView addGestureRecognizer:tap];
    imgView.userInteractionEnabled = YES;  //交互。
    [self.window addSubview:imgView];
}

-(void)tap:(UITapGestureRecognizer *)sender
{
    UIImageView *imgView = (UIImageView *)sender.view;
    //(UIImageView *)[self.window viewWithTag:100];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2.0f];
    if(!_flag)
    {
        _oldFrame = imgView.frame;
        imgView.frame = CGRectMake(0, 0, 320, 480);
    }
    else
    {
        imgView.frame = _oldFrame;
    }
    [UIView commitAnimations];
    _flag = !_flag;
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    [self tapImageView];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
