//
//  CYViewController.m
//  UIImageView1
//
//  Created by zhangyong on 14-12-10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYViewController.h"

@interface CYViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
- (IBAction)tap:(id)sender;
@property(nonatomic)CGRect frame;
@property(nonatomic)BOOL flag;
@end

@implementation CYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap)];
    [_imgView addGestureRecognizer:tap];
    _frame=_imgView.frame;
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)tap
{
    if (!_flag) {
        [UIView animateWithDuration:2 animations:^{
            _imgView.frame=self.view.bounds;
            
        } completion:^(BOOL finished) {
            
        }];
    } else {
        _imgView.frame=_frame;
    }
    _flag=!_flag;
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tap:(id)sender {
}
@end
