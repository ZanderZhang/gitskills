//
//  CYAppDelegate.m
//  Calc
//
//  Created by lcy on 14/11/27.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"

enum
{
    ONE = 1,  //0
    TWO,
    THREE,
    ADD,
    FOUR,
    FIVE,
    SIX,
    SUB,
    SEVEN,
    EIGHT,
    NINE,
    MUL,
    ZERO,
    EQUAL,
    AC,
    DIV
};

@implementation CYAppDelegate
{
    
    UILabel *_result;
    
    //保存 运算符号左边的值.
    NSInteger _leftValue;
    
    //保存 运算符号右边的值.
    NSInteger _rightValue;
    
    //保存输入的内容
    NSMutableString *_inputStr;
    
    //保存运算符
    NSString *_oper;
}

-(void)drawUI
{
    NSArray *content = @[@"1",@"2",@"3",@"+",@"4",@"5",@"6",@"-",@"7",@"8",@"9",@"*",@"0",@"=",@"AC",@"/"];
    _inputStr = [[NSMutableString alloc] init];
    _result = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 160)];
    _result.textAlignment = NSTextAlignmentRight;
    _result.backgroundColor = [UIColor yellowColor];
    
    [self.window addSubview:_result];
    
    NSInteger num = 0;
    for (NSInteger i = 0; i < 4; i++) {
        for (NSInteger j = 0; j < 4; j++) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            [btn setTitle:content[num++] forState:UIControlStateNormal];
            //1 - 16
            btn.tag = num;
            btn.frame = CGRectMake(j * 80, i * 80+160, 79, 79);
            if(i < 3 && j < 3)
            {
                btn.backgroundColor = [UIColor purpleColor];
            }
            else
            {
                 btn.backgroundColor = [UIColor orangeColor];
            }
            [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.window addSubview:btn];
        }
    }
}

-(NSString *)getValue
{
    NSInteger result = 0;
    //@"+"
    unichar sign = [_oper characterAtIndex:0];
    switch (sign) {
        case '+':
            result = _leftValue + _rightValue;
            break;
        case '-':
            result = _leftValue - _rightValue;
            break;
        case '*':
            result = _leftValue * _rightValue;
            break;
        case '/':
            result = _leftValue / _rightValue;
            break;
            
        default:
            break;
    }
    
    return [NSString stringWithFormat:@"%d",result];
}

-(void)btnClick:(UIButton *)btn
{
    switch (btn.tag) {
        case ONE:
        case TWO:
        case THREE:
        case FOUR:
        case FIVE:
        case SIX:
        case SEVEN:
        case EIGHT:
        case NINE:
        case ZERO:
            [_inputStr appendString:btn.titleLabel.text];
            _result.text = _inputStr;
            break;
            
        case ADD:
        case SUB:
        case MUL:
        case DIV:
            //+ - * /
            //保存左边值
            _leftValue = [_inputStr integerValue];
            _oper = btn.titleLabel.text;
            [_inputStr setString:@""];
            _result.text = _inputStr;
            break;
            
        case EQUAL:
            //保存右边的值
            _rightValue = [_inputStr integerValue];
            
            _result.text = [self getValue];
            [_inputStr setString:@""];
            break;
            
        case AC:
            [_inputStr setString:@"0"];
            _result.text = _inputStr;
            break;
            
        default:
            break;
    }
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    
    [self drawUI];
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
