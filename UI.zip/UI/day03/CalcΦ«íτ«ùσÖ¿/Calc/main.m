//
//  main.m
//  Calc
//
//  Created by lcy on 14/11/27.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CYAppDelegate class]));
    }
}
