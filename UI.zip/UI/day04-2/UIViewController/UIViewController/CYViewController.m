//
//  CYViewController.m
//  UIViewController
//
//  Created by lcy on 14/11/28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYViewController.h"
#import "CYSecViewController.h"

@interface CYViewController ()

@end

@implementation CYViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

//xib
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

//加载视图 view
//1.创建view   调用父类的loadView
//2.view UIView
//如果loadView 中没有创建view = nil
//viewDidLoad  是允许访问view.
-(void)loadView
{
    [super loadView];
    //self.view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
}

//
//初始化  viewDidLoad 一次
- (void)viewDidLoad
{
    [super viewDidLoad];
    ////如果loadView 中没有创建view = nil self.view 触发 loadView
    //NSLog(@"%@",self.view);
    // Do any additional setup after loading the view.
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(100, 100, 220, 200)];
    label.text = @"helloworld";
    self.view.backgroundColor = [UIColor redColor];
    [self.view addSubview:label];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    btn.frame = CGRectMake(0, 400, 320, 40);
    [btn setTitle:@"nextVC" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
   // UIImageView  1.jpg
    
}

//模态视图
-(void)btnClick
{
    //跳转
    CYSecViewController *sec = [[CYSecViewController alloc] init];
    
    /*
     UIModalTransitionStyleCoverVertical = 0,
     UIModalTransitionStyleFlipHorizontal,
     UIModalTransitionStyleCrossDissolve,
     #if __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_3_2
     UIModalTransitionStylePartialCurl,
     
     
     */
    sec.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [self presentViewController:sec animated:YES completion:^{
        
    }];
    
}

//一般 界面显示的时候,刷新UI .
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

//推到后台 不会执行该方法
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
