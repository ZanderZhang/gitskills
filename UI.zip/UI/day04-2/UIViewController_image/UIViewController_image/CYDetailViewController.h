//
//  CYDetailViewController.h
//  UIViewController_image
//
//  Created by lcy on 14/11/28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYDetailViewController : UIViewController
@property (nonatomic,strong) UIImage *image;
@end
