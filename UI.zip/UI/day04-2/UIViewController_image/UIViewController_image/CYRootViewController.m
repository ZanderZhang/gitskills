//
//  CYRootViewController.m
//  UIViewController_image
//
//  Created by lcy on 14/11/28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"
#import "CYDetailViewController.h"
#import "CYAppDelegate.h"
@interface CYRootViewController ()

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    for (NSInteger i = 0; i < 4 ; i++) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(i*80, 50, 79, 79)];
        
        imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",i+1]];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
        
        [imgView addGestureRecognizer:tap];
        
        imgView.userInteractionEnabled = YES;
        
        [self.view addSubview:imgView];
    }
}

-(void)tap:(UITapGestureRecognizer *)sender
{
    //得到点的imageView
    UIImageView *imgView = (UIImageView *)sender.view;
    
//    CYAppDelegate *appDelegate =[[UIApplication sharedApplication] delegate];
//    appDelegate.image = imgView.image;
    
    CYDetailViewController *detail = [[CYDetailViewController alloc] init];
    
    detail.image = imgView.image;
    [self presentViewController:detail animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
