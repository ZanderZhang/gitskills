//
//  CYSecViewController.h
//  UIViewController
//
//  Created by lcy on 14/11/28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CYSetLabelText.h"

@interface CYSecViewController : UIViewController
@property (nonatomic,weak) id <CYSetLabelText> delegate;
@end
