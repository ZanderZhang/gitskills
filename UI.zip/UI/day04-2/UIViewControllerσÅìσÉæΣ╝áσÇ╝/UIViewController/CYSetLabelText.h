//
//  CYSetLabelText.h
//  UIViewController
//
//  Created by lcy on 14/11/28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CYSetLabelText <NSObject>

-(void)setLabelText:(NSString *)text;

@end
