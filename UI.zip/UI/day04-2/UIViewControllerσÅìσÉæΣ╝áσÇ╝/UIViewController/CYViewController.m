//
//  CYViewController.m
//  UIViewController
//
//  Created by lcy on 14/11/28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYViewController.h"
#import "CYSecViewController.h"
#import "CYAppDelegate.h"
//UIApplication

NSString *str = nil;
@interface CYViewController ()

@end

@implementation CYViewController
{
    UILabel *label;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

//xib
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)setLabelText:(NSString *)text
{
    label.text = text;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(100, 100, 220, 200)];
    
    self.view.backgroundColor = [UIColor redColor];
    [self.view addSubview:label];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    btn.frame = CGRectMake(0, 400, 320, 40);
    [btn setTitle:@"nextVC" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}

//模态视图
-(void)btnClick
{
    //跳转
    CYSecViewController *sec = [[CYSecViewController alloc] init];
    
    sec.delegate = self;
    
    sec.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [self presentViewController:sec animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
