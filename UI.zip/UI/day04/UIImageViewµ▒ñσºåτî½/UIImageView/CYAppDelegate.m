//
//  CYAppDelegate.m
//  UIImageView
//
//  Created by lcy on 14/11/28.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"
#import "RootViewController.h"
@implementation CYAppDelegate
{
    BOOL _flag;
    CGRect _oldRect;
}

-(void)UIImageView_exc
{
    for (NSInteger i = 0; i < 4; i++) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(i * 80, 50, 79, 79)];
        
        imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",i+1]];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
        
        [imgView addGestureRecognizer:tap];
        //{
        //  tap.view = imgView
        //}
        imgView.userInteractionEnabled = YES;
        
        //UISwipeGestureRecognizer *swip ;
        //= [UISwipeGestureRecognizer alloc] initWithTarget:<#(id)#> action:<#(SEL)#>;
        //swip.direction
        [self.window addSubview:imgView];
    }
}

-(void)tap:(UITapGestureRecognizer *)sender
{
    //flash
    UIImageView *imgView = (UIImageView *)sender.view;
    
    if(!_flag)
    {
        _oldRect = imgView.frame;
        [self.window bringSubviewToFront:imgView];
        [UIView animateWithDuration:0.1f animations:^{
            imgView.center = self.window.center;   //动画时间有bug，quick help 有帮助
        } completion:^(BOOL finished) {
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.1f];
            imgView.frame = CGRectMake(0, 0, 320, 480);
            [UIView commitAnimations];
        }];
    }
    else
    {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.1f];
        imgView.frame = _oldRect;
        [UIView commitAnimations];
    }
    _flag = !_flag;
}
//main

-(void)imageViewAnimation//TOM猫动画
{
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    imgView.tag = 100;
    imgView.image = [UIImage imageNamed:@"cat_fart0000.jpg"];
    
    NSMutableArray *imgArr = [[NSMutableArray alloc] init];
    
    for (NSInteger i = 1; i < 28; i++) {
        NSString *imgName = [NSString stringWithFormat:@"cat_fart00%02d.jpg",i];
        UIImage *img = [UIImage imageNamed:imgName];
        [imgArr addObject:img];
    }
   
    //setAnimationIamges
    [imgView setAnimationImages:imgArr];
    
    [self.window addSubview:imgView];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(100, 400, 120, 40);
    [btn setTitle:@"run" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.window addSubview:btn];
}

-(void)btnClick
{
    UIImageView *imgView = (UIImageView *)[self.window viewWithTag:100];
    
    [imgView setAnimationDuration:2.0f];
    [imgView setAnimationRepeatCount:2];
    [imgView startAnimating];
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    RootViewController *rv=[[RootViewController alloc]initWithNibName:@"RootViewController" bundle:0];
    self.window.rootViewController=rv;
    //[self UIImageView_exc ];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
