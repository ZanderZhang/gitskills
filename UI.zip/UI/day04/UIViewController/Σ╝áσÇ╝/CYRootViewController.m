//
//  CYRootViewController.m
//  UIViewController
//
//  Created by zhangyong on 14-12-10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"
#import "CYSecViewController.h"
#import "CYAppDelegate.h"
#import "ChangeLabelText.h"
@interface CYRootViewController () <ChangeLabelText>
- (IBAction)btn:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)ChangeLabelText:(NSString *)labelText{
    _label.text=labelText;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
   
    // Do any additional setup after loading the view from its nib.
}
//-(void)viewWillAppear:(BOOL)animated
//{
//    CYAppDelegate *app=[UIApplication sharedApplication].delegate;
//    _label.text=app.labeltext;
//    
//}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn:(id)sender {
    CYSecViewController *sec=[[CYSecViewController alloc]initWithNibName:@"CYSecViewController" bundle:0];
    sec.delegate=self;
    [self presentViewController:sec animated:YES completion:^{
        
    }];
    
}
@end
