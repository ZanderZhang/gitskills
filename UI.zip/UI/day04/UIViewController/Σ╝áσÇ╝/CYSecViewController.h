//
//  CYSecViewController.h
//  UIViewController
//
//  Created by zhangyong on 14-12-10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChangeLabelText.h"
@interface CYSecViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *label;
@property(nonatomic,weak)id<ChangeLabelText>delegate;
- (IBAction)btn:(id)sender;

@end
