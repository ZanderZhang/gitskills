//
//  ChangeLabelText.h
//  UIViewController
//
//  Created by zhangyong on 14-12-10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ChangeLabelText <NSObject>
-(void)ChangeLabelText:(NSString *)labelText;
@end
