//
//  CYRootViewController.m
//  UINavgationController
//
//  Created by lcy on 14/11/29.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"
#import "CYSecondViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad//代理都设weak
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.tag = 10000;
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    btn.frame = CGRectMake(60, 80, 200, 40);
    [btn setTitle:@"nextVC" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
     NSLog(@"%@", self.navigationController);
}

//UIViewController
-(void)btnClick
{
    CYSecondViewController *sec = [[CYSecondViewController alloc] init];
    sec.view.backgroundColor = [UIColor colorWithRed:arc4random() % 256 / 255.0f green:arc4random() % 256 / 255.0f  blue:arc4random() % 256 / 255.0f  alpha:1.0f];
    [self.navigationController pushViewController:sec animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
