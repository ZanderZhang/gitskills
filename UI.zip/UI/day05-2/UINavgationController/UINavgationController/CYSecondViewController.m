//
//  CYSecondViewController.m
//  UINavgationController
//
//  Created by lcy on 14/11/29.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYSecondViewController.h"
#import "CYRootViewController.h"

@interface CYSecondViewController ()

@end

@implementation CYSecondViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor purpleColor];
    //self.na
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    btn.frame = CGRectMake(60, 80, 200, 40);
    [btn setTitle:@"perVC" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];


}

-(void)btnClick
{
    //
    //CYRootViewController *rvc = [[CYRootViewController alloc] init];
    //把当前的viewController 出栈  返回上一级
    [self.navigationController popViewControllerAnimated:YES];//返回上一页
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if(vc.view.tag == 10000)
        {
            //跳到指定的viewController
            [self.navigationController popToViewController:vc animated:YES];//返回指定页面
        }
    }
    [self.navigationController popToRootViewControllerAnimated:YES];//返回首页
}//电子书设置一样

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
