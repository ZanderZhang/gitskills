//
//  CYRootViewController.m
//  UITextFile
//
//  Created by lcy on 14/11/29.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController
{
    UITextField *field;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor redColor];
    field = [[UITextField alloc] initWithFrame:CGRectMake(40, 50, 200, 40)];
    
    /*
     UITextBorderStyleNone, //default
     UITextBorderStyleLine,
     UITextBorderStyleBezel,
     UITextBorderStyleRoundedRect
     */
    field.borderStyle = UITextBorderStyleRoundedRect;
    //设置默认文字
    field.placeholder = @"helloworld";
    //设置密文
    //field.secureTextEntry = YES;
    //下一次点击的时候 把 之前的内容清空
    //field.clearsOnBeginEditing = YES;
    //设置输入的内容限制
    //field.keyboardType = UIKeyboardTypePhonePad;
    //设置键盘的样式
    field.keyboardAppearance = UIKeyboardAppearanceAlert;
    field.returnKeyType = UIReturnKeyDefault;
    field.adjustsFontSizeToFitWidth = YES;
    /*
     UITextFieldViewModeNever,
     UITextFieldViewModeWhileEditing,
     UITextFieldViewModeUnlessEditing,
     UITextFieldViewModeAlways
     */
    field.clearButtonMode = UITextFieldViewModeAlways;//设置删除箭头
    
    field.delegate = self;//**设置代理，找到代理

    [self.view addSubview:field];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    
    [self.view addGestureRecognizer:tap];
}


-(void)tap
{
    //使textField 失去第一响应者
    [field resignFirstResponder];
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}// return NO to disallow editing.

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}// became first responder

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSLog(@"%@",textField.text);//获取输入的内容
    NSLog(@"%@",NSStringFromSelector(_cmd));

}// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
//
//有一个默认的内容 “abc”
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{//控制输入
    if([textField.text isEqualToString:@"abc"])
    {
        return NO;
    }
    return YES;
}// return NO to not change text
//

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    return YES;
}// called when clear button pressed. return NO to ignore (no notifications)
//删除不了

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
    [textField resignFirstResponder];//按return 也放弃第一响应者
    return YES;
}// called when 'return' key pressed. return NO to ignore.


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
