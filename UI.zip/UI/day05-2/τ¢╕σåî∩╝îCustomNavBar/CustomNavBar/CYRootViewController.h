//
//  CYRootViewController.h
//  CustomNavBar
//
//  Created by lcy on 14/11/29.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYRootViewController : UIViewController

@end
