//
//  CYSecViewController.m
//  CustomNavBar
//
//  Created by zhangyong on 14-12-13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYSecViewController.h"

@interface CYSecViewController ()
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activity;

@end

@implementation CYSecViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor blackColor];
    [self performSelector:@selector(delay) withObject:self afterDelay:2];

    // Do any additional setup after loading the view from its nib.
}
-(void)delay
{
    [_activity stopAnimating];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
