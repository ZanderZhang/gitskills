//
//  CYThirdViewController.m
//  CustomNavBar
//
//  Created by zhangyong on 14-12-13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYThirdViewController.h"
#import "CYAppDelegate.h"
#import "CYSecViewController.h"
@interface CYThirdViewController ()



@end

@implementation CYThirdViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor redColor];
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap)];
    [self.view addGestureRecognizer:tap];
    // Do any additional setup after loading the view from its nib.
}
-(void)tap
{
    CYAppDelegate *ap=[UIApplication sharedApplication].delegate;
    CYSecViewController *sec=[[CYSecViewController alloc]init];
    
    ap.window.rootViewController=sec;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
