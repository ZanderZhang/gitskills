//
//  CYViewController.h
//  张勇
//
//  Created by zhangyong on 14-12-13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYViewController : UIViewController
@property (weak, nonatomic) IBOutlet UISwitch *mySwith;

@end
