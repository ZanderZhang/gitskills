//
//  CYViewController.m
//  张勇
//
//  Created by zhangyong on 14-12-13.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYViewController.h"
#import "CYAppDelegate.h"
#import "CYSecViewController.h"
#import "CYThirdViewController.h"
@interface CYViewController ()
@property(nonatomic,strong)CYSecViewController *sec;
@property(nonatomic,strong)CYThirdViewController *third;

@property (nonatomic,strong)CYAppDelegate *app;
@end

@implementation CYViewController
- (IBAction)mySwitch:(id)sender {
    switch (_mySwith.on) {
        case 1:
        {
            _app.window.rootViewController=_sec;
        }
            break;
        case 0 :
        {
            _app.window.rootViewController=_third;

        }
            break;
            
        default:
            break;
    }

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _sec=[[CYSecViewController alloc]init];
    _third=[[CYThirdViewController alloc]init];

    _app=[UIApplication sharedApplication].delegate;
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap)];
    [self.view addGestureRecognizer:tap];
    // Do any additional setup after loading the view from its nib.
}
-(void)tap
{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

	// Do any additional setup after loading the view, typically from a nib.


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
