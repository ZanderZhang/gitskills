//
//  CYRootViewController.m
//  SelectHead
//
//  Created by lcy on 14/11/29.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"
#import "CYSelectViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController
{
    UIImageView *imgView;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)setImageView:(UIImage *)image
{
    imgView.image = image;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor purpleColor];
    
    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    
    imgView.image = [UIImage imageNamed:@"1.jpg"];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [imgView addGestureRecognizer:tap];
    
    imgView.userInteractionEnabled = YES;
    [self.view addSubview:imgView];
}
-(void)tap:(UITapGestureRecognizer *)sender
{
    CYSelectViewController *select = [[CYSelectViewController alloc] init];
    
    select.delegate = self;
    
    [self presentViewController:select animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
