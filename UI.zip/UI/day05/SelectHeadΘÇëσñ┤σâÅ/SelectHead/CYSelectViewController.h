//
//  CYSelectViewController.h
//  SelectHead
//
//  Created by lcy on 14/11/29.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CYSetImageView.h"

@interface CYSelectViewController : UIViewController
@property (nonatomic,weak) id <CYSetImageView> delegate;
@end
