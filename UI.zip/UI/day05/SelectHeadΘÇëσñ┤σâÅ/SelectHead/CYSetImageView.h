//
//  CYSetImageView.h
//  SelectHead
//
//  Created by lcy on 14/11/29.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CYSetImageView <NSObject>

-(void)setImageView:(UIImage *)image;

@end
