//
//  CYRootViewController.m
//  UINavgationController
//
//  Created by zhangyong on 14-12-10.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"
#import "CYSecViewController.h"
@interface CYRootViewController ()
- (IBAction)click:(id)sender;

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
CYSecViewController *sec=0;
- (void)viewDidLoad
{
    [super viewDidLoad];  self.navigationItem.backBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"backssfd" style:UIBarButtonItemStylePlain target:sec action:@selector(back)];
   
    
    NSLog(@"%@",NSStringFromCGRect(self.view.frame));
//    UILabel *l=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 100, 100)];
//    l.backgroundColor=[UIColor redColor];
//    [self.view addSubview:l];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    sec.label.text=@"woshisb";
    self.label.text=@"tashisui";
}
-(void)back
{
    sec.label.text=@"woshisb";
    self.label.text=@"tashisui";
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)click:(id)sender {
    sec=[[CYSecViewController alloc]initWithNibName:@"CYSecViewController" bundle:0];
    [self.navigationController pushViewController:sec animated:YES];
}
@end
