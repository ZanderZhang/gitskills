//
//  CYRootViewController.m
//  UITouch
//
//  Created by lcy on 14/12/1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
UIView *view = nil;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor orangeColor];
    
    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    
    view.backgroundColor = [UIColor redColor];
    [self.view addSubview:view];
//    UIButton *btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
//    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
//    btn.frame=CGRectMake(0, 0, 0, 0);
//    [self.view addSubview:btn];
    
    
    
}

-(void)click{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

//
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:view];
    
    NSLog(@"%@",NSStringFromCGPoint(point));
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    //NSLog(@"%@",NSStringFromSelector(_cmd));
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self.view];
    
    view.center = point;
    NSLog(@"%@",NSStringFromCGPoint(point));
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
