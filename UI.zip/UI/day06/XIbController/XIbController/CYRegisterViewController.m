//
//  CYRegisterViewController.m
//  XIbController
//
//  Created by lcy on 14/12/1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRegisterViewController.h"

@interface CYRegisterViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *userPasswd;
- (IBAction)ageChange:(id)sender;
@property (weak, nonatomic) IBOutlet UISegmentedControl *genderSegment;
@property (weak, nonatomic) IBOutlet UILabel *ageLabel;
@property (weak, nonatomic) IBOutlet UITextView *textView;
- (IBAction)btnClick:(id)sender;
- (IBAction)tap:(id)sender;

@end

@implementation CYRegisterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ageChange:(id)sender {
    UIStepper *step = (UIStepper *)sender;
    
    self.ageLabel.text = [NSString stringWithFormat:@"%d",(int)step.value];
}
- (IBAction)btnClick:(id)sender {
    NSLog(@"%@",self.userName.text);
    NSLog(@"%@",self.userPasswd.text);
    
    if(self.genderSegment.selectedSegmentIndex == 0)
    {
        NSLog(@"男");
    }
    else
    {
        NSLog(@"女");
    }
    
    NSLog(@"%@",self.ageLabel.text);
    NSLog(@"%@",self.textView.text);
}

- (IBAction)tap:(id)sender {
    //NSLog(@"sdfadfafda");
//    [self.userName resignFirstResponder];
//    [self.userPasswd resignFirstResponder]
    [self.view endEditing:YES];
}
@end
