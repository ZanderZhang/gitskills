//
//  CYRootViewController.m
//  XIbController
//
//  Created by lcy on 14/12/1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

//扩展   扩展字段
@interface CYRootViewController ()
@property (weak, nonatomic) IBOutlet UITextField *passwd;
- (IBAction)btnClick:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *userName;
@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //self.view addSubview:<#(UIView *)#>
    self.userName.text = @"123";
    self.passwd.text = @"abc";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnClick:(id)sender {
    NSLog(@"%@",NSStringFromSelector(_cmd));
}
@end
