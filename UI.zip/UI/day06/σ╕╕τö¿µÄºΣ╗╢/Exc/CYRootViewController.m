//
//  CYRootViewController.m
//  Exc
//
//  Created by lcy on 14/12/1.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController
{
    UISlider *slider;
    UIStepper *step;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)createSegmentControl
{
    UISegmentedControl *segment = [[UISegmentedControl alloc] initWithItems:@[@"男",@"女"]];
    segment.frame = CGRectMake(0, 100, 100, 40);
    //得到分段控制器的分段个数
    NSLog(@"%u",segment.numberOfSegments);
    //设置默认选中
    segment.selectedSegmentIndex = 0;
    [segment setTitle:@"千峰" forSegmentAtIndex:0];
    [segment setImage:[UIImage imageNamed:@"tab_me_nor"] forSegmentAtIndex:1];
    //动态的增加内容
    [segment insertSegmentWithTitle:@"hello" atIndex:1 animated:YES];
    //删除
    [segment removeSegmentAtIndex:2 animated:YES];
    //监听事件
    [segment addTarget:self action:@selector(valueChange:) forControlEvents:UIControlEventValueChanged];
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 200, 40)];
    self.navigationItem.titleView = view;
    [view addSubview:segment];
    
    //[self.view addSubview:segment];
}



-(void)valueChange:(id)sender
{
    switch ([sender tag]) {
        case 1000:
        {
            UISwitch *sw = (UISwitch *)sender;
            NSLog(@"%d",sw.on);
            NSString *str = [NSString stringWithFormat:@"%d",sw.on];
            
            [str writeToFile:@"/Users/lcy/Desktop/test" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        }
            break;
            
        case 2000:
        {
            UIStepper *step = (UIStepper *)sender;
            NSLog(@"%lf",step.value);
            slider.value = step.value;
        }
            break;
        case 3000:
        {
            UISlider *slider = (UISlider *)sender;
            //NSLog(@"%lf",slider.value);
            step.value = slider.value;
            NSLog(@"xxxxx%lf",step.value);

        }
            break;
            
        default:
            break;
    }
}

-(void) createUISwitch
{
    UISwitch *sw = [[UISwitch alloc] init];
    sw.tag = 1000;
    sw.frame = CGRectMake(50, 100, 100, 40);
    NSString *str = [NSString stringWithContentsOfFile:@"/User  s/lcy/Desktop/test" encoding:NSUTF8StringEncoding error:nil];
    sw.on = [str integerValue];
    NSLog(@"%d",sw.on);
    
    [sw addTarget:self action:@selector(valueChange:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:sw];
}

-(void)createUIStepper
{
    step = [[UIStepper alloc] initWithFrame:CGRectMake(100, 100, 100, 50)];
    step.tag = 2000;
    //注册年龄
    //最大最小值
    step.minimumValue = 0;
    step.maximumValue = 100;
    //设置步进值
    //step.stepValue =  10;
    //到最大值 回到最小值
    step.wraps = YES;
    [step addTarget:self action:@selector(valueChange:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:step];
}

-(void)createUISlider
{
    slider = [[UISlider alloc] initWithFrame:CGRectMake(100, 300, 100, 40)];
    
    slider.tag = 3000;
    //最大值
    slider.maximumValue = 100;
    slider.minimumValue = 0;
    slider.value = 0;
    //改变滑块左右两边的颜色
    slider.minimumTrackTintColor = [UIColor orangeColor];
    slider.maximumTrackTintColor = [UIColor blueColor];
    //[slider setThumbImage:[UIImage imageNamed:@"tab_me_nor"] forState:UIControlStateNormal];
    //0 - 100
    [slider addTarget:self action:@selector(valueChange:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:slider];
}

UIProgressView *pro = nil;
-(void)createProgressView
{
    pro = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
    pro.frame = CGRectMake(100, 100, 200, 40);
    //设置默认进度
    pro.progress = 0; //0 - 1.0f
    //timer
    //scheduledTimerWithTimeInterval 间隔时间
    //target self
    //repeats NO 只会执行一次  YES
    
    //NSFileHandle  copy  --->  500   size
    [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(timer:) userInfo:pro repeats:YES];
    [self.view addSubview:pro];
}

-(void)timer:(NSTimer *)timer
{
    UIProgressView *pro1 = (UIProgressView *)timer.userInfo;
    pro1.progress += 0.1;
}

UIActivityIndicatorView *activity = nil;
-(void)createActivityIndicatorView
{
    /*
     UIActivityIndicatorViewStyleWhiteLarge,
     UIActivityIndicatorViewStyleWhite,
     UIActivityIndicatorViewStyleGray
     */
    activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activity.frame = CGRectMake(100, 100, 80, 80);
    activity.backgroundColor = [UIColor redColor];
    //停止动画隐藏
    activity.hidesWhenStopped = NO;
    [activity startAnimating];
    //[activity stopAnimating];
  
    [self performSelector:@selector(dealy) withObject:nil afterDelay:2.0f];
    [self.view addSubview:activity];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

-(void)dealy
{
    [activity stopAnimating];
    activity.hidesWhenStopped = YES;
   // [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

//多行文本编辑控件
//导航条和scrollView 连用  光标或者视图 会有偏移 需要设置viewController 的一个属性automaticallyAdjustsScrollViewInsets



UITextView *textView = nil;
-(void)createTextView
{
    self.automaticallyAdjustsScrollViewInsets = NO;
    textView = [[UITextView alloc] initWithFrame:CGRectMake(80, 80, 200, 300)];
    
    textView.layer.borderWidth = 1.0f;
    //textView.layer.cornerRadius = 25.0f;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    textView.showsVerticalScrollIndicator = NO;
    textView.scrollEnabled = NO;
    
    textView.delegate = self;
    
    //textView.returnKeyType
    //textView.keyboardAppearance
    //textView.keyboardType
    [self.view addGestureRecognizer:tap];
    [self.view addSubview:textView];
}

-(void)tap
{
    [textView resignFirstResponder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self createActivityIndicatorView];
    //[self createUISlider];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
