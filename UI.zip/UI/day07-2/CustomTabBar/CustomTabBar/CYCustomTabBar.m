//
//  CYCustomTabBar.m
//  CustomTabBar
//
//  Created by lcy on 14/12/2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYCustomTabBar.h"
#import "CYAppDelegate.h"
#import "CYFirstViewController.h"
#import "CYSecondViewController.h"
@implementation CYCustomTabBar
{
    UIView *_baseView;
    
    UIImageView *_backGroundImageView;
    BOOL _flag;
    UIButton *_oldBtn;
    UITabBarController *tap;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        UIApplication *app=[UIApplication sharedApplication];
        CYAppDelegate *appdelegate=app.delegate;
        tap=appdelegate.tabBarController;
    
        // Initialization code
        //    _baseView = [[UIView alloc] initWithFrame:CGRectMake(0, 480-49, 320, 49)];
        //
        //    //_baseView.backgroundColor = [UIColor purpleColor];
        //    [self.tabBarController.view addSubview:_baseView];
        //
        //    _backGroundImageView = [[UIImageView alloc ] initWithFrame:CGRectMake(0, 0, 320, 49)];
        //    _backGroundImageView.image = [UIImage imageNamed:@"tabbar_bg"];
        //    //_backGroundImageView.userInteractionEnabled = YES;
        //    [_baseView addSubview:_backGroundImageView];
        //
        //    for (NSInteger i = 0; i < 8; i+=2) {
        //        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        //        btn.tag = 100 + cnt;
        //        btn.frame = CGRectMake(cnt++ * 80, 2, 80, 45);
        //
        //        [btn setImage:[UIImage imageNamed:imgName[i]] forState:UIControlStateNormal];
        //
        //        [btn setImage:[UIImage imageNamed:imgName[i+1]] forState:UIControlStateSelected];
        //
        //        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        //        [_baseView addSubview:btn];
        //    }
        //    
        //    UIButton *btn = (UIButton *)[_baseView viewWithTag:100];
        //    _oldBtn = btn;
        //    btn.selected = YES;
        NSInteger cnt=0;
         NSArray *imgName = @[@"tab_buddy_nor",@"tab_buddy_press",@"tab_me_nor",@"tab_me_press",@"tab_qworld_nor",@"tab_qworld_press",@"tab_recent_nor",@"tab_recent_press"];
      //  _baseView = [[UIView alloc] initWithFrame:CGRectMake(0, 480-49, 320, 49)];
        
        //_baseView.backgroundColor = [UIColor purpleColor];
     
       
        
        
        [tap.view addSubview:_baseView];
        
        _backGroundImageView = [[UIImageView alloc ] initWithFrame:CGRectMake(0, 0, 320, 49)];
        _backGroundImageView.image = [UIImage imageNamed:@"tabbar_bg"];
        //_backGroundImageView.userInteractionEnabled = YES;
        [self addSubview:_backGroundImageView];
        
        for (NSInteger i = 0; i < 8; i+=2) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.tag = 10 + cnt;
            btn.frame = CGRectMake(cnt++ * 80, 2, 80, 45);
            
            [btn setImage:[UIImage imageNamed:imgName[i]] forState:UIControlStateNormal];
            
            [btn setImage:[UIImage imageNamed:imgName[i+1]] forState:UIControlStateSelected];
            
            [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btn];
        }
        
        UIButton *btn = (UIButton *)[_baseView viewWithTag:100];
        _oldBtn = btn;
        btn.selected = YES;

    }
    return self;
}


-(void)btnClick:(UIButton *)sender
{
    _oldBtn.selected = NO;
    _oldBtn = sender;

    sender.selected = YES;
    
    //    [UIApplication sharedApplication].delegate
  
    tap.selectedIndex = sender.tag-10;
}

-(void)tap
{
    //0.25  - 0.3
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3f];
    
    if(!_flag)
    {
        _baseView.frame = CGRectMake(0, 480, 320, 49);
    }
    else
    {
        _baseView.frame = CGRectMake(0, 480 -49, 320, 49);
    }
    
    [UIView commitAnimations];
    _flag = !_flag;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
