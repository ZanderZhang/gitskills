//
//  CYAppDelegate.m
//  UITabBar
//
//  Created by lcy on 14/12/2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"
#import "CYFirstViewController.h"
#import "CYSeconeViewController.h"

@implementation CYAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    //tabBar ----> 49
    //tabBar ----> tabBarItem
    CYFirstViewController *firstVC = [[CYFirstViewController alloc] init];
    
    UINavigationController *firstNav = [[UINavigationController alloc] initWithRootViewController:firstVC];
    
    firstNav.tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemDownloads tag:1];
    CYSeconeViewController *secondVC = [[CYSeconeViewController alloc] init];
    secondVC.tabBarItem.tag = 2;
    
    UIViewController *viewControlelr = [[UIViewController alloc] init];
    viewControlelr.view.backgroundColor = [UIColor blueColor];
    viewControlelr.tabBarItem.title = @"3";
    viewControlelr.tabBarItem.tag = 3;
    
    UIViewController *viewControlelr1 = [[UIViewController alloc] init];
    viewControlelr1.view.backgroundColor = [UIColor orangeColor];
    viewControlelr1.tabBarItem.title = @"4";
    viewControlelr1.tabBarItem.tag = 4;
    
    UIViewController *viewControlelr2 = [[UIViewController alloc] init];
    viewControlelr2.view.backgroundColor = [UIColor yellowColor];
    viewControlelr2.tabBarItem.title = @"5";
    viewControlelr2.tabBarItem.tag = 5;
    
    UIViewController *viewControlelr3 = [[UIViewController alloc] init];
    viewControlelr3.view.backgroundColor = [UIColor cyanColor];
    viewControlelr3.tabBarItem.title = @"6";
    viewControlelr3.tabBarItem.tag = 6;
    //nav
    UITabBarController *tabController = [[UITabBarController alloc] init];
    
    //UISwitch
    //数组  tabbar最多只能显示五个. 如果超过五个 剩下的都已列表的形式显示
    
    NSMutableArray *tabBarControllers = [[NSMutableArray alloc] init];
    //1，2，3，4，6，5
    NSArray *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"data"];
    NSArray *vcs = @[firstNav,secondVC,viewControlelr,viewControlelr1,viewControlelr2,viewControlelr3]; //selectedIndex = 0
    for (NSNumber *num in data) {
        for (UIViewController *vc in vcs) {
            if(vc.tabBarItem.tag == [num integerValue])
            {
                [tabBarControllers addObject:vc];
            }
        }
    }
    
    //tabBar设置数组
    if(tabBarControllers.count == 0)
    {
        tabController.viewControllers = vcs;
    }
    else
    {
        tabController.viewControllers = tabBarControllers;
    }
    
    //tabBarController 设置默认选中
    
    NSNumber *num = [[NSUserDefaults standardUserDefaults] objectForKey:@"index"];
    NSInteger index = [num integerValue];
    if(index > 6)
    {
        tabController.selectedIndex = 4;
    }
    else
    {
        tabController.selectedIndex = index;
    }
    tabController.delegate = self;
    
    [tabController.tabBar setBackgroundImage:[UIImage imageNamed:@"tabbar_bg"]];
    
    //tabController.tabBar.hidden = YES;
    self.window.rootViewController = tabController;
    return YES;
}

//直接返回NO 说明 不能选中 tabBar中的item
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController NS_AVAILABLE_IOS(3_0)
{
//    [tabBarController.viewControllers indexOfObject:viewController];
    return YES;
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    //NSLog(@"%@",NSStringFromSelector(_cmd));
    NSInteger index = [tabBarController.viewControllers indexOfObject:viewController];
    
    //[UIApplication sharedApplication]
    //保存沙盒
    //NSUserDefaults
    [[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithInteger:index] forKey:@"index"];
    //删除数据
    //[[NSUserDefaults standardUserDefaults] removeObjectForKey:@"index"];
    //还原模拟器
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}
//
- (void)tabBarController:(UITabBarController *)tabBarController willBeginCustomizingViewControllers:(NSArray *)viewControllers NS_AVAILABLE_IOS(3_0)
{
    NSLog(@"%@",NSStringFromSelector(_cmd));

}
- (void)tabBarController:(UITabBarController *)tabBarController willEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed NS_AVAILABLE_IOS(3_0)
{
    NSLog(@"%@",NSStringFromSelector(_cmd));

}
- (void)tabBarController:(UITabBarController *)tabBarController didEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed
{
//    NSLog(@"%@",NSStringFromSelector(_cmd));
//    NSLog(@"%@",tabBarController.viewControllers);
    //viewController.tabBarItem
    
    if(changed)
    {
        NSMutableArray *data = [[NSMutableArray alloc] init];
        for (UIViewController *vc in viewControllers) {
            NSInteger tag = vc.tabBarItem.tag;
        [data addObject:[NSNumber numberWithInteger:tag]];
        }
    
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"data"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
