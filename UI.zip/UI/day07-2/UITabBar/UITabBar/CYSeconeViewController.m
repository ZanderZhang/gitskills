//
//  CYSeconeViewController.m
//  UITabBar
//
//  Created by lcy on 14/12/2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYSeconeViewController.h"

@interface CYSeconeViewController ()

@end

@implementation CYSeconeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        //tabBar里面的内容写在这里面
        self.tabBarItem.image = [UIImage imageNamed:@"1"];
        self.tabBarItem.title = @"second";
        
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"menu_icon_c2c_shortcut_press"];
        
        self.tabBarItem.badgeValue = @"1";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor purpleColor];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
