//
//  CYFirstViewController.m
//  UITabBar
//
//  Created by lcy on 14/12/2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYFirstViewController.h"

@interface CYFirstViewController ()

@end

@implementation CYFirstViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.tabBarItem.image = [UIImage imageNamed:@"menu_icon_bulb"];
        self.tabBarItem.title = @"first";
        self.tabBarItem.selectedImage = [UIImage imageNamed:@"menu_icon_bulb_pressed"];
        self.tabBarItem.badgeValue = @"new";
        
        //self.navigationController
       // self.tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemDownloads tag:0];
        
        //self.tabBarItem = [UITabBarItem alloc] initWithTitle:<#(NSString *)#> image:<#(UIImage *)#> selectedImage:<#(UIImage *)#>
        
      //  self.tabBarItem = [[UITabBarItem alloc] initWithTitle:0 image:0 tag:0];
    
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   
    
    self.view.backgroundColor = [UIColor redColor];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
