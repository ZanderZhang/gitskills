//
//  CYRootViewController.m
//  UITouch
//
//  Created by lcy on 14/12/2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"
#define FILESIZE 1871916
@interface CYRootViewController ()
{
    CGPoint beginPoint;
    CGPoint viewCenter;
    NSFileHandle *writeHandle;
    NSFileHandle *readHandle;
    CGFloat len;
}
@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)copy_file
{
    NSString *soucePath = @"/Users/lcy/Desktop/AppFree.zip";
    
    NSString *destPath = @"/Users/lcy/Desktop/abc.zip";
    
    NSFileManager *man = [NSFileManager defaultManager];
    if(![man fileExistsAtPath:destPath])
    {
        [man createFileAtPath:destPath contents:nil attributes:nil];
    }
    
    writeHandle = [NSFileHandle fileHandleForWritingAtPath:destPath];
    readHandle = [NSFileHandle fileHandleForReadingAtPath:soucePath];
}

-(void)createProgressView
{
    UIProgressView *pro = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
    
    pro.frame = CGRectMake(100, 100, 200, 40);
    
    [self.view addSubview:pro];
    
    [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(timer:) userInfo:pro repeats:YES];
}

-(void)timer:(NSTimer *)timer
{
    UIProgressView *pro = (UIProgressView *)timer.userInfo;
    
    NSData *data = [readHandle readDataOfLength:1024];
    
    if(data.length < 1024)
    {
        [timer invalidate];
    }
    
    [writeHandle writeData:data];
    len += data.length;
    
    pro.progress = len / FILESIZE;
    NSLog(@"%lf",pro.progress);
}


UIView *view = nil;
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
//    view.backgroundColor = [UIColor redColor];
//    [self.view addSubview:view];
    [self copy_file];
    [self createProgressView];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    beginPoint = [touch locationInView:self.view];
    viewCenter = view.center;
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{//侧滑效果，
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self.view]
    ;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5f];
    if(point.x > 150)
    {
        view.frame = CGRectMake(240, 0, 320, 480);
    }
    else
    {
        view.frame = CGRectMake(0, 0, 320, 480);
    }
    
    [UIView commitAnimations];
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self.view];
    NSInteger x = point.x - beginPoint.x;
    //NSInteger y = point.y - beginPoint.y;
    
    CGPoint center = CGPointMake(viewCenter.x + x, viewCenter.y);
    
    view.center = center;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
