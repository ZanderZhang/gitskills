//
//  CYRootViewController.m
//  UIScrollViewImg
//
//  Created by lcy on 14/12/3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController () 

@end

@implementation CYRootViewController
{
    UIScrollView *scroll;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
UIPageControl *pageControl = nil;
-(void)createUIPageControl
{
    pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 440, 320, 40)];
    //设置点的个数
    pageControl.numberOfPages = 4;
    //设置默认选中 的点
    //务必要由currentpage
    pageControl.currentPage = 0;
    //设置点的颜色
    pageControl.pageIndicatorTintColor = [UIColor orangeColor];
    pageControl.currentPageIndicatorTintColor = [UIColor purpleColor];
    //增加事件
    [pageControl addTarget:self action:@selector(valueChange:) forControlEvents:UIControlEventValueChanged];
    //常用控件和UIPageControl 增加事件都是使用UIControlEventValueChanged
    [self.view addSubview:pageControl];
}

-(void)valueChange:(UIPageControl *)page
{
    //NSLog(@"xxxxxxx");
    NSLog(@"%d",page.currentPage);
    //设置scroll对应偏移量
    
    [scroll setContentOffset:CGPointMake(page.currentPage * 320, 0) animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    
    for (NSInteger i = 0; i < 4; i++) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(i * 320, 0, 320, 480)];
        
        imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",i+1]];
        [scroll addSubview:imgView];
    }
    //1
    
    scroll.delegate = self;
    scroll.bounces = NO;
    scroll.pagingEnabled = YES;
    scroll.contentSize = CGSizeMake(320 * 4, 480);//***务必加个contensize
    //scroll.contentOffset = CGPointMake(320, 0); //偏移量也很重要
    [self.view addSubview:scroll];
    
    [self createUIPageControl];
    
    //[NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(timer:) userInfo:scroll repeats:YES];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    
    NSLog(@"%@",NSStringFromSelector(_cmd));
}
// called on finger up if the user dragged. velocity is in points/millisecond. targetContentOffset may be changed to adjust where the scroll view comes to rest
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset NS_AVAILABLE_IOS(5_0)
{
   
    NSLog(@"%@",NSStringFromSelector(_cmd));
}
// called on finger up if the user dragged. decelerate is true if it will continue moving afterwards
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
    
    NSLog(@"%@",NSStringFromSelector(_cmd));
}// called on finger up as we are moving

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //NSLog(@"%@",NSStringFromCGPoint(scroll.contentOffset));
    NSInteger page = scrollView.contentOffset.x / 320;
    pageControl.currentPage =  page;
    NSLog(@"%@",NSStringFromSelector(_cmd));
}// called when scroll view grinds to a halt

NSInteger cnt = 0;
-(void)timer:(NSTimer *)time
{
    UIScrollView *view = (UIScrollView *)time.userInfo;//用timer的userinfo传进来
    cnt++;
    if(cnt == 4)
    {
        cnt = 0;
    }
    
    [view setContentOffset:CGPointMake(320 * cnt, 0) animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
