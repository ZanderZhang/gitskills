//
//  CYRootViewController.m
//  UIScrollViewScale
//
//  Created by lcy on 14/12/3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController () <UIScrollViewDelegate>

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
UIImageView *imgView = nil;
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //前后各加一个imgView,设置偏移，contentsize随之增加，最后在DidEndDecelerating 里面设置跳转。
    //因为是delegate方法，务必加上协议和把代理给自己。加上代理才能把方法打出来，并有void和BOOL之分
    // Do any additional setup after loading the view.
    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    imgView.image = [UIImage imageNamed:@"4.jpg"];
    
    [scroll addSubview:imgView];
    
    for (NSInteger i = 1; i <= 4; i++) {
        imgView = [[UIImageView alloc] initWithFrame:CGRectMake(i * 320, 0, 320, 480)];
        //
        imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d",i]];
        [scroll addSubview:imgView];
    }
    
    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(5 * 320, 0, 320, 480)];
    imgView.image = [UIImage imageNamed:@"1.jpg"];
    
    [scroll addSubview:imgView];
    //    //1
    //scroll.bounces = NO;
    scroll.delegate = self;//****
    scroll.pagingEnabled = YES;
    scroll.contentSize = CGSizeMake(320 * 6, 480);
    
    scroll.contentOffset = CGPointMake(320, 0);
    
    [self.view addSubview:scroll];
    //
}

//- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
//{
//    return imgView;
//}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //-1
    NSInteger index = (scrollView.contentOffset.x - 320) / 320;
    if(index == -1)
    {
        scrollView.contentOffset = CGPointMake(4 * 320, 0);
    }
    
    if(index == 4)
    {
        scrollView.contentOffset = CGPointMake(320, 0);
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
