//
//  CYAppDelegate.m
//  CustomTabBar
//
//  Created by lcy on 14/12/2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYAppDelegate.h"
#import "CYFirstViewController.h"
#import "CYSecondViewController.h"
#import "CYCustomTabBar.h"
@implementation CYAppDelegate

-(void)createTabBar
{
    
    CYFirstViewController *first = [[CYFirstViewController alloc] init];
    first.view.backgroundColor = [UIColor redColor];
    CYSecondViewController *second = [[CYSecondViewController alloc] init];
    second.view.backgroundColor = [UIColor orangeColor];
    
    UIViewController *vc1 = [[UIViewController alloc] init];
    vc1.view.backgroundColor = [UIColor blueColor];
    UIViewController *vc2 = [[UIViewController alloc] init];
    vc2.view.backgroundColor = [UIColor cyanColor];
    self.tabBarController = [[UITabBarController alloc] init];
    
    self.tabBarController.viewControllers = @[first,second,vc1,vc2];
    
    self.tabBarController.tabBar.hidden = YES;
    self.window.rootViewController = self.tabBarController;
    
    
    CYCustomTabBar *tabBar = [[CYCustomTabBar alloc] initWithFrame:CGRectMake(0, 480-49, 320, 49)];
    
    [self.tabBarController.view addSubview:tabBar];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    [self createTabBar];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
    
    [self.window addGestureRecognizer:tap];
    return YES;
}

//-(void)tap
//{
//    //0.25  - 0.3
//    [UIView beginAnimations:nil context:nil];
//    [UIView setAnimationDuration:0.3f];
//    
//    if(!_flag)
//    {
//        _baseView.frame = CGRectMake(0, 480, 320, 49);
//    }
//    else
//    {
//        _baseView.frame = CGRectMake(0, 480 -49, 320, 49);
//    }
//    
//    [UIView commitAnimations];
//    _flag = !_flag;
//}


- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
