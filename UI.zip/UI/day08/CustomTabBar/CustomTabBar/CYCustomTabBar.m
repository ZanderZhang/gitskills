//
//  CYCustomTabBar.m
//  CustomTabBar
//
//  Created by lcy on 14/12/2.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYCustomTabBar.h"
#import "CYAppDelegate.h"

@implementation CYCustomTabBar
{
    UIButton *_oldBtn;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        NSInteger cnt = 0;
        NSArray *imgName = @[@"tab_buddy_nor",@"tab_buddy_press",@"tab_me_nor",@"tab_me_press",@"tab_qworld_nor",@"tab_qworld_press",@"tab_recent_nor",@"tab_recent_press"];
        self.backImg = [[UIImageView alloc ] initWithFrame:CGRectMake(0, 0, 320, 49)];
        self.backImg.image = [UIImage imageNamed:@"tabbar_bg"];
        
        [self addSubview:self.backImg];
        //_backGroundImageView.userInteractionEnabled = YES;
//        [_baseView addSubview:_backGroundImageView];
//        
        for (NSInteger i = 0; i < 8; i+=2) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.tag = 100 + cnt;
            btn.frame = CGRectMake(cnt++ * 80, 2, 80, 45);
            
            [btn setImage:[UIImage imageNamed:imgName[i]] forState:UIControlStateNormal];
            
            [btn setImage:[UIImage imageNamed:imgName[i+1]] forState:UIControlStateSelected];
            
            [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btn];
        }
        
        UIButton *btn = (UIButton *)[self viewWithTag:100];
        _oldBtn = btn;
        btn.selected = YES;

    }
    return self;
}

-(void)btnClick:(UIButton *)sender
{
    _oldBtn.selected = NO;
    _oldBtn = sender;
    
    sender.selected = YES;
    
    CYAppDelegate *appDelegate = [UIApplication sharedApplication].delegate;

    appDelegate.tabBarController.selectedIndex = sender.tag  - 100;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
