//
//  CYRootViewController.m
//  UIScrollView
//
//  Created by lcy on 14/12/3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController
{
    UIScrollView *scroll;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    UIImage *image = [UIImage imageNamed:@"big.jpg"];
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    imgView.image = image;
    //设置隐藏滚动条
    scroll.showsHorizontalScrollIndicator = NO;
    scroll.showsVerticalScrollIndicator = NO;
    
    //如果scroll.contentSize  <= scroll.frame 也可以有拖动效果
    scroll.alwaysBounceHorizontal = YES;
    scroll.alwaysBounceVertical = YES;
    //反弹效果
    scroll.bounces = NO;
    //是否点击状态栏 回到顶端 
    scroll.scrollsToTop = YES;
    //设置scrollView 偏移量
    //scroll.contentOffset = CGPointMake(200, 200);
    //scroll.contentSize > scroll.frame
    scroll.contentSize = CGSizeMake(image.size.width, 480);
    //翻页   --->  320
    scroll.pagingEnabled = YES;
    
    [scroll addSubview:imgView];
    [self.view addSubview:scroll];
    scroll.userInteractionEnabled=YES;
    imgView.userInteractionEnabled=YES;
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [scroll setContentOffset:CGPointMake(1000, 200) animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
