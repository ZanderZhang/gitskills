//
//  CYRootViewController.m
//  UIScrollViewImg
//
//  Created by lcy on 14/12/3.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController{
    UIScrollView *scroll;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    
    for (NSInteger i = 0; i < 4; i++) {
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(i * 320, 0, 320, 480)];
        
        imgView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",i+1]];
        [scroll addSubview:imgView];
    }
    //1
    scroll.bounces = NO;
    scroll.pagingEnabled = YES;
    scroll.contentSize = CGSizeMake(320 * 4, 480);
    //scroll.contentOffset = CGPointMake(320, 0);
    [self.view addSubview:scroll];
    
    [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(timer:) userInfo:scroll repeats:YES];
}

NSInteger cnt = 0;
-(void)timer:(NSTimer *)time
{
//    UIScrollView *view = (UIScrollView *)time.userInfo;
    cnt++;
    if(cnt == 4)
    {
        cnt = 0;
    }
    
    [scroll setContentOffset:CGPointMake(320 * cnt, 0) animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
