#include <stdio.h>  // 包含头文件

int main(void)      /* 主函数*/     
{                   //主函数开始
	
	//insert your code

	printf("Hello World\n");

	return 0;      //返回0 表示主函数正常退出
}                  //主函数结束
