#include <stdio.h>

int main(void)
{
	//int a,b,c;
	int a;
	int b;
	int c;

	//float fa,fb,fc;
	float fa;
	float fb;
	float fc;

	//char ch_a,ch_b,ch_c;


	return 0;
}
