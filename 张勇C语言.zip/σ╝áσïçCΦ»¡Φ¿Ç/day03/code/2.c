#include <stdio.h>

int main(void)
{
//初始化
	int a = 3;

//赋值
	int b;
	b = 5;
    a = 4;
        
    a = b;//=右边是对变量取值操作，左边是对变量存储操作

	char ch1 = 'a';
	char ch2 = 97






	return 0;
}
