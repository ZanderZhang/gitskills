#include <stdio.h>

int main(void)
{
	char ch1 = 67;

	printf("ch1 = %c\n",ch1);
	printf("ch1 = %d\n",ch1);

	float f = 3.1415926;
	printf("f = %f\n",f);
	printf("f = %.2f\n",f);

	float f1 = 3.14;
	printf("f = %f\n",f1);
	printf("f = %g\n",f1);


	return 0;
}
