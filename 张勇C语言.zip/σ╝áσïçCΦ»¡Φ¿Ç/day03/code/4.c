#include <stdio.h>

int main(void)
{
	int a = 65;
	printf("%d\n",a);
	printf("%c\n",a);
	printf("%o\n",a);
	printf("%d\n",a);
	
	return 0;
}
