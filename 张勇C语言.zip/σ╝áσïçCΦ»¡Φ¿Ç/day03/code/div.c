#include <stdio.h>

int main(void)
{
	int a;
	float b;
	
	printf("pls input a ,b\n");
	scanf("%d%f",&a,&b);
	printf("%d / %g =  %g\n",a,b,a/b);
	
	return 0;
}
