#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int a = 20;
	int b = 6;
	printf("%d + %d = %d\n",a,b,a+b);
	printf("%d - %d = %d\n",a,b,a-b);
	printf("%d * %d = %d\n",a,b,a*b);
	printf("%d / %d = %d\n",a,b,a/b);
	printf("%d %% %d = %d\n",a,b,a%b);
	//int a = arc4random( )%59 + 1;
	//printf("请学号为%d的同学上来写代码\n",a);
	return 0;
}
