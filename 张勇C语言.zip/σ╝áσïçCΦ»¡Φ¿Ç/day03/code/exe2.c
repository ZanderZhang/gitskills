#include <stdio.h>

int main(void)
{
	float l,w,s,c;

	printf("pls input l,w\n");
	scanf("%f%f",&l,&w);

	s = l * w;
	c = 2 * (l + w);
	printf("l = %g w = %g s = %g c = %g\n",l,w,s,c);

	return 0;
}
