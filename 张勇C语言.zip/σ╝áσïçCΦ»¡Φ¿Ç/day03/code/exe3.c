#include <stdio.h>

int main(void)
{
	float score;

	printf("pls input a score:\n");
	scanf("%f",&score);

	if(score >= 80)
	{
		printf("考的还可以\n");
	}
	else
	{
		printf("-----end----\n");
	}

	return 0;
}
