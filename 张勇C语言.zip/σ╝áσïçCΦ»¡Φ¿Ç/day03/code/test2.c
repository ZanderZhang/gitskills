#include <stdio.h>

int main(void)
{
	100  , 200,300;
	"qianfeng" ,"helloworld";

	   转码存储
  'a'  --  97  -- 1100001
                 转码输  
  1100001  -- 97  -- 'a'
  


	return 0;
}
