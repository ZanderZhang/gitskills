#include<stdio.h>

int main(void)
{
	int a;
	a = 4;
	printf("%f\n",a);
	return 0;
}
