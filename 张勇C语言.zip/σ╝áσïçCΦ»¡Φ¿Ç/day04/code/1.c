#include <stdio.h>

int main(void)
{
	int a ;
	printf("pls input a value:\n");
	scanf("%d",&a);

	//a++;
	//++a;
	//printf("a = %d a++ = %d\n",a,a++);
	//printf("a = %d ++a = %d\n",a,++a);
	//printf("a = %d\n",a);

//a++ === a  ; a++ 先取a的值，然后再对执行 a = a +1
//++a === a  ; ++a 先执行a = a + 1, ,再取a 的值 


	//printf("a = %d a-- = %d\n",a,a--);
	printf("a = %d --a = %d\n",a,--a);
	printf("a = %d\n",a);



	return 0;
}
