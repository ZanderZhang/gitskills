#include <stdio.h>

int main(void)
{
	int a = 3;
	//a = a + 5;

	a += 5;   //  ===  a = a + 5
	printf("a = %d\n",a);
	return 0;
}
