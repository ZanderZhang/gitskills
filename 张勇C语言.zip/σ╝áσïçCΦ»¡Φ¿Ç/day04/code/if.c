#include <stdio.h>

int main(void)
{
	int a = 2;
	if(2 == a)
	{
		printf("Stop....\n");

	}

	return 0;
}
