#include <stdio.h>

int main(void)
{
	int a,b,min;
	
	printf("pls input a b:\n");
	scanf("%d%d",&a,&b);

	min = a < b ? a : b ;
	//min = a > b ? b : a  ;
	
	if(a < b)
	{
		min = a;
	}
	else
	{
		min = b;
	}

	
	printf("a = %d b = %d min = %d\n",a,b,min);

	return 0;
}

