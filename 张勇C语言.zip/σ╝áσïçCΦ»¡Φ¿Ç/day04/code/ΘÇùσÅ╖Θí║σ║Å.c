#include <stdio.h>


int main(void)
{
	int b,c,d,s1,s2;
	b=3,c=8,d=6 ;
	s1 = (++b, c--, d+3) ;
 	s2 = (++c, c--, c+3) ;
	
	printf("s1 = %d ,s2 = %d\n",s1,s2);
	printf("b = %d c = %d d = %d\n",b,c,d);

	return 0;
}
