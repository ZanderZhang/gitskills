#include <stdio.h>

int main(void)
{
	char ch;
	printf("pls input a charater:\n");
	scanf("%c",&ch);

	if((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122))
	{
		printf(" ch is a charater\n");
	}
	else
	{
		printf(" ch is NOT a charater\n");
	}
	

	return 0;
}
