#include <stdio.h>

int main(void)
{
	int a ,b,s;
	char ch;
	printf("pls input a ,b:\n");
	scanf("%d%d %c",&a,&b,&ch);	
	if(ch == '+' )
	{
		s = a + b;
		printf("%d + %d = %d\n",a,b,s);
	}
	else
	{
		s = a - b;
		printf("%d - %d = %d\n",a,b,s);
	}



	return 0;
}
