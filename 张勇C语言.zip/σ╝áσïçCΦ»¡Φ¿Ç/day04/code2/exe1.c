#include <stdio.h>

int main(void)
{
	int a;
	printf("pls input a :\n");
	scanf("%d",&a);
	if( (a % 5 == 0) && (a % 7 == 0) )
	{
		printf("Yes\n");
	}
	else
	{
		printf("No\n");
	}	

	return 0;
}
