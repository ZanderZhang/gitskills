#include <stdio.h>

int main(void)
{
	int month;
	printf("pls input month: 1 -- 12\n");
	scanf("%d",&month);

	switch(month)
	{
		case 1: 
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			printf("31\n");
			break;

		case 2:
			printf("28\n");
			break;

		case 4:
		case 6:
		case 9:
		case 11:
			printf("30\n");
			break;

/*
		case 4:
			printf("30\n");
			break;

		case 5:
			printf("31\n");
			break;

		case 6:
			printf("30\n");
			break;
		case 7:
			printf("31\n");
			break;

		case 8:
			printf("31\n");
			break;
		
		case 9:
			printf("30\n");
			break;
		
		case 10:
			printf("31\n");
			break;
		
		case 11:
			printf("30\n");
			break;

		case 12:
			printf("31\n");
			break;
*/		
		default:
			printf("sorry,input error,pls input 1 --12  again\n");
			break;
			
	}


	return 0;
}
