#include <stdio.h>


{
	int a;
	printf("pls enter number:\n");
	scanf("%d",&a);
	if(a < 60)
	{
		printf("不及格\n");
	}
	//else if(a >= 60 && a <= 69)
	else if(a <= 69)
	{
		printf(" D\n");
	}
	//else if(a >= 70 && a <= 79)
	else if(a <= 79)
	{
		printf(" C\n");
	}
	//else if(a>= 80 && a <= 89)
	else if(a <= 89)
	{
		printf(" B\n");
	}
	//else if(a >= 90 && a <= 100)
	else if(a <= 100)
	//else  注意else if ( ) 与else 的区别
	{
		printf(" A\n");
	}

	return 0;
}

	ilse if(a >= 90 && a <= 100)
