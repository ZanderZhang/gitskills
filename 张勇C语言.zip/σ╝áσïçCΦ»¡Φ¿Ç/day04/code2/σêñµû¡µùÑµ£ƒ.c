#include <stdio.h>

int main(void)
{
	char ch;
	
	printf("pls enter a charater:M T W F S\n");
	scanf("%c",&ch);
	
	if(ch=='M')
	{
		printf("Monday\n");
	}
	
	if(ch=='W')
	{
		printf("Wednesday\n");
	}

	if(ch=='F')
	{
		printf("Friday\n");
	}
	
	if(ch=='S')
	{
		printf("pls enter the second charater:a u\n");
		getchar();
		scanf("%c",&ch);
		if(ch=='a')
		{
			printf("Saturday\n");
		}
		if(ch=='u')
		{
			printf("Sunday\n");
		}
	}

	if(ch=='T')
	{
		printf("pls enter the second charater:h u\n");
		getchar( );
		scanf("%c",&ch);
		if(ch=='h')
		{
			printf("Thursday\n");
		}
		if(ch=='u')
		{
			printf("Tuesday\n");
		}
	}
	
	return 0;
}
