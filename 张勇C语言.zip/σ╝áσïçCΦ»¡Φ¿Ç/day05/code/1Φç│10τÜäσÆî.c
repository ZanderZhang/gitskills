#include <stdio.h>

int main(void)
{
	int i;
	int sum = 0;
	for(i=1; i<=10; i++)
	{
		//sum = sum + i;
		sum += i;
	}
	//sum = sum + 1 + 2 +... +  10
	printf("sum = %d\n",sum);

	return 0;
}
