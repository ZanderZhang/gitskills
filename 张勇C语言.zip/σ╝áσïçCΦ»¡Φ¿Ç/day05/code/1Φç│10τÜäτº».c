#include <stdio.h>

int main(void)
{
	int i;
	int j = 1;
	for(i=1; i<=10; i++)
	{
		j *= i;
	}
	printf("%d\n",j);

	return 0;
}
