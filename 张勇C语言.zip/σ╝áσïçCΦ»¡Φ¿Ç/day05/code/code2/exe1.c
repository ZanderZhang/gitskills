#include <stdio.h>

int main(void)
{
	int i = 1;
	
	while(i<21)
	{
		printf("%d ",i);
		i++;
	}
	printf("\n");

	return 0;
}
