#include <stdio.h>

int main(void)
{
	int i = 0;

	while(i<10)
	{
		printf("*");
		i++;
	}
	printf("\n");

	return 0;
}
