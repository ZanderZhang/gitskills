#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int num = arc4random( )%500 + 1;
	int s1 = 1;
	int s2 = 500;
	int m;

	do
	{
		printf("pls input a number:%d - %d\n",s1,s2);
		scanf("%d",&m);

		if(m > num)
		{
			s2 = m;
			printf("大了,请再次输入：\n");
		}
		
		if(m < num)
		{	
			s1 = m;
			printf("小了，请再次输入：\n");
		}

	}while(m!=num);

	printf("恭喜猜对了，请上来表演节目\n m = %d num = %d",m,num);

	return 0;
}
