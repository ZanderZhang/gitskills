#include<stdio.h>

int main(void)
{  
    int i = 1;
	long j = 1;
    while(i<=20)
	{
	    j = i*j;
		i++;
	}
    printf("%ld\n",j);

    return 0;
}
