#include <stdio.h>

int main(void)
{
	int i = 1;
	int sum = 0;
	for( ; i<100; )
	{
		sum += i;
		i += 2;
	}
    printf("%d\n",sum);


	return 0;
}
