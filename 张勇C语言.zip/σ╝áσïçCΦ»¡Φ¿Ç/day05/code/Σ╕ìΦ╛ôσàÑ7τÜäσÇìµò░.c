#include <stdio.h>

int main (void)
{
	int a;
	for(a = 1; a <= 100; a++)//i   index
	{
		if(a % 7 == 0)
		{
			break;
		}
		printf("%d ",a);
	}
	return 0;
}
