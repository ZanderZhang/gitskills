#include <stdio.h>

int main(void)
{
	int i;
	int j;
	for(j=0; j<3; j++)
	{
		for(i=0; i<10; i++)
		{
			printf("*");
		}
		printf("\n");
	}

	return 0;
}
