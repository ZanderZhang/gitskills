#include <stdio.h>

int main(void)
{
	int i;
	for(i=1; i<=100; i++)
	{
		if(i % 2 == 0)
		{
			printf("%03d ",i);
		}
		if(i % 10 == 0 )
		{
			printf("\n");
		}
	}
	return 0;
}
