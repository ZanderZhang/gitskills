#include <stdio.h>

int main(void)
{
	int i;
	for(i=40; i>=20; i--)
	{
		printf("%d\n",i);
	}
	
	return 0;
}
