#include <stdio.h>

int main()
{
	int i,j;
	int n;
	printf("pls input n:\n");
	scanf("%d",&n);
	/*
	for (i=0; i<n; i++)
	{
		for(j=n-i; j>0; j--)
		{
			printf("*");
		}
		printf("\n");
	}*/

	for(i=n; i>0; i--)
	{
		for(j=1; j<=i; j++)
		{
			printf("*");
		}
		printf("\n");
	}
	
	return 0;
}
