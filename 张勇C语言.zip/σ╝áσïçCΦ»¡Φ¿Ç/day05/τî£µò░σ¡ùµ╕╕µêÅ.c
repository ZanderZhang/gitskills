#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int i,s1=1,s2=500;
	int num= arc4random()%500 + 1;
	do{
		printf("pls enter a number:%d-%d\n",s1,s2);
		scanf("%d",&i);
		if(i>num)
		{
			printf("大了\n");
			s2=i;
		}
		if(i<num)
		{	
			printf("小了\n");
			s1=i;
		}
	}while(i!=num);
	printf("猜对了\n");

	return 0;
}

