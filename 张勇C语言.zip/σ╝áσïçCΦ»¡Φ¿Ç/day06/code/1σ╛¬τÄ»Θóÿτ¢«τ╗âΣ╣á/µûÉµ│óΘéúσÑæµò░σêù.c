#include <stdio.h>
/*
  1  1  2  3  5  8  13  21   34   55  89

  a  b  ret
     a  b  ret 
	    a  b  ret



*/
int main(void)
{
	int a = 1;
	int b = 1;
	int ret;
	int n;
	int num;
	printf("pls input num:\n");
	scanf("%d",&num);

	for(n=1; n<num+1; n++)
	{
		if(n < 3)
		{
			printf("%6d  ",a);
		}
		else
		{
			ret = a + b;
			printf("%6d  ",ret);
		
			a = b;
			b = ret;
		}

		if(n%5 == 0)
			printf("\n");

	}

	return 0;
}
