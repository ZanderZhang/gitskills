/*

2.逆序输出指定数字的二进制
	
	10%2     0
	 5%2     1
	 2%2     0
	 1%2     1


*/

#include <stdio.h>

int main(void)
{

	int x, y;
	printf("Pls input y,x(2,8,16)\n");
	scanf("%d%d", &y,&x);
	
	while(y != 0)
	{
		printf("%d", y%x);
		
		y /= x;
	}
	
	return 0;
}
