#include <stdio.h>

int main(void)
{
	int num;
	int cnt = 0;
	printf("pls input num:\n");
	scanf("%d",&num);
//1234
	while(num)
	{
		printf("%d",num%10);

		num /= 10;

		cnt++;
	}
	printf("\n cnt = %d\n",cnt);
	return 0;
}
