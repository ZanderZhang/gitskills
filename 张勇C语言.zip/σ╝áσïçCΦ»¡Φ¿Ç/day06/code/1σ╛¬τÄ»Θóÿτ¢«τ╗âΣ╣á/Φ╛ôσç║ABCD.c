/*

ABCD      
ABC
AB
A

****
***
**
*

****
****
****
****

*/
#include <stdio.h>

int main(void)
{
	int i;
	int j;

	for(i=4; i>0; i--)
	{
		for(j=0; j<i; j++)
		{
			printf("%c",'A'+j);

		}
		printf("\n");
	}


	
	return 0;
}
