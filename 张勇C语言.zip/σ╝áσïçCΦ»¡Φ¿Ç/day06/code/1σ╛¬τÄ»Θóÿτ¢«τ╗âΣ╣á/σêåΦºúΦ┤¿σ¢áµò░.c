/*
   60   --   2  
   30   --   2
   15   --   3
    5   --   5 


*/

#include <stdio.h>

int main(void)
{
	int num = 60;
	int i;
	
	printf("%d = ",num);
	for(i=2; i<=num; i++)
	{
		if(num % i == 0)
		{
			if( i != num)
			{
				printf("%d *  ",i);
				num /= i;
				i = 1;
			}
			else
			{
				printf("%d \n",i);
			}
		}
	}

	return 0;
}
