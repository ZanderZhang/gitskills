#include <stdio.h>

int main(void)
{
//1先写出判断一个数是否为素数的代码

	int num;
	int i;
	int s1,s2;
	printf("pls input s1,s2:(s1<s2)\n");
	scanf("%d%d",&s1,&s2);
	//printf("pls input num:\n");
	//scanf("%d",&num);
for(num=s1; num<s2; num++)
{
	for(i=2; i<num; i++)
	{
		if(num % i == 0)
		{
			//printf("num 不是素数\n");
			break;
		}
	}
	
	if(i==num)
	{
		printf("%d 是素数\n",num);
	}
}
	return 0;
}
