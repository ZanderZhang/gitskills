#include <stdio.h>

int main(void)
{
	float h[10],sum=0;
	int i;
	printf("please input heigh:(m)\n");
	for(i=0;i<10;i++)
	{
		scanf("%f",&h[i]);

	}
	for(i=0;i<10;i++)
	{
		sum+=h[i];
	}
	printf("%g(m)",sum/10);

	return 0;
}
