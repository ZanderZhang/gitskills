#include <stdio.h>

int main(void)
{
//数据类型  数组名[常量表达式]
//程序中最好不要出现这种数组定义方式	
	
	int n;
	scanf("%d",&n);
	int     age[n];
	printf("%ld ",sizeof(age)/4);
	return 0;
}
