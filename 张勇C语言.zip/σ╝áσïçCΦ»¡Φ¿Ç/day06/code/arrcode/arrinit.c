#include <stdio.h>
//数组初始化
int main(void)
{
//完全初始化
	float h[10] = {170,171,172,173,174,175,176,177,178,179};

//部分初始化，没有给初始值的元素默认值为0
	int age[10] = {20,19,22,26,25,21,18,23};

//缺省长度初始化，数组的长度为初始化列表中元素的个数
	float score[ ] = {80,85,90,95,100,98,96,78,87,95};
	printf("sizeof(score) = %ld\n",sizeof(score));


	int weight[ ] = { };
	printf("sizeof(weight) = %ld\n",sizeof(weight));
	



	return 0;
}
