#include <stdio.h>

int main(void)
{
	char a[10];
	int i;
	int low_cnt = 0;
	int up_cnt = 0;
	
	for(i=0; i<10; i++)
	{
		scanf("%c",&a[i]);
		getchar();
	}
	
	for(i=0; i<10; i++)
	{
		if('a'<=a[i]&&a[i]<='z')
		{
			low_cnt++;
		}
		
		if('A'<=a[i]&&a[i]<='Z')
		{
			up_cnt++;
		}
		
	}
	printf("low_cnt = %d up_cnt = %d\n", low_cnt, up_cnt);
	
	for(i=0; i<10; i++)
	{
		if(a[i]>='a' && a[i]<='z')
		{
			a[i] -= 32;
		}
	}
	
	for(i=0; i<10; i++)
	{
		printf("%c  ",a[i]);
	}
	printf("\n");
	
	
	
	return 0;
}

