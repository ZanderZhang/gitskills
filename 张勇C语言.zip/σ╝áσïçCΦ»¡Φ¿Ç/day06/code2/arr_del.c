#include <stdio.h>

int main(void)
{
	float h[64] = {170,171,172,173,174,175,176,177,178,179};
//删除第四个元素173


	//float h[64] = {170,171,172,174,175,176,177,178,179};
	int i;
	int len = 10;
	for(i=3; i<len-1; i++)
	{
		h[i] = h[i+1];
	}
	len -= 1;
	
	for(i=0; i<len; i++)
	{
		printf("%.2f\n",h[i]);
	}
	
	return 0;
}
