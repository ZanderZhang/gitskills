#include <stdio.h>

int main(void)
{
	int arr[]= {1,3,5,7,9,2,4,6,8};

	int len = sizeof(arr)/sizeof(int);

	int tmp = arr[0];

	arr[0] = arr[len-1]; 
	
	arr[len-1] = tmp;

	int i;
	for(i=0; i<len; i++)
	{
		printf("%d  ",arr[i]);
	}
	printf("\n");

	return 0;
}
