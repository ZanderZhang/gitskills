#include <stdio.h>

int main(void)
{
	int arr[ ] = {1,2,3,4,5,6};
//逆序输出
//原数组不变，输出为 6 5 4 3 2 1

	int len = sizeof(arr)/sizeof(int);
	int i;

	for(i=len-1; i>=0; i--)
	{
		printf("%d  ",arr[i]);
	}
	printf("\n");



//逆序保存
   //arr[ ] = { 6,5,4,3,2,1};
/*
   1 2 3 4 5 6 7

i   0           6  len-1-i
	
	  1       5
	    2    4
*/	
	int tmp;
	for(i=0; i<len/2; i++)
	{
		tmp = arr[i];
		arr[i] = arr[len-1-i];
		arr[len-1-i] = tmp;
	}
	
	for(i=0; i<len; i++)
	{
		printf("%d  ",arr[i]);
	}
	printf("\n");
	return 0;
}
