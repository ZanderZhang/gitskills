#include <stdio.h>

int main(void)
{
	int num[10] = {200,4,-3,93,108,7,65,45,27,96};
	int max = num[0];
	int max_index = 0;
	int min = num[0];
	int min_index = 0;
	
	int i;
	for(i=1; i<10; i++)
	{
		if(max < num[i])
		{
			max = num[i];
			max_index = i;
		}

		if(min > num[i])
		{
			min = num[i];
			min_index = i;
		}
	}

	printf("max = %d max_index = %d\n",max,max_index);
	printf("min = %d min_index = %d\n",min,min_index);


}
