#include <stdio.h>

int main(void)
{
	int num;
	int arr[32];
	int i = 0;
	int cnt;
	printf("pls input a num:\n");
	scanf("%d",&num);

	while(num)
	{
		arr[i++] = num % 2;
		num /= 2;
	}
	
	cnt = i;
	for(i=cnt-1; i>=0; i--)
	{
		printf("%d",arr[i]);
	}

	printf("\n");
	return 0;
}
