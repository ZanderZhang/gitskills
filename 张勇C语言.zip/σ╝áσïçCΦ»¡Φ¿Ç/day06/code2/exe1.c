#include <stdio.h>

int main(void)
{
	int a[30];
	a[0] = 1;
	a[1] = 1;
	int i;
	for(i=2;i<30;i++)
	{
		a[i] = a[i-1] + a[i-2];
	}
	for(i=0;i<30;i++)
	{
		printf("%d\n",a[i]);
	}

	return 0;
}
