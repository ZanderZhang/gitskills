#include <stdio.h>

int main(void)
{
	int num[ ] = {15,8,10,-1,23,100,0,54};

	int min = num[0];
	int min_index = 0;
	int i,tmp;
	int len = sizeof(num)/sizeof(int);
	int j;

for(j=0; j<len-1; j++)
{
//1假设当前数为最小
	min = num[j];
	min_index = j;
//2找出剩余数中实际最小数
	for(i=j+1; i<len; i++)
	{
		if(min > num[i])
		{
			min = num[i];
			min_index = i;
		}
	}
//3将当前数与所找到的最小数交换
	tmp = num[j];
	num[j] = num[min_index];
	num[min_index] = tmp;
}

	for(i=0; i<len; i++)
	{
		printf("%d  ",num[i]);
	}
	printf("\n");

	return 0;
}
