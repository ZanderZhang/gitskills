#include <stdio.h>

int main(void)
{
	int num[ ] = {15,8,10};

	int min = num[0];
	int min_index = 0;
	int i,tmp;
	int len = sizeof(num)/sizeof(int);

	for(i=1; i<len; i++)
	{
		if(min > num[i])
		{
			min = num[i];
			min_index = i;
		}
	}
	tmp = num[0];
	num[0] = num[min_index];
	num[min_index] = tmp;


//8  15 10
	min = num[1];
	min_index = 1;
	for(i=2; i<len; i++)
	{
		if(min > num[i])
		{
			min = num[i];
			min_index = i;
		}
	}
	tmp = num[1];
	num[1] = num[min_index];
	num[min_index] = tmp;
	
	

	for(i=0; i<len; i++)
	{
		printf("%d  ",num[i]);
	}
	printf("\n");

// 8   15   10

	


	return 0;
}
