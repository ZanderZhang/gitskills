#include <stdio.h>

int main(void)
{
	char name[64];  //"xiaoming"
	int i;
	int cnt;
	printf("pls input your name:\n");
/*
//以字符的方式输入和输出
	for(i=0; i<64; i++)
	{
		scanf("%c",&name[i]);
		if(name[i] == '\n')
			break;
	}
	
	cnt = i;
	for(i=0; i<cnt; i++)
	{
		printf("%c",name[i]);
	}
	printf("\n");
*/

//用字符串特有的方式输入和输出字符串信息

	scanf("%s",name);   //s --- string name:数组首地址，是一个地址常量值
//scanf 以%s的方式输入时，会自动往后偏移，遇到空格或回车会自动加上'\0'，并结束输入

	printf("%s\n",name);
//printf %s 表示从所给出的地址开始一直往后输出，直到遇到'\0'就结束输出
	return 0;
}
