#include <stdio.h>

int main(void)
{
	char addr[128];

	printf("pls input your address:\n");

	//scanf("%s",addr);//不能带空格输入
	
	scanf("%[^\n]",addr); //除了回车以外所有字符都能输入
	
	printf("%s\n",addr);

	return 0;
}
