#include <stdio.h>

int main(void)
{
	int n;
	scanf("%d",&n);
	int arr[n];
	printf("sizeof(arr) = %ld\n",sizeof(arr));
	return 0;
}
