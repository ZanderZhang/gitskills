#include <stdio.h>

int main(void)
{
	int n;
	scanf("%d",&n);
	int age[n];

	return 0;
}
