#include <stdio.h>

int main(void)
{
	float score[3][3] = {80,90,100,90,85,95,92,93,87};
//1手动录入三个学生的三门成绩
/*
              语          数          外
001   s[0][0] 80   s[0][1]90   s[0][2]100   sum[0]
002   s[1][0] 90   s[1][1]85   s[1][2] 95   sum[1] 
003   s[2][0] 92   s[2][1]93   s[2][2] 87   sum[2]
		 sum1[0]     sum1[1]	  sum1[2]
*/
	int i,j;
/*
	printf("pls input 3 students 3 scores:\n");
	for(i=0; i<3; i++)
	{
		for(j=0; j<3; j++)
		{
			scanf("%f",&score[i][j]);
		}
	}
*/
//2统计三个学生的平均分数
	float sum[3] = {0};
	for(i=0; i<3; i++)
	{
		for(j=0; j<3; j++)
		{
			sum[i] += score[i][j];
		}
		printf("学号为00%d学生的平均分数为：%.2f\n",i,sum[i]/3);

	}

//3统计三门成绩的平均分
	float sum1[3] = {0};
	for(i=0; i<3; i++)
	{
		for(j=0; j<3; j++)
		{
			sum1[i] += score[j][i] ;
		}
		if(i==0)
		{
			printf("语文成绩平均分为:%.2f\n",sum1[i]/3);
		}
		else if(i==1)
		{
			printf("数学成绩平均分为:%.2f\n",sum1[i]/3);
		}
		else if(i==2)
		{
			printf("英语成绩平均分为:%.2f\n",sum1[i]/3);
		}
	}
	
//找出最大分数和最小分数
	float max = score[0][0];
	int max_index1 = 0;
	int max_index2 = 0;

	float min = score[0][0];
	int min_index1 = 0;
	int min_index2 = 0;

	for(i=0; i<3; i++)
	{
		for(j=0; j<3; j++)
		{
			if(max < score[i][j])
			{
				max = score[i][j];
				max_index1 = i;
				max_index2 = j;
			}

			if(min > score[i][j])
			{
				min = score[i][j];
				min_index1 = i;
				min_index2 = j;
			}
		}
	}
	printf("最大分数为:%.2f 下标为%d %d\n",max,max_index1,max_index2);

	printf("最小分数为:%.2f 下标为%d %d\n",min,min_index1,min_index2);



	return 0;
}
