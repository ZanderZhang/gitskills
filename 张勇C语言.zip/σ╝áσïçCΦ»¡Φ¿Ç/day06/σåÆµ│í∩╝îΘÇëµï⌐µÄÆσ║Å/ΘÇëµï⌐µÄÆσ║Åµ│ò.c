#include <stdio.h>

int main(void)
{
	int arr[ ] = {3,0,-1,-8,10,2,100,5};
//select sort

	int len = sizeof(arr)/sizeof(int);
	int i,j;
	int min;
	int index;
	int tmp;
	for(i=0; i<len-1; i++)
	{
//1
		min = arr[i];
		index = i;

//2
        for(j=i+1; j<len; j++)
		{
			if(min > arr[j])
			{
				min = arr[j];
				index = j;
			}
		}
//3
		tmp = arr[i];
		arr[i] = arr[index];
		arr[index] = tmp;
	}
	
	for(i=0; i<len; i++)
	{
		printf("%d  ",arr[i]);
	}
	printf("\n");

	return 0;
}
