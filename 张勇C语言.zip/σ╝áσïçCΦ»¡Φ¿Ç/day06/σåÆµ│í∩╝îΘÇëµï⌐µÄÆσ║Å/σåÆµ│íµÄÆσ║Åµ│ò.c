#include <stdio.h>

int main(void)
{
  //int arr[ ] = {0,-1,-8,3,10,2,100,5};
	int arr[ ] = {3,-1,-8,0,2,10,5,100};

	int len = sizeof(arr)/sizeof(int);
	
	int i,j;
	int tmp;
	for(i=0; i<len-1; i++)
	{
		for(j=0; j<len-1-i; j++)
		{
			if(arr[j] > arr[j+1])
			{
				tmp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tmp;
			}
		}
	}

	for(i=0; i<len; i++)
	{
		printf("%d  ",arr[i]);
	}
	printf("\n");

	return 0;
}
