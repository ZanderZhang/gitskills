#include <stdio.h>

int add(int n)
{
	int i;
	int sum = 0;
	for(i=0; i<n+1; i++)
	{
		sum += i;
	}
	return sum;
}

int main(void)
{
	int n;
	printf("pls input n:\n");
	scanf("%d",&n);

	printf("sum = %d\n",add(n));

	return 0;
}
