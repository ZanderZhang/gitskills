#include <stdio.h>
//作用域
//生命周期

//全局变量
int sum = 1;

//函数的声明
void swap(int a,int b);

int main(void)
{
	
	int a = 3;
	int b = 4;
	printf("a = %d b = %d\n",a,b);

	swap(a,b);
	printf("a = %d b = %d\n",a,b);
	
	printf("in main fun:sum = %d\n",sum);
	printf("tmp = %d\n",tmp);
	return 0;
}

void swap(int a,int b)
{
	int tmp;
	tmp = a;
	a = b;
	b = tmp;
	printf("in swap fun:sum = %d\n",sum);
}
