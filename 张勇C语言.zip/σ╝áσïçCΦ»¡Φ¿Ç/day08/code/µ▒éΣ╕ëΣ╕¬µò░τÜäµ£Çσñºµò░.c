#include <stdio.h>
//
/*
在调用函数时操作系统会自动将实参的数赋值对应位置上的形参的值
a = x;
b = y;
c = z
*/
int threeNumCompare(int a ,int b ,int c )//形式参数
{
	int max;
	max = (a>b?a:b) < c ? c:(a>b?a:b);
	return max;
}



int main(void)
{
	int x,y,z;//实际参数
	printf("pls input x y z:\n");
	scanf("%d%d%d",&x,&y,&z);
	
	int num = threeNumCompare(x,y,z);

	printf("%d %d %d  max = %d\n",x,y,z,num);
	
	return 0;
}


/*
	max = a>b?a:b;
	max = max<c?c:max;
*/

//	max = (a>b?a:b) < c ? c:(a>b?a:b);

/*
	if(a>b)
	{
		max = a;
	}
	else
	{
		max = b;
	}

	if(max<c)
	{
		max = c;
	}
*/
