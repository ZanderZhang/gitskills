#include <stdio.h>

int arg(int x, int y, int z){
	
	return x * y * z;

}

int main(void){
	
	int x,y,z;
	
	printf("Pls input three num:\n");
	scanf("%d%d%d",&x,&y,&z);
	int v = arg(x,y,z);
	printf("arg = %d\n",v);

	return 0;
}
