#include <stdio.h>
/*
add(1)  == 1

add(2)  == add(1)  + 2

add(3)  == add(2) + 3

...

add(n) == 1 + 2 + 3 + ... + n;

add(n+1) == 1 + 2 + 3 + n + n+1 == add(n) + (n+1)

add( )

add(n+1) ==  add(n) + (n+1)
*/

int add(int n)
{
	if(n == 1)
		return 1;
	else
	  return add(n-1) + n;
}


int main(void)
{
	printf("sum = %d\n",add(10));
	return 0;
}
