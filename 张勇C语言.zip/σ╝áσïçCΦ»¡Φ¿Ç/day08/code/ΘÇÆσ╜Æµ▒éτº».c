#include <stdio.h>

int mul(int n)
{
	if(n == 1)
		return 1;
	else
		return mul(n-1) * n;
}

int main(void)
{
	printf("mul = %d\n",mul(4));	


	return 0;
}
