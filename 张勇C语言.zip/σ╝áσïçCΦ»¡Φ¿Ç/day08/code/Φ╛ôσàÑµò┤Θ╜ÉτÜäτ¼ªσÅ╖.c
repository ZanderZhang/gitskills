#include <stdio.h>

/*
	**********
	**********
	++++++++++
	++++++++++
	%%%%%%%%%%
	%%%%%%%%%%
	**********
	**********
	++++++++++
	++++++++++
	%%%%%%%%%%
	%%%%%%%%%%

*/
int i,j;
/*
void print_star( )
{
	for(i=0; i<2; i++)
	{
		for(j=0; j<10; j++)
		{
			printf("*");
		}
		printf("\n");
	}
}

void print_adds( )
{
	for(i=0; i<2; i++)
	{
		for(j=0; j<10; j++)
		{
			printf("+");
		}
		printf("\n");
	}
}

void print_b( )
{
	for(i=0; i<2; i++)
	{
		for(j=0; j<10; j++)
		{
			printf("%%");
		}
		printf("\n");
	}
}
*/

void print_symbol( )
{
	char ch;
	int i,j;
	int row,col;
	printf("pls input the symbol want to output:\n");
	scanf("%c",&ch);
	printf("pls input row ,col:\n");
	scanf("%d%d",&row,&col);

	for(i=0; i<row; i++)
	{
		for(j=0; j<col; j++)
		{
			printf("%c",ch);
		}
		printf("\n");
	}

}


int main(void)
{
	
	print_symbol( );
	

	return 0;
}
