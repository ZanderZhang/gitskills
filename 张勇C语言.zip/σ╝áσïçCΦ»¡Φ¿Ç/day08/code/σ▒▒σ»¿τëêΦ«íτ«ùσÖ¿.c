#include <stdio.h>

float add(float x,float y)
{
   return x + y;
}

float sub(float x,float y)
{
   return x - y;
}

float mul(float x,float y)
{
   return x * y;
}

float div(float x,float y)
{
	if(y != 0)
   		return x / y;
	else
	{
		printf("input error: y != 0\n");
		return -1;
	}
}

int main(void)
{
   float x,y;
   char ch; 
   float ret;
   printf("欢迎使用山寨版计算器,请输入:\n");
   scanf("%f",&x);
   getchar( );
   scanf("%c",&ch);
   scanf("%f",&y);

	
	switch(ch)
	{
		case '+':
   			ret = add(x,y);
			break;

			case '-':
   				ret = sub(x,y);
				break;

			case '*':
  				 ret = mul(x,y);
				 break;

			case '/':
				 ret = div(x,y);
				 break;
	}
		printf(" = %g\n",ret);
   
   return 0;
}
