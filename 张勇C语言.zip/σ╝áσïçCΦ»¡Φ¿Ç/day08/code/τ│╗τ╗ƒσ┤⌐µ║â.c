#include <stdio.h>


void print_star( )
{
	printf("*********\n");
	print_star( );	
}


int main(void)
{
	print_star( );

	return 0;
}
