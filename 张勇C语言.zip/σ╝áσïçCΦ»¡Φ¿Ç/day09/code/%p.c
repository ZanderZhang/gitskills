#include <stdio.h>

int main(void)
{
	int a = 3;
//  类型* 变量名   （类型：指针变量将要指向的变量类型保持一致
	int * p;//*出现在定义语句时表示的是指针变量类型

	p = &a;//&符号表示取地址值符号，指针变量p指向变量a

	printf("a = %d\n",a);
	printf("*p = %d\n",*p);//*出现在表达式表示取指针变量所指向的内存的内容 *p = *(&a) = a

	printf(" %p\n",&a);
	printf(" %p\n",p);//p所指向的变量的地址值
	printf(" %p \n",&p);//指针变量p自身内存地址值

	return 0;
}
