#include <stdio.h>

int main(void)
{
	int a = 3;

	int *p = &a;// p = &a

	int** q = &p;//  q = &p

	int** * r = &q;
	printf("a = %d\n",a);
	printf("*p = %d\n",*p);
	printf("**q = %d\n",**q);
	printf("***r = %d\n",***r);



	return 0;
}
