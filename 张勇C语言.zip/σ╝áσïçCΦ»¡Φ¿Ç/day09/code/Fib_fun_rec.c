#include <stdio.h>

/*
  1  1  2  3  5  8  13  21 34 55...


*/

int  fibNum(int n)
{
	if(n==1 || n==2)
		return 1;
	else
		return fibNum(n-1) + fibNum(n-2);
}


int main(void)
{
	int n;
	int i;
	printf("pls input n:\n");
	scanf("%d",&n);

	for(i=1; i<=n; i++)
	{
		printf("%d\n",fibNum(i));
	}

	return 0;
}
