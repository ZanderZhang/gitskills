#include <stdio.h>

int main(void)
{
	int a;
//1
	int* p = NULL;
    int *q; //定义时没有初始化的指针称为野指针
//2
	p = &a;
//3
	if(p != NULL)
	{
		printf("*p = %d\n",*p);
	}

	return 0;
}
