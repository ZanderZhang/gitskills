#include <stdio.h>

int main(void)
{
	int a = 3;
	int b = 4; 
	int c = 5;

//&
	printf("a = %d b = %d c = %d\n",a,b,c);
	printf("&a = %p &b = %p &c = %p\n",&a,&b,&c);


	return 0;
}
