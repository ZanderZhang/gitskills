#include <stdio.h>

int main(void)
{
	int a = 3;
	int b = 100;
//const 在指针变量的前面，限制指针变量的指向功能
	int * const p = &a;

	a = 4;
	printf("p = %p\n",p);
	printf("a = %d\n",a);

	printf("*p = %d\n",*p);

	*p = 5;
	printf("a = %d\n",a);
	printf("*p = %d\n",*p);

	//p = &b;
	printf("p = %p\n",p);

	return 0;
}
