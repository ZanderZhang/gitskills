#include <stdio.h>

int main(void)
{
	int a;
	int b;

	const int  * p1 = &a;
	int  const * p2 = &a;

	int * const p3  = &a;


	int const * const p4 = &a;


	return 0;
}
