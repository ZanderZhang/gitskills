#include <stdio.h>

int main(void)
{
//p = &a   指向任何存储单元
//*p  间接读或写所指向的存储单元
	int a = 3;
	int b = 100;
//const 在* 的左边，限制了*的写功
    //const int * p = &a;
    int const * p = &a;
	int *q = &a;


	a = 4;
	printf("a = %d\n",a);
	printf("p = %p\n",p);
	printf("*p = %d\n",*p);
	
	*p = 5;
	printf("a = %d\n",a);
	printf("*p = %d\n",*p);

	p = &b;
	printf("p = %p\n",p);
	printf("*p = %d\n",*p);

	return 0;
}
