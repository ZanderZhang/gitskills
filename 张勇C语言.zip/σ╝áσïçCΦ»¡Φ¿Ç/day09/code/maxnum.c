#include <stdio.h>

void maxfun(int a,int b,int *p)
{
	*p = a>b?a:b;
}


int main(void)
{
	int a,b,max;
	printf("pls input a b\n");
	scanf("%d%d",&a,&b);
//	max = a>b?a:b;

	maxfun(a,b,&max);

	printf("max = %d\n",max);


	return 0;
}
