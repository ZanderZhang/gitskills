#include <stdio.h>

int main(void)
{
	printf("sizeof(char) = %ld\n",sizeof(char));
	printf("sizeof(short) = %ld\n",sizeof(short));
	printf("sizeof(int) = %ld\n",sizeof(int));
	printf("sizeof(long) = %ld\n",sizeof(long));


	printf("sizeof(char*) = %ld\n",sizeof(char*));
	printf("sizeof(short *) = %ld\n",sizeof(short*));
	printf("sizeof(int *) = %ld\n",sizeof(int *));
	printf("sizeof(long*) = %ld\n",sizeof(long*));

	return 0;
}
