#include <stdio.h>

int main(void)
{
	int a = 3;
	int arr[10];
//sizeof是运算符，计算所占内存字节数
	printf("sizeof(a) = %ld\n",sizeof(a));
	printf("sizeof(int) = %ld\n",sizeof(int));

	
	printf("sizeof(arr[10]) = %ld\n",sizeof(arr[10]));
	printf("sizeof(arr) = %ld\n",sizeof(arr));
	return 0;
}
