#include <stdio.h>


void swap(int *p,int *q)
{
	int tmp;

	tmp = *p;
	*p = *q;
	*q = tmp;
}

int main(void)
{
	int a,b;
	printf("pls input a b:\n");
	scanf("%d%d",&a,&b);
	printf("a = %d b = %d\n",a,b);
	swap(&a,&b);
	printf("a = %d b = %d\n",a,b);

	return 0;
}
