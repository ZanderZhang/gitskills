#include <stdio.h>

void copyArr(int *p,int *q,int len)
{
	int i;
	for(i=0; i<len; i++)
	{
		 *q++ = *p++;
	}
}

void printArr(int *p,int len)
{
	int i;
	for(i=0; i<len; i++)
	{	
		printf("%d  ",*p++);
	}
	printf("\n");
}

int main(void)
{
	int arr[ ] = {1,2,3,4,5,6};
	int brr[6];
	int len = sizeof(arr)/sizeof(int);
	
	copyArr(arr,brr,len);
	printArr(brr,len);

	return 0;
}
