#include <stdio.h>

void printVar(int a)
{
	printf("%d  \n",a);
}

void printVar_p(int *p)
{
	printf("%d  \n",*p);
}

//void printArr(int brr[100],int len)
//数组作为函数的参数时编译器会直接把数简化为一个指针变量，用来接受主函数中数组的首地址，使主函数和调用函数共用同一个数组
void printArr(int brr[ ],int len)
//void printArr(int *brr, int len )
{
	int i;
	//int len = sizeof(brr)/sizeof(brr[0]);
//不可以调用函数中动态获取数组的长度，因为sizeof（数组名）相当于是sizeof一个指针变量 = 8是一个固定值
	
	for(i=0; i<len; i++)
	{
		printf("%d  ",brr[i]);//arr[i] = *(arr+i)
	}
	printf("\n");
}

int main(void)
{
//通过函数输出一个变量
	int a = 3;
//值传递方式
	printVar(a);
//地址传递方式
	printVar_p(&a);

//通过函数输出一个数组

	int arr[10] = {1,2,3,4,5,6,7,8,9,10};
	int len = sizeof(arr)/sizeof(arr[0]);
	printArr(arr,len);

	return 0;
}
