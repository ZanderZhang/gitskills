#include <stdio.h>

int main(void)
{
	char a = 3;
	char *p = &a;

	printf("a = %d a + 1 = %d\n",a,a+1);
	printf("p = %p p + 1 = %p\n",p,p+1);
	return 0;
}
