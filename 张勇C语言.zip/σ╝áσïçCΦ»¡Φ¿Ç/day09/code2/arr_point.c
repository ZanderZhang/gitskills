#include <stdio.h>

int main(void)
{
	int arr[10] = { 1,2,3,4,5,6,7,8,9,0};
//数组名表示数组的首地址，就是第一个元素的地址
	printf("&arr[0] = %p\n",&arr[0]);
	printf("arr = %p\n",arr);
//第五个元素
//	arr[4] == *(arr + 4 )

	int i;
	for(i=0; i<10; i++)
	{
		//printf("%d  ",arr[i]);
		printf("%d  ",*(arr + i));
	
	}
	printf("\n");

	return 0;
}
