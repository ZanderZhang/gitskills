#include <stdio.h>

int main(void)
{
	int arr[5] = {1,2,3,4,5};
//指向数组的指针
	//int *p = arr; // int * p ; p = arr;

    //arr[i]  == *(arr + i) == *(p + i)
/*
	int i;
	for(i=0; i<5; i++)
	{
		//printf("%d  ", *(p + i));
		printf("%d  ", *p++);
	}
	printf("\n");
*/

	int *p = NULL;
	for(p=arr; p<arr+5; p++)
	{
		printf("%d  ",*p);
	}
	printf("\n");



	return 0;
}
