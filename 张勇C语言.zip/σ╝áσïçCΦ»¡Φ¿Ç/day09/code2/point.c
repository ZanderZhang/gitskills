#include <stdio.h>

int main(void)
{
// *(p+1)  *p + 1
//1

	int a = 1;
	int *p = &a;
//取p所指向内存的值+1
	printf("*p + 1 = %d\n",*p + 1);
//取p所指向的内存后面的1个存储单元	
//printf("*(p + 1) = %d\n",*(p + 1));



	return 0;
}	
