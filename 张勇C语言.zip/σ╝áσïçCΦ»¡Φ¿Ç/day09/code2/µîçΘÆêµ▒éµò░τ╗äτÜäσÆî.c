#include<stdio.h>

  int main(void)

  {
    int arr[5],i;
	int sum=0;
	int *p=arr;
	printf("pls input number: \n");
	
	/* for(i=0;i<5;i++)
	{
	  scanf("%d",&arr[i]);
	  sum+=arr[i];
	}      
      printf("%d\n",sum);
    */

	for( ;p<arr+5;p++)
	{
	  scanf("%d",p);
	  sum += *p;
	  
	}
	printf("%d\n",sum);
     return 0;
  }
