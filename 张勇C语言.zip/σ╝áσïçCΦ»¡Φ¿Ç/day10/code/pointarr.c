#include <stdio.h>

int main(void)
{
	int a = 3;
	int arr[100];

	int *p;  // 指针变量名 p
	int *prr[100]; //一次定义了100个指针变量
	//100个指针变量分别为prr[0]  prr[1] prr[2] ....prr[99]

	p = &a;
	printf("%d \n",*p);

	prr[0] = &a;
	printf("%d \n", *prr[0]);

	return 0;
}
