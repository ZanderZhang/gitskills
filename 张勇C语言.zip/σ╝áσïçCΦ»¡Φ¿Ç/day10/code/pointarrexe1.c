#include <stdio.h>

int main(void)
{
	//char *week[7] = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};

	//char *week[7] ={NULL};
	char *week[7] ;

	char str[7][64];


//	week[0] = &str[0][0];
//    week[1] = & str[1][0];

	int i;
	for(i=0; i<7; i++)
	{
		week[i] = &str[i][0];
	}
	
	for(i=0; i<7; i++)
	{
		scanf("%s",week[i]);
	}
	
	for(i=0; i<7; i++)
	{
		printf("%s\n",week[i]);
		//printf("%c\n",*week[i]);

	}


	return 0;
}
