#include <stdio.h>

//*
//|
//@
//$

void printzidan( )
{
	printf("**********\n");
}

void printL( )
{
	printf("||||||||||\n");
}

void printbomb( )
{
	printf("@@@@@@@@@@\n");
}

void printS( )
{
	printf("$$$$$$$$$$$\n");
}

void sendSomething( void (*p)( ) )
{
	p( );
}


int main(void)
{
	char ch;
	while(1)
	{
		printf("pls input a charater:* | @ $\n");
		scanf("%c",&ch);
		getchar( );	
		void (*p)( );

		switch(ch)
		{
			case '*':
				p = printzidan;
				break;

			case '|':
				p = printL;
				break;

			case '@':
				p = printbomb;
				break;

			case '$':
				p = printS;
				break;
		}
		
		sendSomething(p);
	}
	
	return 0;
}
