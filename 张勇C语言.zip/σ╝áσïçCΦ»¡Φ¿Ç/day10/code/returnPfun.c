"#include <stdio.h>

char * searchChar(char *p, char ch)
{
	while(*p!='\0')
	{
		if(*p == ch)
		{
			return p;
		}
		p++;
	}

	return NULL;
}

int main(void)
{
	char str[ ] = "good good study,day day up";
	char c;
	printf("pls input a charater:\n");
	scanf("%c",&c);
	
	char *ret = searchChar(str,c);
	
	if(ret != NULL)
	{
		*ret -= 32;
		printf("%s",str);
	}
	else
	{
		printf("Not Find %c in %s\n",c,str);
	}


	return 0;
}
