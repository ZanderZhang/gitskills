#include <stdio.h>

int * fun(int a,int b)
{
	int sum = a + b;
	return &sum;
}


int main(void)
{
	int *p = fun(3,4);
	printf("*p = %d\n",*p);
	return 0;
}
