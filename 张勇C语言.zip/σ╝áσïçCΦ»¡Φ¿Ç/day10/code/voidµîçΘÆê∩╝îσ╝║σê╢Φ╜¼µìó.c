#include <stdio.h>

int main(void)
{
	char ch = 'A';
	int a = 100;
	float b = 3.14;

	void *p = &ch;
	
	printf("%c\n",*(char* )p);
	p = &a;
	printf("%c\n",*(int *)p);
	p = &b;
	printf("%g\n",*(float *)p);


	return 0;
}
