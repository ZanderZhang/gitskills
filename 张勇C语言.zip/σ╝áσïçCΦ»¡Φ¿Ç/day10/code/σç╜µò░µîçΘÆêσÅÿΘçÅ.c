#include <stdio.h>

void printStar( )
{
	int i,j;
	for(i=0; i<3; i++)
	{
		for(j=0; j<=i; j++)
		{
			printf("*");
		}
		printf("\n");
	}
}


int main(void)
{
	printStar( );
	
//	定义函数指针变量
	void (* p)( );

	p = printStar;

	p();

	(*p)();

	return 0;
}
