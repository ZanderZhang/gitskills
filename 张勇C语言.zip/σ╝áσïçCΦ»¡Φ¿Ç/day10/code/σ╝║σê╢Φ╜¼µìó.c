#include <stdio.h>

int main(void)
{
	int *p = (int *)5;

	int *q = p;
	return 0;
}
