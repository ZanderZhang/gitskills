#include <stdio.h>
//两个数相乘除以最大公约数得到最小公倍数。
//辗转相除法
int main(void)
{//假设a>b,b!=0.

	int a,b,r,c,d,e;
	scanf("%d%d",&a,&b);
	r=a%b;c=a;d=b;e=r;
	printf("%d\n",e);
	while(r!=0)
	{
		a=b;b=r;
		r=a%b;
	}
	printf("%d\n",b);
	printf("%d\n",c*d/b);
	
	return 0;
}
