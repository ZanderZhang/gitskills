#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv[ ])
{
	int i;
	for(i=0; i<argc; i++)
	{
		puts(argv[i]);
	}

	int num = atoi(argv[1]);
	printf("%d\n",num);

	return 0;
}
