#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	char *p = "100";
	char *q = "200";
	
	char str1[ ] = "1234";
	char str2[ ] = "4567";


	int num1 = atoi("100a001");//atoi(p);
	int num2 = atoi("200b002");//atoi(q);

	int ret = num1 + num2;
	printf("ret = %d\n",ret);

	char s[ ] = "3.14";
	printf("%g\n",atof(s));


	return 0;
}
