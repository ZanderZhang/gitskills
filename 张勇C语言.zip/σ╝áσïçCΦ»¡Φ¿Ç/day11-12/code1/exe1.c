#include <stdio.h>
#include <ctype.h>
#include <string.h>
int main (){
	char string[100];
	int numUpper = 0;
	int numLower = 0;
	int numSpace = 0;
	int numNumber = 0;
	int numOther = 0;
	int i = 0;
	int len = 0;

	printf("Pls enter a string :\n");
	scanf("%[^\n]",string);
	len = (int)strlen(string);
	for	(i = 0;i < len;i++ ){
		if	(isdigit(string[i]))
			numNumber++;
		else if (isupper(string[i]))
			numUpper++;
		else if (islower(string[i]))
			numLower++;
		else if (isspace(string[i]))
			numSpace++;
		else
			numOther++;
	}
	printf("Number of Upper is %d\nNumber of Lower is %d\nNumber of Digital is %d\nNumber of Space is %d\nNumber of Other characters is %d\n",numUpper,numLower,numNumber,numSpace,numOther);
	return 0;
}
