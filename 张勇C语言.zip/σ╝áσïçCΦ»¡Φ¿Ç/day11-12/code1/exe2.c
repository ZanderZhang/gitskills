#include <stdio.h>
#include <ctype.h>

int main(void)
{
	char ch = 'a';

	ch = toupper(ch);
	printf("%c\n",ch);	
	return 0;
}
