    #include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(void)
{
	char ch[64];
	char *p=ch;
	scanf("%[^\n]",ch);
	
	while(*p!='\0')
	{
		if((*p>=65)&&(*p<=90))
			//*p=tolower(*p);
			*p += 32;
		else if((*p>=97)&&(*p<=122))
			//*p = toupper(*p);
			*p -= 32;
		
		p++;
	}
	printf("%s\n",ch);
	return 0;
}
