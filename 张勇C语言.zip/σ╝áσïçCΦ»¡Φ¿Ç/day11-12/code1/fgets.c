#include <stdio.h>

int main(void)
{
	char str[10];
//	scanf("%s",str);
//fgets函数可以有效解决数组越界使用非法内存的问题
	fgets(str,10,stdin);//stdin stdout stderr
	//printf("%s\n",str);
	puts(str);//== printf("%s\n",str);
	return 0;
}
