#include <stdio.h>
#include <ctype.h>

int main(void)
{
	char ch;
	printf("pls input a charater:\n");
	scanf("%c",&ch);

	int ret = isdigit(ch);
	if(ret == 0)
	{
		printf("%c is NOT a digit charater\n",ch);
	}
	
	if(ret == 1)
	{
		printf("%c is a digit charater\n",ch);
	}
	
	return 0;
}
