#include <stdio.h>
#include <ctype.h>

int main(void)
{
	int ch = 'a';
	ch = toupper(ch);
	printf("%c\n",ch);
	return 0;
}

