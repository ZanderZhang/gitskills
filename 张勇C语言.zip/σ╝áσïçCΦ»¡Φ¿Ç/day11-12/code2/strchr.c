/*******************************
File Name: strchr.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 11:29:19 2014
*******************************/

#include <stdio.h>
#include <string.h>

//char *strchr(const char * str,int c)
//str目标查找字符串
//c  所要查找的字符
//返回c在str中第一次出现的地址，如果没有就返回NULL

//char * str r ch r(const char *str,int c);
//返回c字符在str中最后一次出现的地址,如果没有就返回NULL

int main(int argc,char *argv[])
{
	char *p = "good good study ,day day up";
	char ch = 'o';

	char *ret = strchr(p,ch);
	printf("ret = %p\n",ret);
	
	ret = strrchr(p,ch);
	printf("ret = %p\n",ret);

	return 0;
}
