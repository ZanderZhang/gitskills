/*******************************
File Name: strcpy.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 11:02:10 2014
*******************************/

#include <stdio.h>
#include <string.h>
//char * strcpy(char * dst,const char * src)
//src表示要copy的数据，即数据源
//dst表示将copy的数据所存向的内存地址，目标地址
//返回为dst的地址
//注意：要求dst所准备的内存必须>=src的长度，在copy的过程中会将src的'\0'一起copy过来

//char * strncpy(char *dst,const char *src,int len)
//功能同strcpy，可以有效防止src>dst引起的数组越界问题
int main(int argc,char *argv[])
{
	char *p = "xiaoqiang";
	char str[64];
	char str2[5];
	puts(p);
	puts(str);

	strcpy(str,p);
	puts(p);
	puts(str);


	//strcpy(str2,p);
	memset(str2,'\0',5);
	strncpy(str2,p,4);
	puts(p);
	puts(str2);

	

	return 0;
}
