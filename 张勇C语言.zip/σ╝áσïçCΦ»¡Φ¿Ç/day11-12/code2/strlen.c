/*******************************
File Name: strlen.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 10:09:22 2014
*******************************/

#include <stdio.h>
#include <string.h>

//size_t strlen(const char *s)
//strlen计算字符串所包含的字符的个数（不包括'\0')
//sizeof是运算符，计算系统所分配内存的大小

int main(int argc,char *argv[])
{
	char str[64];
	printf("pls input a name string:\n");
	scanf("%s",str);
	
	int len = strlen(str);
	printf("%s 的实际长度为:%d\n",str,len);

	int size = sizeof(str);
	printf("数组str所分配内存的大小为:%d\n",size);

	char str2[ ] = "xiaoqiang";
	printf("strlen(str2) = %ld,sizeof(str2) = %ld\n",strlen(str2),sizeof(str2));


	return 0;
}
