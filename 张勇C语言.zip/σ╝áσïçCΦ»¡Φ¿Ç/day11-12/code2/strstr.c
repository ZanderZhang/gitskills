/*******************************
File Name: strstr.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 11:47:15 2014
*******************************/

#include <stdio.h>
#include <string.h>

//char * strstr(const char * s1,const char *s2)
//功能：在s1字符串中查找s2字符串
//返回值：如果s2在s1中存在，返回s1中s2的地址
//如果不存在，返回NULL

//char * strcasestr(const char *s1,const char *s2)
//不区分大小写的查找

int main(int argc,char *argv[])
{
	char *p = "helloworld";
	char *q = "heL";

	char * ret = strstr(p,q);
	printf("ret = %p\n",ret);

	ret = strcasestr(p,q);
	printf("ret = %p\n",ret);
	return 0;
}
