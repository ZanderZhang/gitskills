/*******************************
File Name: strtol.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 09:34:35 2014
*******************************/

#include <stdio.h>
#include <stdlib.h>
//long strtol(char *str,char **p,int base)

int main(int argc,char *argv[])
{
	char *p = "1000";

	long ret = strtol(p,NULL,16);

	printf("ret = %ld\n",ret);

	return 0;
}
