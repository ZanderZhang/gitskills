/*******************************
File Name: strtol_exe.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 09:50:35 2014
*******************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv[])
{
	char str[128];
	int base;
	printf("pls input a number string:\n");
	scanf("%s",str);
	printf("pls input base value:2,8,10,16\n");
	scanf("%d",&base);

	long ret = strtol(str,NULL,base);

	printf("%d 进制字符串%s 转换为十进制：%ld\n",base,str,ret);

	return 0;
}
