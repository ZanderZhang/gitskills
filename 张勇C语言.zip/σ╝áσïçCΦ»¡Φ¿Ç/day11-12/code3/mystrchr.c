/*******************************
File Name: mystrchr.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 15:23:50 2014
*******************************/

#include <stdio.h>
/*
char * mystrchr(char str[ ] ,int ch)
{
	int i;
	for(i=0; str[i]!='\0'; i++)
	{
		if(str[i] == ch)
			return &str[i];
	}
	
	return NULL;
}
*/

char * mystrchr(char *str,int ch)
{
	if(str == NULL)
		return NULL;

	while(*str != '\0')
	{
		if(*str == ch)
			return str;
		str++;
	}
	
	return NULL;
}


int main(int argc,char *argv[])
{
	char str[64];
	char ch;
	printf("pls input a strng:\n");
	scanf("%s",str);
	getchar( );
	printf("pls input a charter:\n");
	scanf("%c",&ch);

	char *ret = mystrchr(str,ch);
	printf("ret = %p\n",ret);

	return 0;
}
