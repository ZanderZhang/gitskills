/*******************************
File Name: mystrcpy.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 14:50:36 2014
*******************************/

#include <stdio.h>
/*
char * mystrcpy(char dst[ ],const char src[ ])
{
	int i;
	for(i=0; src[i]!='\0'; i++)
	{
		dst[i] = src[i];
	}
	dst[i] = '\0';

	return dst;
}
*/

char * mystrcpy(char *dst ,const char *src)
{
//函数入口检查,防止异常操作
	if(dst==NULL || src==NULL)
		return NULL;


	char *p = dst;
	
	while(((*dst++) = (*src++)) !='\0' ) ;

	return p;
}


int main(int argc,char *argv[])
{
	char dst[64];
	char src[64];
	printf("pls input src:\n");
	scanf("%s",src);

	puts(src);
	puts(dst);

	mystrcpy(dst,src);
	
	puts(src);
	puts(dst);
	
	return 0;
}
