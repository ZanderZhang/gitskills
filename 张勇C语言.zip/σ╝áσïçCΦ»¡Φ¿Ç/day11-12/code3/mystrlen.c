/*******************************
File Name: mystrlen.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 14:27:23 2014
*******************************/

#include <stdio.h>
/*
int mystrlen(const char str[ ])
{
	int i;
	for(i=0; str[i]!='\0'; i++)  ;
	return i;
}
*/

int mystrlen(const char *p)
{
	int cnt = 0;
	while(*p++)
	{
		cnt++;
	}
	
	return cnt;
}
int main(int argc,char *argv[])
{
	char str[64];
	printf("pls input a string:\n");
	scanf("%s",str);
	
	int len = mystrlen(str);
	printf("len = %d\n",len);
	
	return 0;
}
