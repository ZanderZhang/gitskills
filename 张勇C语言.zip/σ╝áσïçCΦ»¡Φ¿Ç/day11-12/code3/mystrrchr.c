/*******************************
File Name: mystrrchr.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 15:57:45 2014
*******************************/

#include <stdio.h>
//从左往右
char *mystrrchr(char str[ ],int ch)
{
	int i;
	char *p = NULL;
	for(i=0; str[i]!='\0'; i++)
	{
		if(str[i] == ch)
			p = &str[i];	
	}
	
	return p;
}


//从右往左找

char * mystrrchr(char str[ ],int ch)
{
	int i;
	//将i定位到'\0'的下标上
	for(i=0; str[i]!='\0'; i++) ;
	
	for( ;i>=0; i--)
	{
		if(str[i] == ch)
			return &str[i];
	}
	
	return NULL;
}


char * mystrrchr(char *str,int ch)
{
	char *p = str;
//将指针变量定位到'\0'上
	while(*p++) ;

	while(p >=str)
	{	
		if(*p == ch)
			return p;

		p--;
	}

	return NULL;
}


char * mystrrchr(char *str,int ch)
{
	char *p = NULL;
	while(*str)
	{
		if(*str == ch)
			p = str;
		str++;
	}

	return p;
}


int main(int argc,char *argv[])
{

	return 0;
}
