/*******************************
File Name: strcat.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 17:08:05 2014
*******************************/

#include <stdio.h>
#include <string.h>
//char * strcat(char *s1,const char *s2)
//将s2拼接到s1后，s2的第一个字符覆盖s1的'\0'
//s1所指向的内存长度>= s1+s2-1
int main(int argc,char *argv[])
{
	char str[64] = "qianfeng";
	char str2[ ] = "hulian";

	puts(str);
	puts(str2);
	
	strcat(str,str2);

	puts(str);
	puts(str2);

	return 0;
}
