/*******************************
File Name: strcmp.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 16:31:27 2014
*******************************/

#include <stdio.h>
#include <string.h>

int main(int argc,char *argv[])
{
	char *p = "xiaoming";
	char *q = "xiaoqiang";

	int ret = strcmp(q,p);

	printf("ret = %d\n",ret);

	return 0;
}
