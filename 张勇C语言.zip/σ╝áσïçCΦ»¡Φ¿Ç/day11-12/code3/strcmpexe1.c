/*******************************
File Name: strcmpexe1.c
Author: xw
#Company: 千锋(深圳)
Created Time: 二 11/ 4 16:49:19 2014
*******************************/

#include <stdio.h>
#include <string.h>

int main(int argc,char *argv[])
{
	char *s_username = "xiaoming";
	char *s_password = "111111";

	char c_username[64];
	char c_password[64];
	int cnt = 0;
	do
	{
		printf("pls input user name and password:\n");
		scanf("%s%s",c_username,c_password);
		
		if((strcmp(s_username,c_username)==0) && 
			(strcmp(s_password,c_password)==0) )
		{
			printf("login successed\n");
			break;
		}
		else
		{
			printf("user name or password error,pls try again\n");
		}
		cnt++;
		if(cnt == 3)
		{
			printf("拒绝服务\n");
		}
	}while(cnt<3);	
	return 0;
}
