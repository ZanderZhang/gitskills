/*******************************
File Name: exe1.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 11:02:07 2014
*******************************/

#include <stdio.h>
#include <string.h>

int main(int argc,char *argv[])
{
	char str[ ] = "Hi, Welcome to saif!!";
	char strbk[64];

	char *delim = ", !";
	int cnt = 0;
	
	strcpy(strbk,str);

	char *p = strtok(str,delim);

	while(p!=NULL)
	{
		cnt++;
		p = strtok(NULL,delim);
	}

	printf("%s have %d words\n",strbk,cnt);

	return 0;
}
