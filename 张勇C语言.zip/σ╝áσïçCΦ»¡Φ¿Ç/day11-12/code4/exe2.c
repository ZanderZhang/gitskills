/*******************************
File Name: exe2.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 11:18:40 2014
*******************************/

#include <stdio.h>
#include <string.h>

int main(int argc,char *argv[])
{
	char str[64];
	char *delim = " ";
	int wordmaxlen;
	int len;
	char *word = NULL;
	
	scanf("%[^\n]",str);

	char *p = strtok(str,delim);
	wordmaxlen = strlen(p);
	word = p;

	while(p!=NULL)
	{
		p = strtok(NULL,delim);
		if(p != NULL)
		{
			len = strlen(p);
			if(wordmaxlen < len)
			{
				wordmaxlen = len;
				word = p;
			}
		}
	}

	printf("max len = %d  word is%s\n",wordmaxlen,word);

	return 0;
}
