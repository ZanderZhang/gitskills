/*******************************
File Name: sprintf.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 11:33:39 2014
*******************************/

#include <stdio.h>

// printf("%02d:%02d:%02d",h,m,s);
//sprintf(" ","%02d:%02d:%02d",h,m,s);


int main(int argc,char *argv[])
{
	int h = 11;
	int m = 34;
	int s = 3;
	char str[64];
//printf 为标准输出
	printf("%02d:%02d:%02d\n",h,m,s);
//sprintf 将标准输出的内容以字符串的形式存储
	sprintf(str,"%02d:%02d:%02d",h,m,s);
	puts(str);

	return 0;
}
