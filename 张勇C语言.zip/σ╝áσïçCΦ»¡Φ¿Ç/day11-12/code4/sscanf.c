/*******************************
File Name: sscanf.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 11:46:09 2014
*******************************/

#include <stdio.h>

int main(int argc,char *argv[])
{
	int h;
	int m;
	int s;
	char str[ ] = "11:49:30";
//scanf:标准输入，数据来源入键盘，将输入数据存入地址格式列表对应的每个变量中
	//scanf("%d:%d:%d",&h,&m,&s);
//sscanf：格式化输入, 数据来源于字符串，将字符串中的每个字段按格式提取出来存入到地址列表对应的每个变量中
	sscanf(str,"%d:%d:%d",&h,&m,&s);
	printf("%d-%d-%d\n",h,m,s);



	


	return 0;
}
