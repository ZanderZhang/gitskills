/*******************************
File Name: strtok.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 09:31:26 2014
*******************************/

#include <stdio.h>
#include <string.h>

/*
192.168.88.8

192 
168
88
8
*/

//char * strtok(char *str, char *delim)

//str:要分割的字符串
//delim：分割符列表，
//分割原理在分割的过程中遇到列表中的符号都替换成'\0'

//"192\0 168\0 88\0 8\0";
//"192.168.88.8"
//"(2 + 3) * 4 / 5"


int main(int argc,char *argv[])
{
	char str[ ] = "192.168.88.8";

	char *p = strtok(str,".");
	puts(p);

	while(p!=NULL)
	{
		p = strtok(NULL ,".");
		
		if(p!=NULL)
			puts(p);
	}
	return 0;
}
