/*******************************
File Name: strtok.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 09:31:26 2014
*******************************/

#include <stdio.h>
#include <string.h>

/*
192.168.88.8

192 
168
88
8
*/

//char * strtok(char *str, char *delim)

//str:要分割的字符串
//delim：分割符
//



int main(int argc,char *argv[])
{
	char str[ ] = "192.168.88.8";

	char *p = strtok(str,".");
	puts(p);

	p = strtok(NULL ,".");
	puts(p);

	p =	strtok(NULL,".");
	puts(p);
	

	p =	strtok(NULL,".");
	puts(p);

	p =	strtok(NULL,".");
	puts(p);
	return 0;
}
