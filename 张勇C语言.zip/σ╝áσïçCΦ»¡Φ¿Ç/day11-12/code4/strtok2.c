/*******************************
File Name: strtok2.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 10:15:06 2014
*******************************/

#include <stdio.h>
#include <string.h>

int main(int argc,char *argv[])
{
	char str[ ] ="(3 + 4) * 5 / 6 % 9";
	char *delim = "( +*/)%";

	char *p = strtok(str,delim);

	while(p!=NULL)
	{
		puts(p);
		p = strtok(NULL,delim);
	}

	return 0;
}
