/*******************************
File Name: Bookinfo.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 16:11:21 2014
*******************************/

#include <stdio.h>

struct Bookinfo
{
	char name[64];
	float price;
	char author[64];
	char pub[64];
}b2 = { };
//构造新的数据类型  定义变量，对变量初始一步完成
int main(int argc,char *argv[])
{
//结构体变量初始化
	struct Bookinfo b = {"c programe",38.8,"谭浩强","清华"} ;
/*
	scanf("%[^\n]",b.name);
	scanf("%f",&b.price);
	getchar( );
	scanf("%[^\n]",b.author);
	getchar( );
	scanf("%[^\n]",b.pub);
*/
	printf("name:%s price:%g author:%s pub:%s\n",b.name,b.price,b.author,b.pub);

//结构体数组
	struct Bookinfo brr[3];  //brr[0] brr[1] brr[2]


	return 0;
}
