/*******************************
File Name: Time.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 15:27:37 2014
*******************************/

#include <stdio.h>

struct Time
{
	int h;
	int m;
	int s;
};


int main(int argc,char *argv[])
{
	struct Time curtime;

	curtime.h = 15;
	curtime.m = 29;
	curtime.s = 30;

	printf("%d:%d:%d\n",curtime.h,curtime.m,curtime.s);




	return 0;
}
