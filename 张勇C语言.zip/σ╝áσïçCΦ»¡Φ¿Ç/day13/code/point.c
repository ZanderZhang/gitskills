/*******************************
File Name: point.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 16:02:47 2014
*******************************/

#include <stdio.h>

struct Point
{
	float x;
	float y;
};



int main(int argc,char *argv[])
{

	return 0;
}
