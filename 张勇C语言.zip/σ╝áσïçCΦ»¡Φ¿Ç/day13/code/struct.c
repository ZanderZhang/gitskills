/*******************************
File Name: struct.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 14:45:21 2014
*******************************/

#include <stdio.h>
#include <string.h>

/*
struct 结构体名
{
	成员列表;

};
*/

struct Stuinfo
{
	char name[64];
	float height;
	int age;
	char addr[64];
};


int main(int argc,char *argv[])
{
//	构造类型       变量名
//	int             a
//	int             arr[4];

struct Stuinfo stu1;

struct Stuinfo stu[60];
//"xiaoming" 176 24 "dongguan"
	//str = "xiaoming"
//结构体成员的访问方法：
//结构体名.成员名
//操作方法：按成员的基本类型操作
	strcpy(stu1.name,"xiaoming");
	stu1.height = 176;
	stu1.age = 24;
	strcpy(stu1.addr,"dongguan");

	printf("stu1 info name:%s height:%g age:%d addr:%s\n",stu1.name,stu1.height,stu1.age,stu1.addr);

	return 0;
}
