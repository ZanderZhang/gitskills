/*******************************
File Name: structmem.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 16:59:26 2014
*******************************/

#include <stdio.h>

struct Type
{
	char ch;
	int b;
	short a;
};


int main(int argc,char *argv[])
{
	struct Type d;

	printf("sizeof(d) = %ld\n",sizeof(d));

	return 0;
}
