/*******************************
File Name: structpoint.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 16:38:11 2014
*******************************/

#include <stdio.h>

struct Stuinfo
{
	char idNo[64];
	char name[64];
	char gender;
	int age;
};


int main(int argc,char *argv[])
{
/*
	int a;
	int *p;
	p = &a;
*/
	struct Stuinfo stu = {"0001","xiaoqiang",'F',20};
	struct Stuinfo *sp;
	sp = &stu;
//直接访问
	printf("idno:%s name:%s gender:%c age:%d\n",stu.idNo,stu.name,stu.gender,stu.age);
//间接访问
//	指针变量名->成员变量名
	printf("idno:%s name:%s gender:%c age:%d\n",sp->idNo,sp->name,sp->gender,sp->age);

	return 0;
}
