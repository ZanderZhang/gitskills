/*******************************
File Name: stuinfo.c
Author: xw
#Company: 千锋(深圳)
Created Time: 三 11/ 5 16:32:02 2014
*******************************/

#include <stdio.h>

struct Stuinfo
{
	char idNo[20];
	char name[64];
	char gender;
	char addr[64];
	float c;
	float cpp;
	float oc;
};

int main(int argc,char *argv[])
{
	struct Stuinfo stu[2];
//stu[0]  stu[1]


	return 0;
}
