/*******************************
File Name: define.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 09:51:03 2014
*******************************/

#include <stdio.h>



#define  LOOP100 for(i=0; i<100; i++)
#define PI 3.14
#define G 9.8

int main(int argc,char *argv[])
{
	int i;
	
	LOOP100
	{
		printf("%d\n",i);
	}

	


	return 0;
}
