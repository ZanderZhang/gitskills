/*******************************
File Name: define2.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 10:01:20 2014
*******************************/

#include <stdio.h>

#define MAX(a,b) a > b ? a : b

int maxFun(int a,int b)
{
	return a > b? a : b;
}

int main(int argc,char *argv[])
{
	int a = 3;
	int b = 4;
//直接用运算符
	int max = a>b? a : b;
	printf("max = %d\n",max);
//函数调用
	int maxf = maxFun(a,b);
	printf("maxf = %d\n",maxf);
//宏定义调用
	int maxd = MAX(a,b);
	printf("maxd = %d\n",maxd);

	return 0;
}
