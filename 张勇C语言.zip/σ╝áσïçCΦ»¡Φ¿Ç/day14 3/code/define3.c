/*******************************
File Name: define3.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 10:25:34 2014
*******************************/

#include <stdio.h>

#define SUM(a,b) ((a) + (b)) 




int main(int argc,char *argv[])
{
	int a = 3;
	int b = 4;
	int c =SUM(a,b);
	printf("c = %d\n",c);
	int d = SUM(a,b) * SUM(a,b);// (3 + 4) * (3 + 4)`
	printf("d = %d\n",d);
	return 0;
}
