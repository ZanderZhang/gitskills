/*******************************
File Name: ifndef.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 11:44:04 2014
*******************************/

#include <stdio.h>

#define GD

int main(int argc,char *argv[])
{
#ifndef GD
	printf("###########\n");
#else
	printf("***********\n");
#endif

	return 0;
}
