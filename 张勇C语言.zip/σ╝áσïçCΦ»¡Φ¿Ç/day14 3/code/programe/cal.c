/*******************************
File Name: cal.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 11:08:00 2014
*******************************/

//函数实现
float add(float a,float b)
{
	return a + b;
}
float sub(float a,float b)
{
	return a - b;
}
float mul(float a,float b)
{
	return a * b;
}
float div(float a,float b)
{
	if(b!=0)
		return a / b;
	else 
		return -1;
}
