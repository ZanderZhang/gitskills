/*******************************
File Name: cal.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 11:08:00 2014
*******************************/

//函数声明

struct Point
{
	float x;
	float y;
};


float add(float a,float b);
float sub(float a,float b);
float mul(float a,float b);
float div(float a,float b);
