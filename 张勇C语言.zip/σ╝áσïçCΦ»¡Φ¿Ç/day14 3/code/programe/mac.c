/*******************************
File Name: mac.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 11:54:57 2014
*******************************/

#include <stdio.h>

int main(int argc,char *argv[])
{
  printf("line = %d, file = %s, DATA = %s, TIME = %s", __LINE__, __FILE__, __DATE__, __TIME__);
	return 0;
}
