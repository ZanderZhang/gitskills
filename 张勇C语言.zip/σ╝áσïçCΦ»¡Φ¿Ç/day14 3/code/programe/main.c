/*******************************
File Name: cal.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 11:08:00 2014
*******************************/

#include <stdio.h>
#ifndef _CAL_H_  //ifndef 可以解决头文件重复包含错误
#define _CAL_H_
#include "cal.h"
#endif

//主函数
int main(int argc,char *argv[])
{
	float x,y,ret;
	char ch;
	scanf("%f",&x);
	getchar( );
	scanf("%c",&ch);
	scanf("%f",&y);

	switch(ch)
	{
		case '+':
			ret = add(x,y);
			break;

		case '-':
			ret = sub(x,y);
			break;

		case '*':
			ret = mul(x,y);
			break;

		case '/':
			ret = div(x,y);
			break;
	
	}
	
	printf("=%g\n",ret);
		
	return 0;
}
