/*******************************
File Name: struct.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 09:09:00 2014
*******************************/

#include <stdio.h>

struct Point
{
	float x;
	float y;
};

//顶点、长，宽可以在坐标系上唯一确定一个矩形 

struct Rect
{
	struct Point top;
	float l;
	float w;
};

//圆心和半径

struct Cir
{
	struct Point p;
	float r;
};


int main(int argc,char *argv[])
{

	return 0;
}
