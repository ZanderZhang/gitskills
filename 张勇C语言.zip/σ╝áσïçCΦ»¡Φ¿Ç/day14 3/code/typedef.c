/*******************************
File Name: typedef.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 09:25:45 2014
*******************************/

#include <stdio.h>

long int strlen(const char *s);


size_t strlen(const char *s);

struct Point
{
	float x;
	float y;
};

struct Rect
{
	struct Point p;
	float l;
	float w;
};


int main(int argc,char *argv[])
{
//typedef   已有的数据类型  已有数据类型的别名;
	typedef long int size_t;

	typedef struct Rect RectType;

	struct Rect rect;

	RectType rect2;


	return 0;
}
