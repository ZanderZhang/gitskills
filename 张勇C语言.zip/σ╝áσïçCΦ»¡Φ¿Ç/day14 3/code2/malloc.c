/*******************************
File Name: malloc.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 14:18:35 2014
*******************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//void * malloc(size_t size)

void * fun( )
{
	void * p = malloc(64);
	return p;
}


int main(int argc,char *argv[])
{
	void * p = fun( );
	char * q = (char *)p;
	
	strcpy(q,"xiaoming");
	puts(q);
	
	free(q);
//1 free 释放的是指针所指向的堆内存
//2 同一块内存只能被释放一次

	while(1)  ;

	return 0;
}
