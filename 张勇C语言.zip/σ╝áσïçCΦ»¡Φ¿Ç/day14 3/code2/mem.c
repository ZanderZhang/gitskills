/*******************************
File Name: mem.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 13:48:55 2014
*******************************/

#include <stdio.h>
#include <string.h>


//栈空间局限性：
//1作用域和生命周期
/*
char * fun( )
{
	char str[64];
	strcpy(str,"xiaoming");
	return str;
}*/


int main(int argc,char *argv[])
{
//	char *p = fun( );
//	puts(p);
//栈空间局限性2,栈空间内存大小	
	char ch[8 * 1024 * 1024];
	strcpy(ch,"xiaoming");
	puts(ch);	
	return 0;
}
