/*******************************
File Name: memcpy.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 15:19:12 2014
*******************************/

#include <stdio.h>
#include <string.h>
//strcpy(char *dst,char *src)
//memcpy(void *dst,void *src,size_t size)


int main(int argc,char *argv[])
{
	int arr[10] = {1,2,3,4,5,6,7,8,9,0};
	int brr[10];
/*
	int i;
	for(i=0; i<10; i++)
	{
		brr[i] = arr[i];
		printf("%d  ",brr[i]);
	}
	printf("\n");
*/

	memcpy(brr,arr,4*10);//第三个参数是以字节为单位

	int i;
	for(i=0; i<10; i++)
	{
		printf("%d  ",brr[i]);
	}
	printf("\n");

	return 0;
}
