/*******************************
File Name: memexe.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 14:46:43 2014
*******************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv[])
{
	double * p = (double *)malloc(sizeof(double));
	
	*p = 3.14;

	printf("*p = %f\n",*p);

			
	double *q = (double *)malloc(10*sizeof(double));

	int i;
	for(i=0; i<10; i++)
	{
		//q[i] = i;  //q[i] = *(q + i)
		*q++ = i;
		printf("%f\n",*(q-1));
	}

	return 0;
}
