/*******************************
File Name: memset.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 15:12:40 2014
*******************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc,char *argv[])
{
	int *p = (int *)malloc(sizeof(int)*10);
//void * memset(void *p,int c,size_t size)
	memset(p,0,10*4);//第三个参数以字节为单位
	
	int i;
	for(i=0; i<10; i++)
	{
		printf("%d\n",p[i]);
	}
	return 0;
}
