/*******************************
File Name: memsize.c
Author: xw
#Company: 千锋(深圳)
Created Time: 四 11/ 6 14:59:00 2014
*******************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char *argv[])
{
	char *p = (char *)malloc(1024*1024*1024*10);
	strcpy(p,"xiaoming");
	puts(p);
	return 0;
}
