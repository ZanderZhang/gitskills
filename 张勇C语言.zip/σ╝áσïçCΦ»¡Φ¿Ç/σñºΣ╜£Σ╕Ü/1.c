#include <stdio.h>

void A()
{
	int a,b,c,n=100;
	for(n=100; n<=999; n++)
	{
		
	c=n%10;b=n/10%10;a=n/100%10;
		if(n==c*c*c+b*b*b+a*a*a)
		printf("%d ",n);
	}
}


int main(void)
{
	A();
	printf("\n");
	return 0;
}


