#include <stdio.h>

int main(void)
{
	char ch,c,c1;
	scanf("%c",&ch);
	switch(ch)
	{	case 'M':
		printf("Monday\n");
		break;
		case 'W':
		printf("Wednesday\n");
		break;
		case 'F':
		printf("Friday\n");
		break;

		case 'T':
				
			scanf("%c",&c);
			getchar();
			if(c=='u')
			printf("Tuesday\n");
			break;
			if(c=='h')
			printf("Thursday\n");
			break;
		case 'S':
			scanf("%c",&c1);
			if(c1=='u')
			printf("Sunday\n");
			break;
			if(c1=='a')
			printf("Saturday\n");
			break;
	}

	return 0;
}
