#include <stdio.h>

int main(void)
{
	int a[5];
	int tmp;
	int i,len=sizeof(a)/sizeof(int);
	for(i=0; i<len; i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0; i<len/2; i++)
	{
		tmp=a[i];a[i]=a[len-1-i];a[len-1-i]=tmp;

	}
	for(i=0; i<len; i++)
	{
	printf("%d",a[i]);
	}
	printf("\n");
	

	return 0;
}
