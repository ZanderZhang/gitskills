#include <stdio.h>

int main(void)
{
	int a=1,b=1,c=1,cnt=0,max=18,tmp,d;
	for(a=1; a<19; a++)
	{
		for(b=1; b<19; b++)
		{
			c=a*b*(20-a-b);
			if(c>max)
			{

			}
			cnt++;
		}
		
	}
			printf("%d %d ",max,d);
	printf("%d\n",cnt);
	return 0;
}
