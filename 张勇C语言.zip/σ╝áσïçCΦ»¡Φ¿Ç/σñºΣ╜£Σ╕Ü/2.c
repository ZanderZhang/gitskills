#include <stdio.h>

void A()
{
	int n,i;
	scanf("%d",&n);
	for(i=2; i<=n; i++)
	{
		if(n%i==0)
		{	if(i != n){
			printf("%d*",i);
			n /= i;
			i=1;}
			else
			printf("%d",n);
		}
	}
}
int main(void)
{
	A();
	printf("\n");
	
	return 0;
}
