#include <stdio.h>

int main(void)
{
	int s;
	scanf("%d",&s);
	printf("%c\n",(s>=90)?'A':((s<=89&&s>=60)?'B':'C'));

	return 0;
}
