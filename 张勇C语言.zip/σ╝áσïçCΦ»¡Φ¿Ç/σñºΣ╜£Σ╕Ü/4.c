#include <stdio.h>

int main()
{
	char a1[7];
	int a=0,b=0,c=0,d=0,e=0,i;
	for(i=0; a1[i]!=='\n'; i++)
	{
		scanf("%c",&a1[i]);
	}
	if(a1[i]=='\0')
	b++;
	if(a1[i]>='A'&&a1[i]<='Z'||a1[i]>='a'&&a1[i]<='z')
	a++;
	if(scanf("%d",&a[i])
	c++;
	d=e-1-a-b-1-c;
	printf("%d %d %d %d %d\n",a,b,c,d,e);
	return 0;
}
