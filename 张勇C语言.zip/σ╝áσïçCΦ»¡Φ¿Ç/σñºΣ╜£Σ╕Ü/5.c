#include <stdio.h>

int main(void)
{
	int i,j=2,sum=0,n;
	scanf("%d",&n);
	for(i=0; i<n; i++)
	{
		sum += j;
		j=j*10+2;
	}
	printf("%d\n",sum);

	return 0;
}
