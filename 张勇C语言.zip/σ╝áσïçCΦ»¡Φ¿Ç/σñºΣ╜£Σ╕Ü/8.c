#include <stdio.h>

int main(void)
{
	long long i,j=1,a,sum=0;
	
	
		
	for(i=1; i<=20; i++)

{	j *= i;
	sum +=j;
}	
	printf("%lld\n",sum);
	return 0;
}
