#include <stdio.h>

int main(void)
{
	int n,cnt=0;
	scanf("%d",&n);
	while(n)
	{
		printf("%d",n%10);
		n=n/10;
		cnt++;
	}
	printf("\n");
	printf("%d\n",cnt);
	return 0;
}
