#include <stdio.h>

int main(void)
{
	int arr[5] = {1,2,3,5,6};
	int i = 0;
	int index = 0;
	int num = 0;
	
	scanf("%d", &num);
	//找到应该插入的位置
	for(i = 0; i < 5; i ++)
	{
		if(num < arr[i])
		{
			index = i;
			break;
		}
	}
	//如果num应该插入下标为0~4的位置，则进行插入
	//否则不插入
		for(i = 5; i > index; i --)
		{
			arr[i] = arr[i - 1];
		}
		arr[index] = num;
	for(i = 0; i < 6; i ++)
	{
		printf("%d ", arr[i]);
	}
	printf("\n");
	return 0;
}
