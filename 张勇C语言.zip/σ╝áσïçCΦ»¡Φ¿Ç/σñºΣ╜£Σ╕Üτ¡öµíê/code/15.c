#include <stdio.h>

int main(void)
{
	int n = 0;
	int i = 0, j = 0;
	scanf("%d", &n);
	int arr[n];

	for(i = 0; i < n; i ++)
	{
		arr[i] = i + 1;
	}

	int len = n;
	int count = 0;

	for(i = 0; i < len; i ++)
	{
		count ++;
		if(count == 3)
		{
			count = 0;
			for(j = i; j < len - 1; j ++)
			{
				arr[j] = arr[j + 1];
			}
			len --;
			i --;
		}
		if(len == 1)
			break;
		if(i == len - 1)
			i = -1;
	}
	printf("%d\n", arr[0]);
	return 0;
}
