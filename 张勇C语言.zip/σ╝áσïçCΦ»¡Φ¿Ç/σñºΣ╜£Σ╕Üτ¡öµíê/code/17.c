#include <stdio.h>

int is_alpha(char ch)
{
	if(ch >= 'a' && ch <= 'z'
	 || ch >= 'A' && ch <= 'Z')
	 	return 1;
	else
		return 0;
}

int is_digit(char ch)
{
	if(ch >= '0' && ch <= '9')	
		return 1;
	else
		return 0;
}

int is_biaodian(char ch)
{
	if(ch < '0' || ch > '9' && ch < 'A' 
		|| ch > 'Z' && ch < 'a' || ch > 'z')
		return 1;
	else 
		return 0;
}

int main(void)
{
	char str[100] = {};
	int counter = 0;
	int i = 0;

	scanf("%[^\n]", str);
	while(str[i] != '\0')
	{
		if((is_alpha(str[i]) || is_digit(str[i]))
			&& is_biaodian(str[i + 1]))
		{
			counter ++;
		}
		i ++;
	}
	printf("\n%d\n", counter);
	return 0;
}
