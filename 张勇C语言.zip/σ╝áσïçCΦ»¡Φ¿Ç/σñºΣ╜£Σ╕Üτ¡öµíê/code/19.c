#include <stdio.h>

int main(void)
{
	int hour = 0;
	int minits = 0;
	int second = 0;

	scanf("%d: %d: %d", &hour, &minits, &second);
	second ++;
	if(second == 60)
	{
		second = 0;
		minits ++;
		if(minits == 60)
		{
			minits = 0;
			hour ++;
			if(hour == 24)
			{
				hour = 0;
			}
		}
	}
	printf("%d : %d : %d\n", hour, minits, second);
	return 0;
}
