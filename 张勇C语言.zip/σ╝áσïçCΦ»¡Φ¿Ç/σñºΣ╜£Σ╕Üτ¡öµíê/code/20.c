#include <stdio.h>

int main(void)
{
	int i = 0;
	int j = 0;
	int n = 0;
	int counter = 0;

	scanf("%d", &n);
	for(i = n; i > 0; i -= 2)
	{
		for(j = 0; j < counter; j ++)
		{
			printf(" ");
		}
		for(j = 0; j < i; j ++)
		{
			printf("*");
		}
		counter ++;
		printf("\n");
	}
	return 0;
}
