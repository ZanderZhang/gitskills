#include <stdio.h>

int main(void)
{
	int n = 0;
	int i, j;
	int temp = 0;

	scanf("%d", &n);
	int arr[n][n];

	for(i = 0; i < n; i ++)
	{
		for(j = 0; j < n; j ++)
		{
			scanf("%d", &arr[i][j]);
		}
	}
	for(i = 0; i < n; i ++)
	{
		for(j = 0; j < n; j ++)
		{
			printf("%d", arr[i][j]);
		}
		printf("\n");
	}

	for(i = 0; i < n; i ++)
	{
		for(j = 0; j < i; j ++)
		{
			temp = arr[i][j];
			arr[i][j] = arr[j][i];
			arr[j][i] = temp;
		}
	}

	for(i = 0; i < n; i ++)
	{
		for(j = 0; j < n; j ++)
		{
			printf("%d", arr[i][j]);
		}
		printf("\n");
	}
	
	
	return 0;
}
