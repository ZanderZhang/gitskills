#include <stdio.h>

int main(void)
{
	char ch = 0;
	int score = 0;

	scanf("%d", &score);
	ch = (score >= 90) ? 'A' : (score >= 60) ? 'B' : 'c';

	printf("%c\n", ch);
	return 0;
}
