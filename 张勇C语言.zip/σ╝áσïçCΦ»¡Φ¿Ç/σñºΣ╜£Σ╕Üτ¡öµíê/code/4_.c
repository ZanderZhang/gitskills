#include <stdio.h>

int main(void)
{
	char c = 0;
	int arr[4] = {};

	while(1)
	{
		scanf("%c", &c);
		if(c == '\n')
			break;
		if(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z')
			arr[0] ++;
		else if(c == ' ')
			arr[1] ++;
		else if(c >= '0' && c <= '9')
			arr[2] ++;
		else
			arr[3] ++;
	}
	printf("英文个数为：%d\n\
空个数为: %d\n\
数字个数为：%d\n\
其他字符个数为：%d\n",arr[0],arr[1],arr[2],arr[3]);
			
	return 0;
}
