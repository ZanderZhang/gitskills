#include <stdio.h>

int main(void)
{
	int n = 0;
	int i = 0;
	int sum = 0;
	int num = 0;

	scanf("%d", &n);
	for(i = 0; i < n; i ++)
	{
		num = num*10 + 2;
		sum += num;
	}
	printf("sum = %d\n", sum);
	return 0;
}
