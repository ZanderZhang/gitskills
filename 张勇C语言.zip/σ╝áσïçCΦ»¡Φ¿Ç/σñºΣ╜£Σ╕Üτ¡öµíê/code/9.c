#include <stdio.h>

int main(void)
{
	int num = 0;
	int counter = 0;

	scanf("%d", &num);
	if(num == 0)
		printf("%d 1位\n", num);
	else
	{
		while(num)//1234
		{
			counter ++;
			printf("%d ", num % 10);
			num /= 10;
		}
		printf("\n%d位数\n", counter);
	}
	return 0;
}
