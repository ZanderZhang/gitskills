//
//  CYRootViewController.m
//  net
//
//  Created by lcy on 14/12/15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController () <NSURLConnectionDataDelegate>
{
    NSURLConnection *_connection;
    
    //保存接受的数据
    NSMutableData *_revData;
    
    //
    UIImageView *_imgView;
    
    UIActivityIndicatorView *activity;
    
    UIProgressView *progressView;
    
    //保存文件的大小
    float fileLength;
    
    NSString *fileName;
}

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the
    
    _revData = [[NSMutableData alloc] init];
    
    //http://127.0.0.1/net/json1
    NSString *path = @"http://127.0.0.1/net/json1";

    NSURL *url = [NSURL URLWithString:path];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    
    _connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
}

//处理 请求错误
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

//接受数据
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_revData appendData:data];
}

//已经接收到响应
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    _revData.length = 0;
}

//已经接受完毕
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //NSLog(@"%@",_revData);
    
    /*
     NSJSONReadingMutableContainers = (1UL << 0), 
     可变的
     NSJSONReadingMutableLeaves = (1UL << 1),
     只读
     NSJSONReadingAllowFragments = (1UL << 2)
     允许不是json格式的数据
     */
    
    //下载的图片保存到系统相册.  一次下载两张图片
    //http://127.0.0.1/net/json1 json   json_exc
    NSDictionary *obj = [NSJSONSerialization JSONObjectWithData:_revData options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"%@",obj);
    
    for (NSString *key in obj) {
        NSArray *arr = [obj objectForKey:key];
        
        for (NSDictionary *dic in arr) {
            for (NSString *key in dic) {
                //NSLog(@"%@",dic[key]);
                //josn  xml
                NSLog(@"%@",dic[key][@"name"]);
                NSLog(@"%@",dic[key][@"age"]);
                NSLog(@"%@",dic[key][@"score"]);
            }
        }
    }
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
