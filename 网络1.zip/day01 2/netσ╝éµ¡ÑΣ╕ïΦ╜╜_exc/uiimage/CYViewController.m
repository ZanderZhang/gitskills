//
//  CYViewController.m
//  uiimage
//
//  Created by zhangyong on 14-12-15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYViewController.h"

@interface CYViewController () <NSURLConnectionDataDelegate>
@property(nonatomic,strong)NSURLConnection *connection;
@property(nonatomic,strong)NSMutableData *data;
@property(nonatomic,strong)NSURLConnection *connection1;
@property(nonatomic,strong)NSMutableData *data1;
@property(nonatomic,strong)NSURLConnection *connection2;
@property(nonatomic,strong)NSMutableData *data2;

@property (weak, nonatomic) IBOutlet UIImageView *imgView1;
@property (weak, nonatomic) IBOutlet UIImageView *imgView2;
@property (weak, nonatomic) IBOutlet UIImageView *imgView3;
@property(nonatomic,strong)NSString *fileName;
@property(nonatomic,strong)NSString *fileName1;
@property(nonatomic,strong)NSString *fileName2;
@property(nonatomic,strong)NSString *path;
@property(nonatomic,strong)NSString *path1;
@property(nonatomic,strong)NSString *path2;

@property(nonatomic,strong)NSArray *arr;
@end

@implementation CYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _data=[NSMutableData alloc];
    NSURL *url=[NSURL URLWithString:@"http://c.hiphotos.baidu.com/image/h%3D360/sign=630d26dd818ba61ec0eece29713497cc/0e2442a7d933c895037bb86cd21373f08202009b.jpg"];
    NSURLRequest *request=[[NSURLRequest alloc]initWithURL:url];
    _connection=[[NSURLConnection alloc]initWithRequest:request delegate:self];
    
    _data1=[NSMutableData alloc];
    NSURL *url1=[NSURL URLWithString:@"http://e.hiphotos.baidu.com/image/h%3D360/sign=9069bdd9f8edab646b724bc6c736af81/8b13632762d0f703a5e956ce0bfa513d2697c54d.jpg"];
    NSURLRequest *request1=[[NSURLRequest alloc]initWithURL:url1];
    _connection1=[[NSURLConnection alloc]initWithRequest:request1 delegate:self];


    _data2=[NSMutableData alloc];
    NSURL *url2=[NSURL URLWithString:@"http://d.hiphotos.baidu.com/image/h%3D360/sign=a205153db351f819ee25054ceab44a76/d6ca7bcb0a46f21f251ecd45f5246b600c33aefa.jpg"];
    NSURLRequest *request2=[[NSURLRequest alloc]initWithURL:url2];
    _connection2=[[NSURLConnection alloc]initWithRequest:request2 delegate:self];
    
    //保存到沙盒里面。
    _arr=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);


    
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    if (connection==_connection) {
        [_data appendData:data];

    }
    else if(connection==_connection1)
        [_data1 appendData:data];
    else if(connection==_connection2)
        [_data2 appendData:data];
}
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    if (connection==_connection) {
        _fileName=[response suggestedFilename];
        
    }
    else if(connection==_connection1){
        _fileName1=[response suggestedFilename];

    }

    else  if(connection==_connection2)
    {
        _fileName2=[response suggestedFilename];

    }
    
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    if (connection==_connection) {
        _imgView1.image=[UIImage imageWithData:_data];
        UIImageWriteToSavedPhotosAlbum(_imgView1.image, 0, 0, 0);
        _path=[NSString stringWithFormat:@"%@/%@",_arr[0],_fileName];
        [_data writeToFile:_path atomically:YES];


        

    } else if(connection==_connection1){
        _imgView2.image=[UIImage imageWithData:_data1];
        UIImageWriteToSavedPhotosAlbum(_imgView2.image, 0, 0, 0);
        _path1=[NSString stringWithFormat:@"%@/%@",_arr[0],_fileName1];
        [_data1 writeToFile:_path1 atomically:YES];


    }
    else  if(connection==_connection2)
    {
        _imgView3.image=[UIImage imageWithData:_data2];
        UIImageWriteToSavedPhotosAlbum(_imgView3.image, 0, 0, 0);
        _path2=[NSString stringWithFormat:@"%@/%@",_arr[0],_fileName2];
        [_data2 writeToFile:_path2 atomically:YES];
        NSLog(@"%@",_path2);
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
