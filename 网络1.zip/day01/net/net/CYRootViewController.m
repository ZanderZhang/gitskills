//
//  CYRootViewController.m
//  net
//
//  Created by lcy on 14/12/15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //ip/net/index.php
    //ip/net/1.jpg
    //先创建一个 url
    //localhost ----> 127.0.0.1
    //url  协议名://主机名:端口/路径
    
    //ip/net/index.php
    //ip/net/1.jpg
//    NSString *path = @"http://www.baidu.com";
//    //html
//    //+ -
//    NSURL *url = [NSURL URLWithString:path];
//    //协议名
//    NSLog(@"%@",[url scheme]);
//    //获取主机名
//    NSLog(@"%@",[url host]);
//    //获取端口
//    NSLog(@"%@",[url port]);
//    //webView
//
//    NSString *str = [NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
//    
//    NSLog(@"%@",str);
//    
//    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
//    
//    [webView loadHTMLString:str baseURL:url];
//    
//    [self.view addSubview:webView];
    
    
    
    NSURL *url=[NSURL URLWithString:@"http://weibo.com/u/2000515475/home?wvr=5&lf=reg"];
    
    NSString *str=[NSString stringWithContentsOfURL:url encoding:NSUTF8StringEncoding error:0];
    
    UIWebView *webView=[[UIWebView alloc]initWithFrame:self.view.bounds];
    
    
    [webView loadHTMLString:str baseURL:url];
    
    [self.view addSubview:webView];
    
    
    
    
    
    //[NSString alloc] initw
    
    //[NSString alloc] initWithData:<#(NSData *)#> encoding:<#(NSStringEncoding)#>
    //[NSData alloc]
    //[str dataUsingEncoding:<#(NSStringEncoding)#>]
    
    //data <---> string
    //data --->  alloc] initWithData
    //string ---> data  datausingString
    //[str dataUsingEncoding:<#(NSStringEncoding)#>]
    
    //同步下载  当下在的时候 会阻塞线程 , ui界面无法响应
    //异步下载  当下在的时候 不会阻塞线程
    //单线程
//    NSString *imgPath = @"http://127.0.0.1/net/1.jpg";
//    //+ -
//    NSURL *imgUrl = [NSURL URLWithString:imgPath];
//    NSData *data = [NSData dataWithContentsOfURL:imgUrl];
//    
//    NSLog(@"%@",data);
//    UIImageView *imgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
//    UIImage *image = [UIImage imageWithData:data];
//    
//    imgView.image = image;
    //[self.view addSubview:imgView];
    //NSLog(@"%@",str);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
