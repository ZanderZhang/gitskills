//
//  CYRootViewController.m
//  net
//
//  Created by lcy on 14/12/15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController ()

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the
    NSString *path = @"http://img3.3lian.com/2006/013/16/2005617193712391.jpg";
    //html
    //+ -
    NSURL *url = [NSURL URLWithString:path];
   
    //创建一个 请求资源的对象
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    //NSError
    NSURLResponse *response = nil;
    //通道 //404    //400  bad request
    //200 请求成功   2
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    NSHTTPURLResponse *http = (NSHTTPURLResponse *)response;
    NSLog(@"%@",response);
    //可以得到文件名
    NSLog(@"%@",[response suggestedFilename]);
    //得到文件的大小
    NSLog(@"%lld",[response expectedContentLength]);
    //得到状态码
    NSLog(@"%d",[http statusCode]);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
