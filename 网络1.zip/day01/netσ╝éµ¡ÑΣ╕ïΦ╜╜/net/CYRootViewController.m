//
//  CYRootViewController.m
//  net
//
//  Created by lcy on 14/12/15.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController () <NSURLConnectionDataDelegate>
{
    NSURLConnection *_connection;
    
    //保存接受的数据
    NSMutableData *_revData;
    
    //
    UIImageView *_imgView;
}

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the
    
    _revData = [[NSMutableData alloc] init];
    NSString *path = @"http://map.onegreen.net/%E4%B8%AD%E5%9B%BD%E6%94%BF%E5%8C%BA2500.jpg";
   
    NSURL *url = [NSURL URLWithString:path];
   
    //创建一个 请求资源的对象
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    //通道 //404    //400  bad request
    //200 请求成功   2
    _connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    _imgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    _imgView.image = [UIImage imageNamed:@"1.jpg"];
    
    [self.view addSubview:_imgView];
}

//处理 请求错误
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

//接受数据  //5MB   //10
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //NSLog(@"%@",NSStringFromSelector(_cmd));
    [_revData appendData:data];
}

//已经接收到响应
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"%@",NSStringFromSelector(_cmd));
    //清空上一次请求的内容
    _revData.length = 0;
}

//已经接受完毕
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //NSLog(@"%@",NSStringFromSelector(_cmd));
    _imgView.image = [UIImage imageWithData:_revData];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
