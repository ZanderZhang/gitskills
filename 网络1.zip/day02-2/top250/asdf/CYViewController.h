//
//  CYViewController.h
//  asdf
//
//  Created by zhangyong on 14-12-26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYViewController : UIViewController

@end
