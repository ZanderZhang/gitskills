//
//  CYViewController.m
//  asdf
//
//  Created by zhangyong on 14-12-26.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYViewController.h"

@interface CYViewController ()

@end

@implementation CYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

@end
