//
//  CYRootViewController.m
//  net_exc
//
//  Created by lcy on 14/12/16.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"

@interface CYRootViewController () <NSURLConnectionDataDelegate>
@property (nonatomic,strong) NSMutableData *recvData;
@property (nonatomic,strong) UIImageView *imgView;
@property (nonatomic,strong) NSString *fileName;

@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //
    NSString *urlStr = @"http://202.195.64.103/picture/article/319/cd/ca/fbb257fe4b9da86dbebcca469915/aed9d401-42f4-4a15-bd81-1daef198f5b9.jpg";
    
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    _recvData = [[NSMutableData alloc] init];
    _imgView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    
    [self.view addSubview:_imgView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    _recvData.length = 0;
    _fileName = [response suggestedFilename];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_recvData appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    _imgView.image = [UIImage imageWithData:_recvData];
    
    //josn
    //保存沙盒
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *strPath = paths[0];
    
    //stringByAppendingPathComponent 自动 "/"
    strPath = [strPath stringByAppendingPathComponent:_fileName];
    NSLog(@"%@",strPath);
    
    [_recvData writeToFile:strPath atomically:YES];
    //保存到相册中去。
    UIImageWriteToSavedPhotosAlbum(_imgView.image, nil, nil, nil);
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
    //可以在这里处理保存成功等,要传参数。
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
