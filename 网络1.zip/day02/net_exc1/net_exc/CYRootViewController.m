//
//  CYRootViewController.m
//  net_exc
//
//  Created by lcy on 14/12/16.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYRootViewController.h"
#import "CYStudent.h"

@interface CYRootViewController () <NSURLConnectionDataDelegate,UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) NSMutableData *recvData;
@property (nonatomic,strong) UIImageView *imgView;
@property (nonatomic,strong) NSString *fileName;

@property (nonatomic,strong) NSMutableArray *data;
@property (nonatomic,strong) UITableView *tabView;
@end

@implementation CYRootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //https://api.douban.com/v2/book/search?q=C++&start=10&count=10
    
    _data = [[NSMutableArray alloc] init];
    NSString *urlStr = @"http://127.0.0.1/net/json1";
    
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    
    _recvData = [[NSMutableData alloc] init];
    
    _tabView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    
    _tabView.delegate = self;
    _tabView.dataSource = self;
    [self.view addSubview:_tabView];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.data.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if(cell ==nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = [self.data[indexPath.row] name];
    
    cell.detailTextLabel.text = [self.data[indexPath.row] age];
    
    return cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    _recvData.length = 0;
    _fileName = [response suggestedFilename];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [_recvData appendData:data];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //NSJSONReadingMutableLeaves 返回一个  Json  格式的一个 NSMutableString
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:_recvData options:NSJSONReadingMutableContainers error:nil];
    
    NSArray *arr = dic[@"Student"];
    for (NSDictionary *stuInfo in arr) {
        CYStudent *stu = [[CYStudent alloc] initWithDictionary:stuInfo];
        [_data addObject:stu];
    }
    
    [_tabView reloadData];
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
