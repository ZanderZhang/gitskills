//
//  CYStudent.m
//  net_exc
//
//  Created by lcy on 14/12/16.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYStudent.h"

@implementation CYStudent

-(id)initWithDictionary:(NSDictionary *)dic
{
    self = [super init];
    
    if(self)
    {
        NSLog(@"%@",dic);
        for (NSString *key in dic) {
            _name = dic[key][@"name"];
            //NSI
            NSInteger temp = [dic[key][@"age"] integerValue];
            _age = [NSString stringWithFormat:@"%d",temp];
    
            temp = [dic[key][@"score"] integerValue];
            _score = [NSString stringWithFormat:@"%d",temp];
            
            NSLog(@"%@,%@,%@",_name,_age,_score);
            
        }
        //_age
    }
    return self;
}

@end
