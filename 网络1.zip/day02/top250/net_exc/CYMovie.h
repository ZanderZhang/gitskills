//
//  CYMovie.h
//  net_exc
//
//  Created by lcy on 14/12/16.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CYMovie : NSObject
//
@property (nonatomic,strong) NSString *imgName;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *title;

-(id)initWithDictionary:(NSDictionary *)dic;

@end
