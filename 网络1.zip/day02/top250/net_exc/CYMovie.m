//
//  CYMovie.m
//  net_exc
//
//  Created by lcy on 14/12/16.
//  Copyright (c) 2014年 qianfeng. All rights reserved.
//

#import "CYMovie.h"

@implementation CYMovie

-(id)initWithDictionary:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        self.imgName = dic[@"images"][@"small"];
        self.name = dic[@"title"];
        self.title = dic[@"original_title"];
    }
    return self;
}
@end
