//
//  ViewController.m
//  Post Demo
//
//  Created by vera on 14-12-18.
//  Copyright (c) 2014年 vera. All rights reserved.
//



#import "ViewController.h"

@interface ViewController ()
{
    NSMutableData *requestData;
}

@end

/*
 GET和POST的区别：
    1. GET提交的数据会放在URL之后，以?分割URL和传输数据，参数之间以&相连，如EditPosts.aspx?name=test1&id=123456.  POST方法是把提交的数据放在HTTP包的Body中.
    GET: http://10.0.8.10/sns/my/login.php?username=test&password=123456&email=123@163.com
    POST:http://10.0.8.10/sns/my/login.php
 　　2. GET提交的数据大小有限制（因为浏览器对URL的长度有限制），而POST方法提交的数据没有限制.
 　　3. GET方式提交数据，会带来安全问题，比如一个登录页面，通过GET方式提交数据时，用户名和密码将出现在URL上，如果页面可以被缓存或者其他人可以访问这台机器，就可以从历史记录获得该用户的账号和密码.
 */

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    requestData = [NSMutableData data];
    
#if 0
    //GET.默认是GET请求
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://10.0.8.10/sns/my/login.php?username=test&password=123456"]];
#endif
    NSString *parameter = @"username=test&password=123456";
    
    //POST
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://10.0.8.10/sns/my/login.php"]];
    //设置请求方式为POST(默认为GET)
    [request setHTTPMethod:@"POST"];
    //提交参数
    [request setHTTPBody:[parameter dataUsingEncoding:NSUTF8StringEncoding]];
    [NSURLConnection connectionWithRequest:request delegate:self];
    
    /*
    http://10.0.8.10/sns/my/login.php?username=test&password=123456
     */
    
    
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    requestData.length = 0;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [requestData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"%@",[[NSString alloc] initWithData:requestData encoding:4]);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
