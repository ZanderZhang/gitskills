//
//  ViewController.m
//  myPostDemo
//
//  Created by zhangyong on 14-12-18.
//  Copyright (c) 2014年 vera. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tabView;
@property(nonatomic,strong)NSMutableArray *tabViewData;
@end

@implementation ViewController
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _tabViewData.count;
}
UITableViewCell *cell=0;
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
  cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
     //  cell.textLabel.text=dic[@"code"];
    cell.textLabel.text=_tabViewData[indexPath.row];
    cell.textLabel.text=@"_tabViewData[indexPath.row]";

    return cell;
}
NSDictionary *dic=0;
- (void)viewDidLoad
{
    [super viewDidLoad];
    _tabViewData=[[NSMutableArray alloc]init];

    NSMutableURLRequest *request=[[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:@"http://10.0.8.10/sns/my/login.php"]];
    [request setHTTPMethod:@"POST"];
    //string与DATA的相互转化。
    [request setHTTPBody:[@"username=test&password=123456" dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    
    AFHTTPRequestOperation *op=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    [op setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
       // NSLog(@"%@",[[NSString alloc] initWithData:responseObject encoding:4]);
        dic=[NSJSONSerialization JSONObjectWithData:responseObject options:0 error:0];
        NSLog(@"%@",dic);
//        cell.textLabel.text=dic[@"code"];
//        cell.detailTextLabel.text=dic[@"message"];
     //   [_tabViewData addObject:dic[@"code"]];
        
        [_tabViewData addObject:dic[@"code"]];
        [_tabView reloadData];    
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
    [op start];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager POST:request parameters:<#(id)#> success:<#^(AFHTTPRequestOperation *operation, id responseObject)success#> failure:<#^(AFHTTPRequestOperation *operation, NSError *error)failure#>]
    
    
    _tabViewData=[[NSMutableArray alloc]init];
    _tabView=[[UITableView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:_tabView];
    _tabView.delegate=self;_tabView.dataSource=self;
    [_tabView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
   //去除多余的cell。
    _tabView.tableFooterView=[[UIView alloc]init];
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
