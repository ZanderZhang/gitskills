//
//  main.m
//  myPostDemo
//
//  Created by zhangyong on 14-12-18.
//  Copyright (c) 2014年 vera. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
