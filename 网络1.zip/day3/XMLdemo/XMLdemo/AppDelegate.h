//
//  AppDelegate.h
//  XMLdemo
//
//  Created by vera on 14-12-18.
//  Copyright (c) 2014年 vera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
