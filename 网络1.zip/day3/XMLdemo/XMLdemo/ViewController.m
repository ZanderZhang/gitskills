//
//  ViewController.m
//  XMLdemo
//
//  Created by vera on 14-12-18.
//  Copyright (c) 2014年 vera. All rights reserved.
//

#import "ViewController.h"
#import "GDataXMLNode.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    /*
    NSString *systemVersion =  [[UIDevice currentDevice] systemVersion];

    NSLog(@"%@",systemVersion);
     */
    
    /*
     谓语（Predicates）
     谓语用来查找某个特定的节点或者包含某个指定的值的节点。
     谓语被嵌在方括号中。
     
     实例
     在下面的表格中，我们列出了带有谓语的一些路径表达式，以及表达式的结果：
     路径表达式	结果
     /bookstore/book[1]	选取属于 bookstore 子元素的第一个 book 元素。
     
     /bookstore/book[last()]	选取属于 bookstore 子元素的最后一个 book 元素。
     
     /bookstore/book[last()-1]	选取属于 bookstore 子元素的倒数第二个 book 元素。
     
     /bookstore/book[position()<3]	选取最前面的两个属于 bookstore 元素的子元素的 book 元素。
     
     //title[@lang]	选取所有拥有名为 lang 的属性的 title 元素。
     
     //title[@lang='eng']	选取所有 title 元素，且这些元素拥有值为 eng 的 lang 属性。
     
     /bookstore/book[price>35.00]	选取 bookstore 元素的所有 book 元素，且其中的 price 元素的值须大于 35.00。
     
     /bookstore/book[price>35.00]/title	选取 bookstore 元素中的 book 元素的所有 title 元素，且其中的 price 元素的值须大于 35.00。
     */
    
    //1.获取数据(user.xml)
    //获取user.xml沙盒文件路径
    NSString *path = [[NSBundle mainBundle] pathForResource:@"user" ofType:@"xml"];
    NSLog(@"%@",path);
    //读取文件字符串
    NSString *content = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"内容：%@",content);
    
    
    //2.解析
    /*
     参数：
     1.要解析的字符串
     2.预保留的参数(框架没有用到）
     3.错误信息
     */
    //初始化xml解析器
    GDataXMLDocument *document = [[GDataXMLDocument alloc] initWithXMLString:content options:0 error:nil];
    
#if 0
    //根元素
    GDataXMLElement *rootElement = [document rootElement];
    NSArray *users = [rootElement elementsForName:@"User"];
    
   // NSLog(@"==:%@",users);
    
    //遍历
    for (GDataXMLElement *userElement in users)
    {
        GDataXMLElement *nameElement = [userElement elementsForName:@"name"][0];
        //转化为字符串
        NSString *name = [nameElement stringValue];
        
        NSLog(@"名字：%@",name);
        
        GDataXMLElement *ageElement = [userElement elementsForName:@"age"][0];
        NSString *age = [ageElement stringValue];
        NSLog(@"年龄：%@",age);
        
    }
#endif
    
    //Users/User/name
    NSArray *users = [document nodesForXPath:@"/Users/User" error:nil];
    for (GDataXMLElement *userElement in users)
    {
        GDataXMLElement *nameElement = [userElement elementsForName:@"name"][0];
        //转化为字符串
        NSString *name = [nameElement stringValue];
        
        NSLog(@"名字：%@",name);
        
        GDataXMLElement *ageElement = [userElement elementsForName:@"age"][0];
        NSString *age = [ageElement stringValue];
        NSLog(@"年龄：%@",age);
        
        //获取属性
        GDataXMLNode *idNode = [nameElement attributeForName:@"id"];
        //转化为字符串
        NSString *IDString = [idNode stringValue];
        NSLog(@"学号：%@",IDString);
    }

}

@end
