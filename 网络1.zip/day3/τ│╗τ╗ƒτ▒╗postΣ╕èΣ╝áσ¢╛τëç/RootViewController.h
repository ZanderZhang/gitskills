

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController 
    <NSURLConnectionDataDelegate>
{
    NSURLConnection *connection;
    NSMutableData *recvData;
}

@end
