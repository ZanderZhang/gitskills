

#import "RootViewController.h"


@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBar.translucent = NO;
    [self login];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)login
{
    NSString * loginStr = @"http://119.255.38.178:8089/sns/my/login.php?username=test&password=123456";
    
    NSURLRequest * request = [NSURLRequest requestWithURL:[NSURL URLWithString:loginStr]];
    [NSURLConnection connectionWithRequest:request delegate:self];
}

#define BOUNDARY @"ABC12345678"
- (void) postImage
{
    //NSString * s = @"http://119.255.38.178/sns/my/upload_headimage.php";
    NSString * s = @"http://119.255.38.178:8089/sns/my/upload_headimage.php";
    
    NSURL *url = [NSURL URLWithString:s];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];

    s = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", BOUNDARY];
    [request addValue:s 
        forHTTPHeaderField:@"Content-Type"];
    // 开始拼接POST2 表单
    NSMutableString *bodyString = [NSMutableString string];
    [bodyString appendFormat:@"--%@\r\n", BOUNDARY];
    [bodyString appendString:@"Content-Disposition: form-data; name=\"action\"\r\n"];
    [bodyString appendString:@"\r\n"];
    [bodyString appendString:@"\r\n"];
    /*
     --ABC123
     Content-Disposition: form-data; name=\"action\"\r\n
     \r\n
     \r\n
     */

    [bodyString appendFormat:@"--%@\r\n", BOUNDARY];
    [bodyString appendString:@"Content-Disposition: form-data; name=\"headimage\"; filename=\"test.png\"\r\n"];
    [bodyString appendString:@"Content-Type: image/png\r\n"];
    [bodyString appendString:@"\r\n"];
    /*
     --ABC123
     Content-Disposition: form-data; name=\"action\"\r\n
     \r\n
     \r\n
     --ABC123
     Content-Disposition: form-data; name=\"headimage\"; filename=\"test.png\"\r\n
     Content-Type: image/png\r\n
     \r\n
     */

    NSData * imgData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"image2" ofType:@"png"]];
    
    NSMutableData *bodyData = [[NSMutableData alloc] init];
    NSData *bodyStringData = [bodyString dataUsingEncoding:NSUTF8StringEncoding];

    [bodyData appendData:bodyStringData];
    [bodyData appendData:imgData];

    NSString *endString = [NSString stringWithFormat:@"\r\n--%@--\r\n", BOUNDARY];
    NSData *endData = [endString dataUsingEncoding:NSUTF8StringEncoding];
    [bodyData appendData:endData];

    NSString *len = [NSString stringWithFormat:@"%d", [bodyData length]];
    // 表单的总长度
    [request addValue:len forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:bodyData];
    /*
     最终表单格式
     --ABC123
     Content-Disposition: form-data; name=\"action\"\r\n
     \r\n
     \r\n
     --ABC123
     Content-Disposition: form-data; name=\"headimage(服务器开发文档)\"; filename=\"test.png\"\r\n
     Content-Type: image/png\r\n（数据类型 image/jpeg video/mp4 audio/mp3 ...）
     \r\n
     图片的二进制
     \r\n
     --ABC123
     \r\n
     */
    
    [bodyData release];
    
    connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [request release];
}
- (void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    if (recvData == nil) {
        recvData = [[NSMutableData alloc] init];
    }
    recvData.length = 0;
}
- (void) connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [recvData appendData:data];
}

bool flag = NO;
- (void) connectionDidFinishLoading:(NSURLConnection *)connection {
    NSString *s = [[NSString alloc] initWithData:recvData encoding:NSUTF8StringEncoding];
    NSLog(@"s is %@",s);
    if (!flag) {
        // 登陆成功后调用
        [self postImage];
    }
    flag = YES;

    [s release];
    
}

@end
